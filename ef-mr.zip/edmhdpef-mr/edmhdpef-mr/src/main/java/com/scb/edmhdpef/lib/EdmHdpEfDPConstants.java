package com.scb.edmhdpef.lib;

public class EdmHdpEfDPConstants {

    // Constants
    public static final String COL_SEPARATOR = Character.toString((char) 1);
    public static final String PROP_LINE_SEPARATOR = ",";

    public static final String EDMHDPIF_COLSEPARATOR = "colseparator";
    public static final String EDMHDPIF_OUTPUTCOLSEPARATOR = "outputcolseparator";
}
