package com.scb.edmhdpef.dataprocessing;

import java.util.List;

import org.apache.hadoop.conf.Configuration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.collect.Lists;
import com.scb.edmhdpef.lib.EdmHdpEfDPConstants;

public class EdmHdpEfSchema {

	private List<String> colNames = null;

	private Integer timestampColumn = null;
	private List<Integer> functionalKeyColumns = null;
	private List<Integer> checksumColumn = null;

	private String tableName;

	private Logger logger = LoggerFactory.getLogger(EdmHdpEfSchema.class);

	public EdmHdpEfSchema(Configuration conf, String tableName) {
		this.tableName = tableName;
		String colSchema = conf.get(tableName + ".schema");
		if (colSchema == null) {
			return;
		}
		logger.info(tableName + " colSchema: " + colSchema);

		String schemaCols[] = colSchema.split(EdmHdpEfDPConstants.PROP_LINE_SEPARATOR, -1);
		colNames = Lists.newArrayList(schemaCols);
		String tsCol = conf.get(tableName + ".timestampColumn");
		logger.info(tableName + " TimeStamp: " + tsCol);
		if (tsCol != null) {
			int index = colNames.indexOf(tsCol);
			if (index != -1) {
				timestampColumn = index + 1;
			}
		}
		String fcColStr = conf.get(tableName + ".functionalKeyColumns");
		logger.info(tableName + " functionalKeyColumns: " + fcColStr);
		if (fcColStr != null) {
			String[] fcCols = fcColStr.split(EdmHdpEfDPConstants.PROP_LINE_SEPARATOR);
			for (String col : fcCols) {
				int index = colNames.indexOf(col.trim());
				if (index != -1) {
					if (functionalKeyColumns == null) {
						functionalKeyColumns = Lists.newArrayList(index + 1);
					} else {
						functionalKeyColumns.add(index + 1);
					}
				}
			}
		}
		String ckColStr = conf.get(tableName + ".checksumColumn");
		logger.info(tableName + " checksumColumn: " + ckColStr);
		if (ckColStr != null) {
			String[] ckCols = ckColStr.split(EdmHdpEfDPConstants.PROP_LINE_SEPARATOR);
			for (String col : ckCols) {
				int index = colNames.indexOf(col.trim());
				if (index != -1) {
					if (checksumColumn == null) {
						checksumColumn = Lists.newArrayList(index + 1);
					} else {
						checksumColumn.add(index + 1);
					}
				}
			}
		}
	}

	public List<String> getColNames() {
		return colNames;
	}

	public Integer getTimestampColumn() {
		return timestampColumn;
	}

	public List<Integer> getFunctionalKeyColumns() {
		return functionalKeyColumns;
	}

	public List<Integer> getChecksumColumn() {
		return checksumColumn;
	}

	public String getTableName() {
		return tableName;
	}

	@Override
	public String toString() {
		return "EdmHdpEfSchema [colNames=" + colNames + ", timestampColumn=" + timestampColumn
				+ ", functionalKeyColumns=" + functionalKeyColumns + ", checksumColumn=" + checksumColumn
				+ ", tableName=" + tableName + ", logger=" + logger + "]";
	}
}
