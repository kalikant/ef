package com.scb.edmhdpef.lib;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.fs.PathFilter;
import org.apache.log4j.Logger;

public class EdmHdpEfDPCommon {
	private static final Logger logger = Logger.getLogger(EdmHdpEfDPCommon.class);

	/**
	 * Get files with exact name, from a path using filters.
	 * 
	 * @param fileSystem
	 *            The file system where look for the path.
	 * @param parentPath
	 *            The path.
	 * @param name
	 *            Name to filter files with.
	 * @return The list of files in parentPath starting by name.
	 * @throws IOException
	 */
	private static FileStatus[] getFilteredFilesByName(final FileSystem fileSystem, final Path parentPath,
			final String name) throws IOException {
		try {
			FileStatus[] fileList = fileSystem.listStatus(parentPath, new PathFilter() {
				@Override
				public boolean accept(Path path) {
					if (name == null) {
						return true;
					}
					return path.getName().startsWith(name);
				}
			});
			if (fileList == null) {
				fileList = new FileStatus[] {};
			}
			return fileList;
		} catch (FileNotFoundException e) {
			logger.warn("Ignoring path " + parentPath + ": " + e.getMessage());
			return new FileStatus[] {};
		}
	}

	/**
	 * Delete a path. If the provided path is a directory, delete it
	 * recursively. If it's a file, delete the files starting with the file
	 * name.
	 *
	 * @param deletePath
	 *            Path to delete
	 * @param directory
	 *            Indicates if it's expected to be a directory or not.
	 * @throws IOException
	 */
	public static void deletePath(FileSystem fileSystem, final String deletePathStr) throws IOException {
		// If exists and it's a directory, delete
		boolean directory = deletePathStr.endsWith("/");
		Path deletePath = new Path(deletePathStr);
		if (directory || (fileSystem.exists(deletePath) && fileSystem.isDirectory(deletePath))) {
			if (fileSystem.exists(deletePath)) {
				// Check minimum levels of directory, to avoid deletion of
				// parent directories if parameters are incorrect or not set
				if (deletePath.toString().split("/").length < 4) {
					logger.error("Skipping unsafe delete of directory, please check parameters: " + deletePath);
				} else {
					fileSystem.delete(deletePath, true);
					logger.info("Deleted directory: " + deletePath);
				}
			}
		} else {
			Path parentPath = deletePath.getParent();
			if (fileSystem.exists(parentPath) && fileSystem.isDirectory(parentPath)) {
				// Look for the files matching deletePath
				FileStatus[] fileStatus = getFilteredFilesByName(fileSystem, parentPath, deletePath.getName());
				for (FileStatus file : fileStatus) {
					fileSystem.delete(file.getPath(), true);
					logger.info("Deleted  file: " + file.getPath());
				}
			}
		}
	}

	/**
	 * Check for required parameters, throws an exception if some of the
	 * required parameters are missing.
	 * 
	 * @param conf
	 * @param parameters
	 * @throws RuntimeException
	 */
	public static void checkRequiredParameters(Configuration conf, String[] parameters) throws RuntimeException {
		ArrayList<String> missingParams = new ArrayList<String>();
		for (String param : parameters) {
			if (conf.get(param) == null) {
				missingParams.add(param);
			}
		}
		if (!missingParams.isEmpty()) {
			StringBuilder error = new StringBuilder("Required parameters not set: ");
			for (String param : missingParams) {
				error.append("\n").append(param);
			}
			throw new RuntimeException(error.toString());
		}

	}
}
