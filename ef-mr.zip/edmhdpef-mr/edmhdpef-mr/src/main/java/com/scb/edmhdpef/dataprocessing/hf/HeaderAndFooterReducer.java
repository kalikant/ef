package com.scb.edmhdpef.dataprocessing.hf;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.log4j.Logger;

import com.scb.edmhdpef.lib.EdmHdpEfDPConstants;

public class HeaderAndFooterReducer extends Reducer<Text, Text, NullWritable, Text> {

	/**
	 * Variables initialized at setup
	 */
	private String COL_SEPARATOR = EdmHdpEfDPConstants.COL_SEPARATOR;

	private Configuration conf = null;

	private static final Logger logger = Logger.getLogger(HeaderAndFooterReducer.class);

	private String runDate;

	private Integer sequence = 1;

	@Override
	protected void setup(Context context) throws IOException, InterruptedException {
		logger.info("Setup initiated");

		conf = context.getConfiguration();
		COL_SEPARATOR = conf.get(EdmHdpEfDPConstants.EDMHDPIF_COLSEPARATOR, COL_SEPARATOR);

		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		runDate = sdf.format(Calendar.getInstance().getTime());

		logger.info("Setup finished");

	}

	@Override
	protected void reduce(Text key, Iterable<Text> values, Context context) throws IOException, InterruptedException {

		String tableName = key.toString().split("#", -1)[1];
		String rowType = key.toString().split("#", -1)[2];

		if (rowType.equals("Data")) {
			// Write header
			StringBuilder header = new StringBuilder(tableName).append(COL_SEPARATOR).append('H').append(COL_SEPARATOR)
					.append("1.0").append(COL_SEPARATOR).append("1.0").append(COL_SEPARATOR);
			if (conf.get("country") == null) {
				header.append("ALL");
			} else {
				header.append(conf.get("country"));
			}
			header.append(COL_SEPARATOR).append(conf.get("businessday")).append(COL_SEPARATOR).append(runDate)
					.append(COL_SEPARATOR).append(sequence);
			context.write(NullWritable.get(), new Text(header.toString()));
			// Write data
			for (Text t : values) {
				// Remove tablename
//				String out = t.toString().substring(t.toString().indexOf(COL_SEPARATOR) + 1);
				context.write(NullWritable.get(), t);
			}
		}

		if (rowType.equals("Trail")) {
			// Calculate trail
			Integer count = 0;
			Integer[] checkSums = null;
			int checkSumLength = 0;
			String trailColumns[] = null;
			for (Text val : values) {
				trailColumns = val.toString().split(COL_SEPARATOR, -1);
				// Count
				count += Integer.valueOf(trailColumns[1]);
				// Number of checksums
				if (checkSums == null) {
					checkSums = new Integer[(trailColumns.length / 2) - 1];
					Arrays.fill(checkSums, 0);
					checkSumLength = checkSums.length;
				}
				for (int i = 0; i < checkSumLength; i++) {
					checkSums[i] += Integer.valueOf(trailColumns[(i * 2) + 3]);
				}
			}

			StringBuilder footer = new StringBuilder(tableName).append(COL_SEPARATOR).append('T').append(COL_SEPARATOR)
					.append(count);
			if (trailColumns != null && trailColumns.length > 2) {
				for (int i = 0; i < checkSumLength; i++) {
					footer.append(COL_SEPARATOR).append(trailColumns[(i * 2) + 2]).append(COL_SEPARATOR)
							.append(checkSums[i]);
				}
			}
			context.write(NullWritable.get(), new Text(footer.toString()));
		}
	}
}
