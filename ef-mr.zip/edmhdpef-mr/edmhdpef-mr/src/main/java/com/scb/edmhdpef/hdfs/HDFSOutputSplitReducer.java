package com.scb.edmhdpef.hdfs;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.output.MultipleOutputs;
import org.apache.log4j.Logger;

import com.scb.edmhdpef.lib.EdmHdpEfDPConstants;

public class HDFSOutputSplitReducer extends Reducer<Text, Text, NullWritable, Text> {

    /**
     * Variables initialized at setup
     */
    private String COL_SEPARATOR = EdmHdpEfDPConstants.COL_SEPARATOR;

    private Configuration conf = null;

    private static final Logger logger = Logger.getLogger(HDFSOutputSplitReducer.class);

    private MultipleOutputs<NullWritable, Text> mout;

    private NullWritable nullWritable = NullWritable.get();

    private String outputPath = "/tmp/edmhdpef/output";

    private String lastOutput = null;

    @Override
    protected void setup(Context context) throws IOException, InterruptedException {
        logger.info("Setup initiated");

        conf = context.getConfiguration();
        COL_SEPARATOR = conf.get(EdmHdpEfDPConstants.EDMHDPIF_COLSEPARATOR, COL_SEPARATOR);

        outputPath = conf.get("outputPath", "/tmp/edmhdpef/output") + "/";

        logger.info("Setup finished");
    }

    @Override
    protected void reduce(Text key, Iterable<Text> values, Context context) throws IOException, InterruptedException {

        logger.info("Processing key: " + key.toString());

        String output = key.toString().split("#")[0] + "/";

        if (!output.equals(lastOutput)) {
            // Force write to save memory
            try {
                if (mout != null) {
                    mout.close();
                }
            } catch (IOException e) {
                // If we use compression, then the channel could be already
                // closed. Ignore the exception
            }
            // Open outputs
            mout = new MultipleOutputs<NullWritable, Text>(context);
            lastOutput = output;
        }
        int count = 0;
        for (Text t : values) {
            mout.write("data", nullWritable, t, outputPath + output);
            count++;
        }

        // Rowcount output
        System.out.println("RC" + output.replaceAll("\\/", "") + "=" + count);
    }
}
