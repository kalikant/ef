package com.scb.edmhdpef.dataprocessing.hf;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.log4j.Logger;

import com.scb.edmhdpef.dataprocessing.EdmHdpEfSchema;
import com.scb.edmhdpef.lib.EdmHdpEfDPConstants;

public class HeaderAndFooterMapper extends Mapper<LongWritable, Text, Text, Text> {

    private String COL_SEPARATOR = EdmHdpEfDPConstants.COL_SEPARATOR;

    private Configuration conf = null;

    private Map<String, EdmHdpEfSchema> schemaMap = new HashMap<>();
    private static final Logger logger = Logger.getLogger(HeaderAndFooterMapper.class);

    @Override
    protected void setup(Context context) throws IOException, InterruptedException {
        logger.info("Setup initiated for task " + context.getTaskAttemptID());
        conf = context.getConfiguration();
        COL_SEPARATOR = conf.get(EdmHdpEfDPConstants.EDMHDPIF_COLSEPARATOR, COL_SEPARATOR);

        logger.info("Setup finished");
    }

    @Override
    protected void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {

        String[] row = value.toString().split(COL_SEPARATOR);
        String tableName = row[0];

        EdmHdpEfSchema schema = getSchema(tableName);

        // Get checsum field
        StringBuilder footer = new StringBuilder("T").append(COL_SEPARATOR).append('1');
        if (schema.getChecksumColumn() != null && !schema.getChecksumColumn().isEmpty()) {
            for (int i = 0; i < schema.getChecksumColumn().size(); i++) {
                Integer chksum;
                try {
                    chksum = Integer.valueOf(row[schema.getChecksumColumn().get(i)]);
                } catch (Exception e) {
                    chksum = 0;
                }
                footer.append(COL_SEPARATOR).append(schema.getChecksumColumn().get(i)).append(COL_SEPARATOR)
                        .append(chksum);
            }
        }
        // Add checksums to context
        context.write(new Text('#' + tableName + "#Trail"), new Text(footer.toString()));

        StringBuilder keyStr = new StringBuilder("#").append(tableName).append("#Data");

        String outputValue = value.toString();
        outputValue = outputValue.substring(outputValue.indexOf(COL_SEPARATOR) + 1);

        StringBuilder data = new StringBuilder(tableName).append(COL_SEPARATOR).append('D').append(COL_SEPARATOR)
                .append(outputValue);

        context.write(new Text(keyStr.toString()), new Text(data.toString()));
    }

    private EdmHdpEfSchema getSchema(String tableName) {
        EdmHdpEfSchema schema = schemaMap.get(tableName);
        if (schema == null) {
            schema = new EdmHdpEfSchema(conf, tableName);
            schemaMap.put(tableName, schema);
            logger.info("Created schema: " + schema.toString());
        }
        return schema;
    }
}
