package com.scb.edmhdpef.dataprocessing.trimmedsri;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.log4j.Logger;

import com.scb.edmhdpef.dataprocessing.EdmHdpEfSchema;
import com.scb.edmhdpef.lib.EdmHdpEfDPConstants;

public class TrimmedSRIMapper extends Mapper<LongWritable, Text, Text, Text> {

	private String COL_SEPARATOR = EdmHdpEfDPConstants.COL_SEPARATOR;

	private Configuration conf = null;

	private Map<String, EdmHdpEfSchema> schemaMap = new HashMap<>();
	private static final Logger logger = Logger.getLogger(TrimmedSRIMapper.class);

	@Override
	protected void setup(Context context) throws IOException, InterruptedException {
		logger.info("Setup initiated for task " + context.getTaskAttemptID());
		conf = context.getConfiguration();
		COL_SEPARATOR = conf.get(EdmHdpEfDPConstants.EDMHDPIF_COLSEPARATOR, COL_SEPARATOR);

		logger.info("Setup finished");
	}

	@Override
	protected void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {

		String[] row = value.toString().split(COL_SEPARATOR);
		String tableName = row[0];

		EdmHdpEfSchema schema = getSchema(tableName);

		// Build key for SRI
		StringBuilder keyStr = new StringBuilder("#").append(tableName);
		if (schema.getFunctionalKeyColumns() == null || schema.getFunctionalKeyColumns().isEmpty()) {
			for (int i = 1; i < row.length; i++) {
				keyStr.append("#").append(row[i]);
			}
		} else {
			for (Integer n : schema.getFunctionalKeyColumns()) {
				if (n > row.length - 1) {
					String error = "Incorrect number of columns when retrieving key: cols=" + row.length + " expected: "
							+ n;
					logger.error(error);
					throw new RuntimeException(error);
				}
				keyStr.append("#").append(row[n]);
			}
		}

		context.write(new Text(keyStr.toString()), value);
	}

	private EdmHdpEfSchema getSchema(String tableName) {
		EdmHdpEfSchema schema = schemaMap.get(tableName);
		if (schema == null) {
			schema = new EdmHdpEfSchema(conf, tableName);
			schemaMap.put(tableName, schema);
			logger.info("Created schema: " + schema.toString());
		}
		return schema;
	}
}
