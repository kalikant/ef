package com.scb.edmhdpef.hdfs;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.LocatedFileStatus;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.fs.RemoteIterator;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Counter;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.TaskCounter;
import org.apache.hadoop.mapreduce.lib.input.MultipleInputs;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.LazyOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.MultipleOutputs;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;
import org.apache.log4j.Logger;

import com.scb.edmhdpef.lib.EdmHdpEfDPCommon;

public class HDFSOutputSplit extends Configured implements Tool {

    private static final Logger logger = Logger.getLogger(HDFSOutputSplit.class);

    public static void main(String[] args) throws Exception {
        int res = ToolRunner.run(new Configuration(), new HDFSOutputSplit(), args);
        System.exit(res);
    }

    @Override
    public int run(String[] args) throws Exception {

        Configuration conf = super.getConf();

        String oozieConfigurationLocation = System.getProperty("oozie.action.conf.xml");
        if (oozieConfigurationLocation != null) {
            logger.info("Loading Oozie configuration from " + oozieConfigurationLocation);
            conf.addResource(new Path(oozieConfigurationLocation));
        }
        EdmHdpEfDPCommon.checkRequiredParameters(conf, new String[] { "inputPath", "outputPath"});

        Job job;
        try {
            job = Job.getInstance(conf, "EdmHdpEf HDFS Output Split");
        } catch (IOException e) {
            e.printStackTrace();
            return 1;
        }

        job.setJarByClass(HDFSOutputSplit.class);
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(Text.class);

        job.setMapperClass(HDFSOutputSplitMapper.class);
        job.setReducerClass(HDFSOutputSplitReducer.class);

        // Delete output folder
        FileSystem fileSystem = FileSystem.get(conf);
        Path outputPath = new Path(conf.get("outputPath", "/tmp/edmhdpef/output"));
        logger.info("Output path set to " + outputPath);
        EdmHdpEfDPCommon.deletePath(fileSystem, outputPath + "/");
        job.setOutputFormatClass(LazyOutputFormat.class);
        LazyOutputFormat.setOutputFormatClass(job, TextOutputFormat.class);
        TextOutputFormat.setOutputPath(job, outputPath);

        Path inputPath = new Path(conf.get("inputPath"));
        logger.info("Input path: " + inputPath);

        try {
            // If not a rerun, load all tables
            if (!fileSystem.exists(inputPath)) {
                logger.info("Input path doesn't exist, skipping: " + inputPath);
            }
            // Add files inside the input path
            RemoteIterator<LocatedFileStatus> inputfiles = fileSystem.listFiles(inputPath, true);
            while (inputfiles.hasNext()) {
                MultipleInputs.addInputPath(job, inputfiles.next().getPath(), TextInputFormat.class,
                        HDFSOutputSplitMapper.class);
            }

            MultipleOutputs.addNamedOutput(job, "data", TextOutputFormat.class, NullWritable.class, Text.class);

            if (job.getConfiguration().get(MultipleInputs.DIR_FORMATS) == null) {
                // No input paths
                logger.warn("Job not launched: no input paths");
                return 0;
            }
            boolean jobOk = job.waitForCompletion(true);
            if (!jobOk) {
                return 1;
            }
            // Move from output path to /
            RemoteIterator<LocatedFileStatus> files = fileSystem.listFiles(outputPath, true);
            while (files.hasNext()) {
                LocatedFileStatus file = files.next();
                if ("_SUCCESS".equals(file.getPath().getName())) {
                    continue;
                }
                String newPath = Path.getPathWithoutSchemeAndAuthority(file.getPath()).toString()
                        .substring(Path.getPathWithoutSchemeAndAuthority(outputPath).toString().length());
                System.out.println("Moving file " + file.getPath() + " to " + newPath);
                fileSystem.rename(file.getPath(), new Path(newPath));
            }
            Counter counter = job.getCounters().findCounter(TaskCounter.REDUCE_OUTPUT_RECORDS);
            if (counter == null) {
                System.out.println("OutputRecords=0");
            } else {
                System.out.println("OutputRecords=" + counter.getValue());
            }
            return 0;
        } catch (ClassNotFoundException | IOException | InterruptedException e) {
            e.printStackTrace();
            return 1;
        }
    }
}
