package com.scb.edmhdpef.hdfs;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.log4j.Logger;

import com.scb.edmhdpef.lib.EdmHdpEfDPConstants;

public class HDFSOutputSplitMapper extends Mapper<LongWritable, Text, Text, Text> {

    private String COL_SEPARATOR = EdmHdpEfDPConstants.COL_SEPARATOR;
    private String OUTPUT_COL_SEPARATOR = EdmHdpEfDPConstants.COL_SEPARATOR;

    private Configuration conf = null;

    private static final Logger logger = Logger.getLogger(HDFSOutputSplitMapper.class);

    @Override
    protected void setup(Context context) throws IOException, InterruptedException {
        logger.info("Setup initiated for task " + context.getTaskAttemptID());
        conf = context.getConfiguration();
        COL_SEPARATOR = conf.get(EdmHdpEfDPConstants.EDMHDPIF_COLSEPARATOR, COL_SEPARATOR);
        OUTPUT_COL_SEPARATOR = conf.get(EdmHdpEfDPConstants.EDMHDPIF_OUTPUTCOLSEPARATOR, OUTPUT_COL_SEPARATOR);
        logger.info("Setup finished");
    }

    @Override
    protected void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {

        String[] row = value.toString().split(COL_SEPARATOR, -1);
        String tableName = row[0];
        String lineType = row[1];

        StringBuilder outputKey = new StringBuilder();
        String[] splittedTable = tableName.split("\\.");
        for (String sp : splittedTable) {
            outputKey = outputKey.append("/").append(sp);
        }

        // Ensure to get the Header, Data and Trailer in right order
        if ("H".equals(lineType)) {
            outputKey = outputKey.append("#1");
        } else if ("T".equals(lineType)) {
            outputKey = outputKey.append("#3");
        } else { // Data
            outputKey = outputKey.append("#2");
        }

        StringBuilder outputValue = new StringBuilder();
        for (int i = 1; i < row.length; i++) {
            if (i != 1) {
                outputValue.append(OUTPUT_COL_SEPARATOR);
            }
            outputValue.append(row[i]);
        }

        context.write(new Text(outputKey.toString()), new Text(outputValue.toString()));
    }
}
