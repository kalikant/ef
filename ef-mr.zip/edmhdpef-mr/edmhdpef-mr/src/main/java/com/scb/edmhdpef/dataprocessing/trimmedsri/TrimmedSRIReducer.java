package com.scb.edmhdpef.dataprocessing.trimmedsri;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.log4j.Logger;

import com.scb.edmhdpef.dataprocessing.EdmHdpEfSchema;
import com.scb.edmhdpef.lib.EdmHdpEfDPConstants;

public class TrimmedSRIReducer extends Reducer<Text, Text, NullWritable, Text> {

	/**
	 * Variables initialized at setup
	 */
	private String COL_SEPARATOR = EdmHdpEfDPConstants.COL_SEPARATOR;

	private Configuration conf = null;

	private static final Logger logger = Logger.getLogger(TrimmedSRIReducer.class);

	private Map<String, EdmHdpEfSchema> schemaMap = new HashMap<>();

	@Override
	protected void setup(Context context) throws IOException, InterruptedException {
		logger.info("Setup initiated");

		conf = context.getConfiguration();
		COL_SEPARATOR = conf.get(EdmHdpEfDPConstants.EDMHDPIF_COLSEPARATOR, COL_SEPARATOR);

		logger.info("Setup finished");

	}

	@Override
	protected void reduce(Text key, Iterable<Text> values, Context context) throws IOException, InterruptedException {

		String tableName = key.toString().split("#", -1)[1];

		EdmHdpEfSchema schema = getSchema(tableName);

		Integer timeStamp = schema.getTimestampColumn();
		// Get the last value with this key
		Text valueToWrite = null;
		String ts = null;
		for (Text v : values) {
			if (valueToWrite == null) {
				valueToWrite = new Text(v);
				if (timeStamp != null) {
					ts = v.toString().split(COL_SEPARATOR, -1)[timeStamp];
				}
				continue;
			}
			// TimeStamp column
			if (timeStamp == null || ts.compareTo(v.toString().split(COL_SEPARATOR, -1)[timeStamp]) < 0) {
				valueToWrite = new Text(v);
			}
		}

		if (valueToWrite != null) {
			context.write(NullWritable.get(), valueToWrite);
		}
	}

	private EdmHdpEfSchema getSchema(String tableName) {
		EdmHdpEfSchema schema = schemaMap.get(tableName);
		if (schema == null) {
			schema = new EdmHdpEfSchema(conf, tableName);
			schemaMap.put(tableName, schema);
		}
		return schema;
	}
}
