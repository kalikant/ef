package com.scb.edmhdpef.dataprocessing.hf;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mrunit.mapreduce.ReduceDriver;
import org.junit.Before;
import org.junit.Test;

import com.scb.edmhdpef.lib.EdmHdpEfDPConstants;

public class HeaderAndFooterReducerTest {
    ReduceDriver<Text, Text, NullWritable, Text> reduceDriver;

    @Before
    public void setUp() throws IOException {
        HeaderAndFooterReducer reducer = new HeaderAndFooterReducer();
        reduceDriver = ReduceDriver.newReduceDriver(reducer);
        setConfigParameters(reduceDriver.getConfiguration());
    }

    @Test
    public void testReducerNoChecksum() throws IOException {

        String row1 = "edmhdpef.tableName,0_1,journaltime,transactionid,A,userid,1,2,3";
        String row2 = "edmhdpef.tableName,0_1,journaltime,transactionid,A,userid,4,5,6";
        String outputRow1 = row1.substring(0, row1.indexOf(',')) + ",D," + row1.substring(row1.indexOf(',') + 1);
        String outputRow2 = row2.substring(0, row2.indexOf(',')) + ",D," + row2.substring(row2.indexOf(',') + 1);
        List<Text> inputList = new ArrayList<>();
        inputList.add(new Text(outputRow1));
        inputList.add(new Text(outputRow2));
        reduceDriver.withInput(new Text("#edmhdpef.tableName#Data"), inputList);

        List<Text> trailList = new ArrayList<>();
        trailList.add(new Text("T,1"));
        trailList.add(new Text("T,1"));
        reduceDriver.withInput(new Text("#edmhdpef.tableName#Trail"), trailList);

        reduceDriver.withOutput(NullWritable.get(), buildHeader(reduceDriver.getConfiguration()));
        reduceDriver.withOutput(NullWritable.get(), new Text(outputRow1));
        reduceDriver.withOutput(NullWritable.get(), new Text(outputRow2));
        reduceDriver.withOutput(NullWritable.get(), new Text("edmhdpef.tableName,T,2"));

        reduceDriver.runTest();
    }

    @Test
    public void testReducerOneChecksum_1() throws IOException {
        reduceDriver.getConfiguration().set("edmhdpef.tableName.checksumColumn", "MYCOL7");

        String row1 = "edmhdpef.tableName,0_1,journaltime,transactionid,A,userid,1,2,3";
        String row2 = "edmhdpef.tableName,0_1,journaltime,transactionid,A,userid,4,5,6";
        String outputRow1 = row1.substring(0, row1.indexOf(',')) + ",D," + row1.substring(row1.indexOf(',') + 1);
        String outputRow2 = row2.substring(0, row2.indexOf(',')) + ",D," + row2.substring(row2.indexOf(',') + 1);

        List<Text> inputList = new ArrayList<>();
        inputList.add(new Text(outputRow1));
        inputList.add(new Text(outputRow2));
        reduceDriver.withInput(new Text("#edmhdpef.tableName#Data"), inputList);

        List<Text> trailList = new ArrayList<>();
        trailList.add(new Text("T,1,7,2"));
        trailList.add(new Text("T,1,7,5"));
        reduceDriver.withInput(new Text("#edmhdpef.tableName#Trail"), trailList);

        reduceDriver.withOutput(NullWritable.get(), buildHeader(reduceDriver.getConfiguration()));
        reduceDriver.withOutput(NullWritable.get(), new Text(outputRow1));
        reduceDriver.withOutput(NullWritable.get(), new Text(outputRow2));
        reduceDriver.withOutput(NullWritable.get(), new Text("edmhdpef.tableName,T,2,7,7"));
        reduceDriver.runTest();
    }

    @Test
    public void testReducerOneChecksum_2() throws IOException {

        reduceDriver.getConfiguration().set("edmhdpef.tableName.checksumColumn", "MYCOL8");

        String row1 = "edmhdpef.tableName,0_1,journaltime,transactionid,A,userid,1,2,3";
        String row2 = "edmhdpef.tableName,0_1,journaltime,transactionid,A,userid,4,5,6";
        String outputRow1 = row1.substring(0, row1.indexOf(',')) + ",D," + row1.substring(row1.indexOf(',') + 1);
        String outputRow2 = row2.substring(0, row2.indexOf(',')) + ",D," + row2.substring(row2.indexOf(',') + 1);
        List<Text> inputList = new ArrayList<>();
        inputList.add(new Text(outputRow1));
        inputList.add(new Text(outputRow2));
        reduceDriver.withInput(new Text("#edmhdpef.tableName#Data"), inputList);

        List<Text> trailList = new ArrayList<>();
        trailList.add(new Text("T,1,8,3"));
        trailList.add(new Text("T,1,8,6"));
        reduceDriver.withInput(new Text("#edmhdpef.tableName#Trail"), trailList);

        reduceDriver.withOutput(NullWritable.get(), buildHeader(reduceDriver.getConfiguration()));
        reduceDriver.withOutput(NullWritable.get(), new Text(outputRow1));
        reduceDriver.withOutput(NullWritable.get(), new Text(outputRow2));
        reduceDriver.withOutput(NullWritable.get(), new Text("edmhdpef.tableName,T,2,8,9"));

        reduceDriver.runTest();
    }

    @Test
    public void testReducerOneChecksum_NoCountry() throws IOException {

        reduceDriver.getConfiguration().set("edmhdpef.tableName.checksumColumn", "MYCOL8");
        reduceDriver.getConfiguration().unset("country");

        String row1 = "edmhdpef.tableName,0_1,journaltime,transactionid,A,userid,1,2,3";
        String row2 = "edmhdpef.tableName,0_1,journaltime,transactionid,A,userid,4,5,6";
        String outputRow1 = row1.substring(0, row1.indexOf(',')) + ",D," + row1.substring(row1.indexOf(',') + 1);
        String outputRow2 = row2.substring(0, row2.indexOf(',')) + ",D," + row2.substring(row2.indexOf(',') + 1);
        List<Text> inputList = new ArrayList<>();
        inputList.add(new Text(outputRow1));
        inputList.add(new Text(outputRow2));
        reduceDriver.withInput(new Text("#edmhdpef.tableName#Data"), inputList);

        List<Text> trailList = new ArrayList<>();
        trailList.add(new Text("T,1,8,3"));
        trailList.add(new Text("T,1,8,6"));
        reduceDriver.withInput(new Text("#edmhdpef.tableName#Trail"), trailList);

        reduceDriver.withOutput(NullWritable.get(), buildHeader(reduceDriver.getConfiguration()));
        reduceDriver.withOutput(NullWritable.get(), new Text(outputRow1));
        reduceDriver.withOutput(NullWritable.get(), new Text(outputRow2));
        reduceDriver.withOutput(NullWritable.get(), new Text("edmhdpef.tableName,T,2,8,9"));

        reduceDriver.runTest();
    }

    @Test
    public void testReducerTwoChecksum_1() throws IOException {
        reduceDriver.getConfiguration().set("edmhdpef.tableName.checksumColumn", "MYCOL6,MYCOL7");

        String row1 = "edmhdpef.tableName,0_1,journaltime,transactionid,A,userid,1,2,3";
        String row2 = "edmhdpef.tableName,0_1,journaltime,transactionid,A,userid,4,5,6";
        String outputRow1 = row1.substring(0, row1.indexOf(',')) + ",D," + row1.substring(row1.indexOf(',') + 1);
        String outputRow2 = row2.substring(0, row2.indexOf(',')) + ",D," + row2.substring(row2.indexOf(',') + 1);

        List<Text> inputList = new ArrayList<>();
        inputList.add(new Text(outputRow1));
        inputList.add(new Text(outputRow2));
        reduceDriver.withInput(new Text("#edmhdpef.tableName#Data"), inputList);

        List<Text> trailList = new ArrayList<>();
        trailList.add(new Text("T,1,6,1,7,2"));
        trailList.add(new Text("T,1,6,4,7,5"));
        reduceDriver.withInput(new Text("#edmhdpef.tableName#Trail"), trailList);

        reduceDriver.withOutput(NullWritable.get(), buildHeader(reduceDriver.getConfiguration()));
        reduceDriver.withOutput(NullWritable.get(), new Text(outputRow1));
        reduceDriver.withOutput(NullWritable.get(), new Text(outputRow2));
        reduceDriver.withOutput(NullWritable.get(), new Text("edmhdpef.tableName,T,2,6,5,7,7"));

        reduceDriver.runTest();
    }

    @Test
    public void testReducerTwoChecksum_2() throws IOException {

        reduceDriver.getConfiguration().set("edmhdpef.tableName.checksumColumn", "MYCOL7,MYCOL8");

        String row1 = "edmhdpef.tableName,0_1,journaltime,transactionid,A,userid,1,2,3";
        String row2 = "edmhdpef.tableName,0_1,journaltime,transactionid,A,userid,4,5,6";
        String outputRow1 = row1.substring(0, row1.indexOf(',')) + ",D," + row1.substring(row1.indexOf(',') + 1);
        String outputRow2 = row2.substring(0, row2.indexOf(',')) + ",D," + row2.substring(row2.indexOf(',') + 1);
        List<Text> inputList = new ArrayList<>();
        inputList.add(new Text(outputRow1));
        inputList.add(new Text(outputRow2));
        reduceDriver.withInput(new Text("#edmhdpef.tableName#Data"), inputList);

        List<Text> trailList = new ArrayList<>();
        trailList.add(new Text("T,1,7,2,8,3"));
        trailList.add(new Text("T,1,7,5,8,6"));
        reduceDriver.withInput(new Text("#edmhdpef.tableName#Trail"), trailList);

        reduceDriver.withOutput(NullWritable.get(), buildHeader(reduceDriver.getConfiguration()));
        reduceDriver.withOutput(NullWritable.get(), new Text(outputRow1));
        reduceDriver.withOutput(NullWritable.get(), new Text(outputRow2));
        reduceDriver.withOutput(NullWritable.get(), new Text("edmhdpef.tableName,T,2,7,7,8,9"));
        reduceDriver.runTest();
    }

    private void setConfigParameters(Configuration conf) {

        conf.set("edmhdpef.tableName.schema", "MYCOL,MYCOL2,MYCOL3,MYCOL4,MYCOL5,MYCOL6,MYCOL7,MYCOL8");
        conf.set(EdmHdpEfDPConstants.EDMHDPIF_COLSEPARATOR, ",");
        conf.set(EdmHdpEfDPConstants.EDMHDPIF_OUTPUTCOLSEPARATOR, ",");
        conf.set("businessday", "2015-01-01");
        conf.set("country", "sg");
    }

    private Text buildHeader(Configuration conf) {

        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
        String runDate = sdf.format(Calendar.getInstance().getTime());

        String header = "edmhdpef.tableName,H,1.0,1.0,";
        if (conf.get("country") == null) {
            header = header + "ALL";
        } else {
            header = header + conf.get("country");
        }
        header = header + "," + conf.get("businessday") + "," + runDate + ",1";

        return new Text(header);
    }
}
