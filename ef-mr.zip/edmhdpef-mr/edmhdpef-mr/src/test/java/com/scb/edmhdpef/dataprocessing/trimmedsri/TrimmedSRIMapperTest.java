package com.scb.edmhdpef.dataprocessing.trimmedsri;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mrunit.mapreduce.MapDriver;
import org.junit.Before;
import org.junit.Test;

import com.scb.edmhdpef.lib.EdmHdpEfDPConstants;

public class TrimmedSRIMapperTest {
	MapDriver<LongWritable, Text, Text, Text> mapDriver;

	private LongWritable longWritable = new LongWritable(1L);

	@Before
	public void setUp() throws IOException {
		TrimmedSRIMapper mapper = new TrimmedSRIMapper();
		mapDriver = MapDriver.newMapDriver(mapper);
		setConfigParameters(mapDriver.getConfiguration());
	}

	@Test
	public void testMapperOneKeyOneValue() throws IOException {

		String row1 = "edmhdpef.tableName,0_1,2015-01-01T02:00,transactionid,A,userid,id1,2,3";
		String row2 = "edmhdpef.tableName,0_1,2015-01-01T02:30,transactionid,A,userid,id1,5,6";
		mapDriver.withInput(longWritable, new Text(row1));
		mapDriver.withInput(longWritable, new Text(row2));
		mapDriver.addOutput(new Text("#edmhdpef.tableName#id1"), new Text(row1));
		mapDriver.addOutput(new Text("#edmhdpef.tableName#id1"), new Text(row2));
		mapDriver.runTest();
	}

	@Test
	public void testMapperOneKeyTwoValue() throws IOException {

		String row1 = "edmhdpef.tableName,0_1,2015-01-01T02:00,transactionid,A,userid,id1,2,3";
		String row2 = "edmhdpef.tableName,0_1,2015-01-01T02:30,transactionid,A,userid,id1,5,6";
		String row3 = "edmhdpef.tableName,0_1,2015-01-01T02:00,transactionid,A,userid,id2,2,3";
		String row4 = "edmhdpef.tableName,0_1,2015-01-01T02:30,transactionid,A,userid,id2,5,6";
		mapDriver.withInput(longWritable, new Text(row1));
		mapDriver.withInput(longWritable, new Text(row2));
		mapDriver.withInput(longWritable, new Text(row3));
		mapDriver.withInput(longWritable, new Text(row4));
		mapDriver.addOutput(new Text("#edmhdpef.tableName#id1"), new Text(row1));
		mapDriver.addOutput(new Text("#edmhdpef.tableName#id1"), new Text(row2));
		mapDriver.addOutput(new Text("#edmhdpef.tableName#id2"), new Text(row3));
		mapDriver.addOutput(new Text("#edmhdpef.tableName#id2"), new Text(row4));
		mapDriver.runTest();
	}

	@Test
	public void testMapperTwoKeyOneValue() throws IOException {
		mapDriver.getConfiguration().set("edmhdpef.tableName.functionalKeyColumns", "MYCOL6, MYCOL7");

		String row1 = "edmhdpef.tableName,0_1,2015-01-01T02:00,transactionid,A,userid,id1,sc1,3";
		String row2 = "edmhdpef.tableName,0_1,2015-01-01T02:30,transactionid,A,userid,id1,sc1,6";
		mapDriver.withInput(longWritable, new Text(row1));
		mapDriver.withInput(longWritable, new Text(row2));
		mapDriver.addOutput(new Text("#edmhdpef.tableName#id1#sc1"), new Text(row1));
		mapDriver.addOutput(new Text("#edmhdpef.tableName#id1#sc1"), new Text(row2));
		mapDriver.runTest();
	}

	@Test
	public void testMapperTwoKeyTwoValue() throws IOException {
		mapDriver.getConfiguration().set("edmhdpef.tableName.functionalKeyColumns", "MYCOL6, MYCOL7");

		String row1 = "edmhdpef.tableName,0_1,2015-01-01T02:00,transactionid,A,userid,id1,sc1,3";
		String row2 = "edmhdpef.tableName,0_1,2015-01-01T02:30,transactionid,A,userid,id1,sc1,6";
		String row3 = "edmhdpef.tableName,0_1,2015-01-01T02:00,transactionid,A,userid,id2,sc1,3";
		String row4 = "edmhdpef.tableName,0_1,2015-01-01T02:30,transactionid,A,userid,id2,sc1,6";
		mapDriver.withInput(longWritable, new Text(row1));
		mapDriver.withInput(longWritable, new Text(row2));
		mapDriver.withInput(longWritable, new Text(row3));
		mapDriver.withInput(longWritable, new Text(row4));
		mapDriver.addOutput(new Text("#edmhdpef.tableName#id1#sc1"), new Text(row1));
		mapDriver.addOutput(new Text("#edmhdpef.tableName#id1#sc1"), new Text(row2));
		mapDriver.addOutput(new Text("#edmhdpef.tableName#id2#sc1"), new Text(row3));
		mapDriver.addOutput(new Text("#edmhdpef.tableName#id2#sc1"), new Text(row4));
		mapDriver.runTest();
	}

	@Test
	public void testMapperTwoKeyFourValueTwoTables() throws IOException {
		mapDriver.getConfiguration().set("edmhdpef.tableName.functionalKeyColumns", "MYCOL6, MYCOL7");
		mapDriver.getConfiguration().set("edmhdpef.tableNameb.functionalKeyColumns", "MYCOL7, MYCOL6");

		String row1 = "edmhdpef.tableName,0_1,2015-01-01T02:00,transactionid,A,userid,id1,sc1,3";
		String row2 = "edmhdpef.tableName,0_1,2015-01-01T02:30,transactionid,A,userid,id1,sc1,6";
		String row3 = "edmhdpef.tableName,0_1,2015-01-01T02:00,transactionid,A,userid,id2,sc1,3";
		String row4 = "edmhdpef.tableName,0_1,2015-01-01T02:30,transactionid,A,userid,id2,sc1,6";
		String row1b = "edmhdpef.tableNameb,0_1,2015-01-01T02:00,transactionid,A,userid,id3,sc2,3";
		String row2b = "edmhdpef.tableNameb,0_1,2015-01-01T02:30,transactionid,A,userid,id3,sc2,6";
		String row3b = "edmhdpef.tableNameb,0_1,2015-01-01T02:00,transactionid,A,userid,id4,sc2,3";
		String row4b = "edmhdpef.tableNameb,0_1,2015-01-01T02:30,transactionid,A,userid,id4,sc2,6";
		mapDriver.withInput(longWritable, new Text(row1));
		mapDriver.withInput(longWritable, new Text(row2));
		mapDriver.withInput(longWritable, new Text(row3));
		mapDriver.withInput(longWritable, new Text(row4));
		mapDriver.withInput(longWritable, new Text(row1b));
		mapDriver.withInput(longWritable, new Text(row2b));
		mapDriver.withInput(longWritable, new Text(row3b));
		mapDriver.withInput(longWritable, new Text(row4b));
		mapDriver.addOutput(new Text("#edmhdpef.tableName#id1#sc1"), new Text(row1));
		mapDriver.addOutput(new Text("#edmhdpef.tableName#id1#sc1"), new Text(row2));
		mapDriver.addOutput(new Text("#edmhdpef.tableName#id2#sc1"), new Text(row3));
		mapDriver.addOutput(new Text("#edmhdpef.tableName#id2#sc1"), new Text(row4));
		mapDriver.addOutput(new Text("#edmhdpef.tableNameb#sc2#id3"), new Text(row1b));
		mapDriver.addOutput(new Text("#edmhdpef.tableNameb#sc2#id3"), new Text(row2b));
		mapDriver.addOutput(new Text("#edmhdpef.tableNameb#sc2#id4"), new Text(row3b));
		mapDriver.addOutput(new Text("#edmhdpef.tableNameb#sc2#id4"), new Text(row4b));

		mapDriver.runTest();
	}

	private void setConfigParameters(Configuration conf) {
		conf.set("edmhdpef.tableName.schema", "MYCOL,MYCOL2,MYCOL3,MYCOL4,MYCOL5,MYCOL6,MYCOL7,MYCOL8");
		conf.set("edmhdpef.tableName.timestampColumn", "MYCOL2");
		conf.set("edmhdpef.tableName.functionalKeyColumns", "MYCOL6");

		conf.set("edmhdpef.tableNameb.schema", "MYCOL,MYCOL2,MYCOL3,MYCOL4,MYCOL5,MYCOL6,MYCOL7,MYCOL8");
		conf.set("edmhdpef.tableNameb.timestampColumn", "MYCOL2");
		conf.set("edmhdpef.tableNameb.functionalKeyColumns", "MYCOL6");
		conf.set(EdmHdpEfDPConstants.EDMHDPIF_COLSEPARATOR, ",");
	}
}
