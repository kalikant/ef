package com.scb.edmhdpef.hdfs;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mrunit.mapreduce.MapDriver;
import org.junit.Before;
import org.junit.Test;

import com.scb.edmhdpef.lib.EdmHdpEfDPConstants;

public class HDFSOutputSplitMapperTest {

    MapDriver<LongWritable, Text, Text, Text> mapDriver;

    private LongWritable longWritable = new LongWritable(1L);

    @Before
    public void setUp() throws IOException {
        HDFSOutputSplitMapper mapper = new HDFSOutputSplitMapper();
        mapDriver = MapDriver.newMapDriver(mapper);
        setConfigParameters(mapDriver.getConfiguration());
    }

    @Test
    public void testMapperNoChecksum() throws IOException {

        String rowH = "H,h1,h2,h3";
        String rowD = "D,0_1,journaltime,transactionid,A,userid,1,2,3";
        String rowT = "T,t1,t2,t3";

        mapDriver.withInput(longWritable, new Text("edmhdpef.tableName," + rowH));
        mapDriver.withInput(longWritable, new Text("edmhdpef.tableName," + rowD));
        mapDriver.withInput(longWritable, new Text("edmhdpef.tableName," + rowD));
        mapDriver.withInput(longWritable, new Text("edmhdpef.tableName," + rowT));

        mapDriver.withInput(longWritable, new Text("edmhdpef.tableName2," + rowH));
        mapDriver.withInput(longWritable, new Text("edmhdpef.tableName2," + rowD));
        mapDriver.withInput(longWritable, new Text("edmhdpef.tableName2," + rowD));
        mapDriver.withInput(longWritable, new Text("edmhdpef.tableName2," + rowD));
        mapDriver.withInput(longWritable, new Text("edmhdpef.tableName2," + rowD));
        mapDriver.withInput(longWritable, new Text("edmhdpef.tableName2," + rowT));

        mapDriver.withInput(longWritable, new Text("edmhdpef.tableName3," + rowH));
        mapDriver.withInput(longWritable, new Text("edmhdpef.tableName3," + rowD));
        mapDriver.withInput(longWritable, new Text("edmhdpef.tableName3," + rowD));
        mapDriver.withInput(longWritable, new Text("edmhdpef.tableName3," + rowD));
        mapDriver.withInput(longWritable, new Text("edmhdpef.tableName3," + rowT));

        mapDriver.withInput(longWritable, new Text("edmhdpef.tableName4," + rowH));
        mapDriver.withInput(longWritable, new Text("edmhdpef.tableName4," + rowD));
        mapDriver.withInput(longWritable, new Text("edmhdpef.tableName4," + rowT));

        mapDriver.addOutput(new Text("/edmhdpef/tableName#1"), new Text(rowH));
        mapDriver.addOutput(new Text("/edmhdpef/tableName#2"), new Text(rowD));
        mapDriver.addOutput(new Text("/edmhdpef/tableName#2"), new Text(rowD));
        mapDriver.addOutput(new Text("/edmhdpef/tableName#3"), new Text(rowT));

        mapDriver.addOutput(new Text("/edmhdpef/tableName2#1"), new Text(rowH));
        mapDriver.addOutput(new Text("/edmhdpef/tableName2#2"), new Text(rowD));
        mapDriver.addOutput(new Text("/edmhdpef/tableName2#2"), new Text(rowD));
        mapDriver.addOutput(new Text("/edmhdpef/tableName2#2"), new Text(rowD));
        mapDriver.addOutput(new Text("/edmhdpef/tableName2#2"), new Text(rowD));
        mapDriver.addOutput(new Text("/edmhdpef/tableName2#3"), new Text(rowT));

        mapDriver.addOutput(new Text("/edmhdpef/tableName3#1"), new Text(rowH));
        mapDriver.addOutput(new Text("/edmhdpef/tableName3#2"), new Text(rowD));
        mapDriver.addOutput(new Text("/edmhdpef/tableName3#2"), new Text(rowD));
        mapDriver.addOutput(new Text("/edmhdpef/tableName3#2"), new Text(rowD));
        mapDriver.addOutput(new Text("/edmhdpef/tableName3#3"), new Text(rowT));

        mapDriver.addOutput(new Text("/edmhdpef/tableName4#1"), new Text(rowH));
        mapDriver.addOutput(new Text("/edmhdpef/tableName4#2"), new Text(rowD));
        mapDriver.addOutput(new Text("/edmhdpef/tableName4#3"), new Text(rowT));

        mapDriver.runTest();
    }

    private void setConfigParameters(Configuration conf) {
        conf.set(EdmHdpEfDPConstants.EDMHDPIF_COLSEPARATOR, ",");
        conf.set(EdmHdpEfDPConstants.EDMHDPIF_OUTPUTCOLSEPARATOR, ",");
    }
}
