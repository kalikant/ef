package com.scb.edmhdpef.dataprocessing.hf;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mrunit.mapreduce.MapDriver;
import org.junit.Before;
import org.junit.Test;

import com.scb.edmhdpef.lib.EdmHdpEfDPConstants;

public class HeaderAndFooterMapperTest {
	MapDriver<LongWritable, Text, Text, Text> mapDriver;

	private LongWritable longWritable = new LongWritable(1L);

	@Before
	public void setUp() throws IOException {
		HeaderAndFooterMapper mapper = new HeaderAndFooterMapper();
		mapDriver = MapDriver.newMapDriver(mapper);
		setConfigParameters(mapDriver.getConfiguration());
	}

	@Test
	public void testMapperNoChecksum() throws IOException {

		String row1 = "edmhdpef.tableName,0_1,journaltime,transactionid,A,userid,1,2,3";
		String row2 = "edmhdpef.tableName,0_1,journaltime,transactionid,A,userid,4,5,6";
		String outputRow1 = row1.substring(0, row1.indexOf(',')) + ",D," + row1.substring(row1.indexOf(',') + 1);
		String outputRow2 = row2.substring(0, row2.indexOf(',')) + ",D," + row2.substring(row2.indexOf(',') + 1);
		mapDriver.withInput(longWritable, new Text(row1));
		mapDriver.withInput(longWritable, new Text(row2));
		mapDriver.addOutput(new Text("#edmhdpef.tableName#Trail"), new Text("T,1"));
		mapDriver.addOutput(new Text("#edmhdpef.tableName#Data"), new Text(outputRow1));
		mapDriver.addOutput(new Text("#edmhdpef.tableName#Trail"), new Text("T,1"));
		mapDriver.addOutput(new Text("#edmhdpef.tableName#Data"), new Text(outputRow2));
		mapDriver.runTest();
	}

	@Test
	public void testMapperOneChecksum_1() throws IOException {
		mapDriver.getConfiguration().set("edmhdpef.tableName.checksumColumn", "MYCOL7");

		String row1 = "edmhdpef.tableName,0_1,journaltime,transactionid,A,userid,1,2,3";
		String row2 = "edmhdpef.tableName,0_1,journaltime,transactionid,A,userid,4,5,6";
		String outputRow1 = row1.substring(0, row1.indexOf(',')) + ",D," + row1.substring(row1.indexOf(',') + 1);
		String outputRow2 = row2.substring(0, row2.indexOf(',')) + ",D," + row2.substring(row2.indexOf(',') + 1);
		mapDriver.withInput(longWritable, new Text(row1));
		mapDriver.withInput(longWritable, new Text(row2));
		mapDriver.addOutput(new Text("#edmhdpef.tableName#Trail"), new Text("T,1,7,2"));
		mapDriver.addOutput(new Text("#edmhdpef.tableName#Data"), new Text(outputRow1));
		mapDriver.addOutput(new Text("#edmhdpef.tableName#Trail"), new Text("T,1,7,5"));
		mapDriver.addOutput(new Text("#edmhdpef.tableName#Data"), new Text(outputRow2));
		mapDriver.runTest();
	}

	@Test
	public void testMapperOneChecksum_2() throws IOException {

		mapDriver.getConfiguration().set("edmhdpef.tableName.checksumColumn", "MYCOL8");

		String row1 = "edmhdpef.tableName,0_1,journaltime,transactionid,A,userid,1,2,3";
		String row2 = "edmhdpef.tableName,0_1,journaltime,transactionid,A,userid,4,5,6";
		String outputRow1 = row1.substring(0, row1.indexOf(',')) + ",D," + row1.substring(row1.indexOf(',') + 1);
		String outputRow2 = row2.substring(0, row2.indexOf(',')) + ",D," + row2.substring(row2.indexOf(',') + 1);
		mapDriver.withInput(longWritable, new Text(row1));
		mapDriver.withInput(longWritable, new Text(row2));
		mapDriver.addOutput(new Text("#edmhdpef.tableName#Trail"), new Text("T,1,8,3"));
		mapDriver.addOutput(new Text("#edmhdpef.tableName#Data"), new Text(outputRow1));
		mapDriver.addOutput(new Text("#edmhdpef.tableName#Trail"), new Text("T,1,8,6"));
		mapDriver.addOutput(new Text("#edmhdpef.tableName#Data"), new Text(outputRow2));
		mapDriver.runTest();
	}

	@Test
	public void testMapperTwoChecksum_1() throws IOException {
		mapDriver.getConfiguration().set("edmhdpef.tableName.checksumColumn", "MYCOL6,MYCOL7");

		String row1 = "edmhdpef.tableName,0_1,journaltime,transactionid,A,userid,1,2,3";
		String row2 = "edmhdpef.tableName,0_1,journaltime,transactionid,A,userid,4,5,6";
		String outputRow1 = row1.substring(0, row1.indexOf(',')) + ",D," + row1.substring(row1.indexOf(',') + 1);
		String outputRow2 = row2.substring(0, row2.indexOf(',')) + ",D," + row2.substring(row2.indexOf(',') + 1);
		mapDriver.withInput(longWritable, new Text(row1));
		mapDriver.withInput(longWritable, new Text(row2));
		mapDriver.addOutput(new Text("#edmhdpef.tableName#Trail"), new Text("T,1,6,1,7,2"));
		mapDriver.addOutput(new Text("#edmhdpef.tableName#Data"), new Text(outputRow1));
		mapDriver.addOutput(new Text("#edmhdpef.tableName#Trail"), new Text("T,1,6,4,7,5"));
		mapDriver.addOutput(new Text("#edmhdpef.tableName#Data"), new Text(outputRow2));
		mapDriver.runTest();
	}

	@Test
	public void testMapperTwoChecksum_2() throws IOException {

		mapDriver.getConfiguration().set("edmhdpef.tableName.checksumColumn", "MYCOL7,MYCOL8");

		String row1 = "edmhdpef.tableName,0_1,journaltime,transactionid,A,userid,1,2,3";
		String row2 = "edmhdpef.tableName,0_1,journaltime,transactionid,A,userid,4,5,6";
		String outputRow1 = row1.substring(0, row1.indexOf(',')) + ",D," + row1.substring(row1.indexOf(',') + 1);
		String outputRow2 = row2.substring(0, row2.indexOf(',')) + ",D," + row2.substring(row2.indexOf(',') + 1);
		mapDriver.withInput(longWritable, new Text(row1));
		mapDriver.withInput(longWritable, new Text(row2));
		mapDriver.addOutput(new Text("#edmhdpef.tableName#Trail"), new Text("T,1,7,2,8,3"));
		mapDriver.addOutput(new Text("#edmhdpef.tableName#Data"), new Text(outputRow1));
		mapDriver.addOutput(new Text("#edmhdpef.tableName#Trail"), new Text("T,1,7,5,8,6"));
		mapDriver.addOutput(new Text("#edmhdpef.tableName#Data"), new Text(outputRow2));
		mapDriver.runTest();
	}

	private void setConfigParameters(Configuration conf) {
		conf.set("edmhdpef.tableName.schema", "MYCOL,MYCOL2,MYCOL3,MYCOL4,MYCOL5,MYCOL6,MYCOL7,MYCOL8");
		conf.set(EdmHdpEfDPConstants.EDMHDPIF_COLSEPARATOR, ",");
	}
}
