package com.scb.edmhdpef.dataprocessing.trimmedsri;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mrunit.mapreduce.ReduceDriver;
import org.junit.Before;
import org.junit.Test;

import com.scb.edmhdpef.lib.EdmHdpEfDPConstants;

public class TrimmedSRIReducerTest {
	ReduceDriver<Text, Text, NullWritable, Text> reduceDriver;

	@Before
	public void setUp() throws IOException {
		TrimmedSRIReducer reducer = new TrimmedSRIReducer();
		reduceDriver = ReduceDriver.newReduceDriver(reducer);
		setConfigParameters(reduceDriver.getConfiguration());
	}

	@Test
	public void testMapperOneKeyOneValue() throws IOException {

		String row1 = "edmhdpef.tableName,0_1,2015-01-01T02:00,transactionid,A,userid,id1,2,3";
		String row2 = "edmhdpef.tableName,0_1,2015-01-01T02:30,transactionid,A,userid,id1,5,6";

		List<Text> input = new ArrayList<>();
		input.add(new Text(row1));
		input.add(new Text(row2));
		reduceDriver.withInput(new Text("#edmhdpef.tableName#id1"), input);

		reduceDriver.withOutput(NullWritable.get(), new Text(row2));

		reduceDriver.runTest();
	}

	@Test
	public void testMapperOneKeyTwoValue() throws IOException {

		String row1 = "edmhdpef.tableName,0_1,2015-01-01T02:00,transactionid,A,userid,id1,2,3";
		String row2 = "edmhdpef.tableName,0_1,2015-01-01T02:30,transactionid,A,userid,id1,5,6";
		String row3 = "edmhdpef.tableName,0_1,2015-01-01T02:00,transactionid,A,userid,id2,2,3";
		String row4 = "edmhdpef.tableName,0_1,2015-01-01T02:30,transactionid,A,userid,id2,5,6";

		List<Text> input = new ArrayList<>();
		input.add(new Text(row1));
		input.add(new Text(row2));
		reduceDriver.withInput(new Text("#edmhdpef.tableName#id1"), input);

		List<Text> input2 = new ArrayList<>();
		input2.add(new Text(row3));
		input2.add(new Text(row4));
		reduceDriver.withInput(new Text("#edmhdpef.tableName#id2"), input2);

		reduceDriver.withOutput(NullWritable.get(), new Text(row2));
		reduceDriver.withOutput(NullWritable.get(), new Text(row4));

		reduceDriver.runTest();
	}

	@Test
	public void testMapperTwoKeyOneValue() throws IOException {
		reduceDriver.getConfiguration().set("edmhdpef.tableName.functionalKeyColumns", "MYCOL6, MYCOL7");

		String row1 = "edmhdpef.tableName,0_1,2015-01-01T02:00,transactionid,A,userid,id1,sc1,3";
		String row2 = "edmhdpef.tableName,0_1,2015-01-01T02:30,transactionid,A,userid,id1,sc1,6";

		List<Text> input = new ArrayList<>();
		input.add(new Text(row2));
		input.add(new Text(row1));
		reduceDriver.withInput(new Text("#edmhdpef.tableName#id1#sc1"), input);

		reduceDriver.withOutput(NullWritable.get(), new Text(row2));

		reduceDriver.runTest();
	}

	@Test
	public void testMapperTwoKeyTwoValue() throws IOException {
		reduceDriver.getConfiguration().set("edmhdpef.tableName.functionalKeyColumns", "MYCOL6, MYCOL7");

		String row1 = "edmhdpef.tableName,0_1,2015-01-01T02:00,transactionid,A,userid,id1,sc1,3";
		String row2 = "edmhdpef.tableName,0_1,2015-01-01T02:30,transactionid,A,userid,id1,sc1,6";
		String row3 = "edmhdpef.tableName,0_1,2015-01-01T02:00,transactionid,A,userid,id2,sc1,3";
		String row4 = "edmhdpef.tableName,0_1,2015-01-01T02:30,transactionid,A,userid,id2,sc1,6";

		List<Text> input = new ArrayList<>();
		input.add(new Text(row1));
		input.add(new Text(row2));
		reduceDriver.withInput(new Text("#edmhdpef.tableName#id1#sc1"), input);

		List<Text> input2 = new ArrayList<>();
		input2.add(new Text(row4));
		input2.add(new Text(row3));
		reduceDriver.withInput(new Text("#edmhdpef.tableName#id2#sc1"), input2);

		reduceDriver.withOutput(NullWritable.get(), new Text(row2));
		reduceDriver.withOutput(NullWritable.get(), new Text(row4));

		reduceDriver.runTest();
	}

	@Test
	public void testMapperTwoKeyFourValueTwoTables() throws IOException {
		reduceDriver.getConfiguration().set("edmhdpef.tableName.functionalKeyColumns", "MYCOL6, MYCOL7");
		reduceDriver.getConfiguration().set("edmhdpef.tableNameb.functionalKeyColumns", "MYCOL7, MYCOL6");

		String row1 = "edmhdpef.tableName,0_1,2015-01-01T02:00,transactionid,A,userid,id1,sc1,3";
		String row2 = "edmhdpef.tableName,0_1,2015-01-01T02:30,transactionid,A,userid,id1,sc1,6";
		String row3 = "edmhdpef.tableName,0_1,2015-01-01T02:00,transactionid,A,userid,id2,sc1,3";
		String row4 = "edmhdpef.tableName,0_1,2015-01-01T02:30,transactionid,A,userid,id2,sc1,6";

		String row1b = "edmhdpef.tableNameb,0_1,2015-01-01T02:00,transactionid,A,userid,id3,sc2,3";
		String row2b = "edmhdpef.tableNameb,0_1,2015-01-01T02:30,transactionid,A,userid,id3,sc2,6";
		String row3b = "edmhdpef.tableNameb,0_1,2015-01-01T02:00,transactionid,A,userid,id4,sc2,3";
		String row4b = "edmhdpef.tableNameb,0_1,2015-01-01T02:30,transactionid,A,userid,id4,sc2,6";

		List<Text> input = new ArrayList<>();
		input.add(new Text(row1));
		input.add(new Text(row2));
		reduceDriver.withInput(new Text("#edmhdpef.tableName#id1#sc1"), input);

		List<Text> input2 = new ArrayList<>();
		input2.add(new Text(row4));
		input2.add(new Text(row3));
		reduceDriver.withInput(new Text("#edmhdpef.tableName#id2#sc1"), input2);

		List<Text> input3 = new ArrayList<>();
		input3.add(new Text(row1b));
		input3.add(new Text(row2b));
		reduceDriver.withInput(new Text("#edmhdpef.tableName#sc2#id3"), input3);

		List<Text> input4 = new ArrayList<>();
		input4.add(new Text(row4b));
		input4.add(new Text(row3b));
		reduceDriver.withInput(new Text("#edmhdpef.tableName#sc2#id4"), input4);

		reduceDriver.withOutput(NullWritable.get(), new Text(row2));
		reduceDriver.withOutput(NullWritable.get(), new Text(row4));
		reduceDriver.withOutput(NullWritable.get(), new Text(row2b));
		reduceDriver.withOutput(NullWritable.get(), new Text(row4b));

		reduceDriver.runTest();
	}

	private void setConfigParameters(Configuration conf) {
		conf.set("edmhdpef.tableName.schema", "MYCOL,MYCOL2,MYCOL3,MYCOL4,MYCOL5,MYCOL6,MYCOL7,MYCOL8");
		conf.set("edmhdpef.tableName.timestampColumn", "MYCOL2");
		conf.set("edmhdpef.tableName.functionalKeyColumns", "MYCOL6");

		conf.set("edmhdpef.tableNameb.schema", "MYCOL,MYCOL2,MYCOL3,MYCOL4,MYCOL5,MYCOL6,MYCOL7,MYCOL8");
		conf.set("edmhdpef.tableNameb.timestampColumn", "MYCOL2");
		conf.set("edmhdpef.tableNameb.functionalKeyColumns", "MYCOL7");

		conf.set(EdmHdpEfDPConstants.EDMHDPIF_COLSEPARATOR, ",");
	}
}
