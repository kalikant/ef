package com.scb.edmhdpef.hdfs;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mrunit.mapreduce.ReduceDriver;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.scb.edmhdpef.lib.EdmHdpEfDPConstants;

@PrepareForTest({ HDFSOutputSplitReducer.class })
@RunWith(PowerMockRunner.class)
public class HDFSOutputSplitReducerTest {
	ReduceDriver<Text, Text, NullWritable, Text> reduceDriver;

	@Before
	public void setUp() throws IOException {
		HDFSOutputSplitReducer reducer = new HDFSOutputSplitReducer();
		reduceDriver = ReduceDriver.newReduceDriver(reducer);
		setConfigParameters(reduceDriver.getConfiguration());
	}

	@Test
	public void testMapperOneFile() throws IOException {

		String rowH = "H,h1,h2,h3";
		String rowD = "D,0_1,journaltime,transactionid,A,userid,1,2,3";
		String rowT = "T,t1,t2,t3";

		List<Text> inputH = new ArrayList<>();
		List<Text> inputD = new ArrayList<>();
		List<Text> inputT = new ArrayList<>();
		inputH.add(new Text(rowH));
		inputD.add(new Text(rowD));
		inputD.add(new Text(rowD));
		inputT.add(new Text(rowT));

		reduceDriver.withInput(new Text("/edmhdpef/tableName#1"), inputH);
		reduceDriver.withInput(new Text("/edmhdpef/tableName#2"), inputD);
		reduceDriver.withInput(new Text("/edmhdpef/tableName#3"), inputT);

		reduceDriver.withMultiOutput("data", NullWritable.get(), new Text(rowH));
		reduceDriver.withMultiOutput("data", NullWritable.get(), new Text(rowD));
		reduceDriver.withMultiOutput("data", NullWritable.get(), new Text(rowD));
		reduceDriver.withMultiOutput("data", NullWritable.get(), new Text(rowT));

		reduceDriver.runTest();
	}

	@Test
	public void testMapperTwoFile() throws IOException {

		String rowH = "H,h1,h2,h3";
		String rowD = "D,0_1,journaltime,transactionid,A,userid,1,2,3";
		String rowT = "T,t1,t2,t3";

		List<Text> inputH = new ArrayList<>();
		List<Text> inputD = new ArrayList<>();
		List<Text> inputT = new ArrayList<>();
		inputH.add(new Text(rowH));
		inputD.add(new Text(rowD));
		inputD.add(new Text(rowD));
		inputT.add(new Text(rowT));

		reduceDriver.withInput(new Text("/edmhdpef/tableName#1"), inputH);
		reduceDriver.withInput(new Text("/edmhdpef/tableName#2"), inputD);
		reduceDriver.withInput(new Text("/edmhdpef/tableName#3"), inputT);

		reduceDriver.withInput(new Text("/edmhdpef/tableName2#1"), inputH);
		reduceDriver.withInput(new Text("/edmhdpef/tableName2#2"), inputD);
		reduceDriver.withInput(new Text("/edmhdpef/tableName2#3"), inputT);

		reduceDriver.withMultiOutput("data", NullWritable.get(), new Text(rowH));
		reduceDriver.withMultiOutput("data", NullWritable.get(), new Text(rowD));
		reduceDriver.withMultiOutput("data", NullWritable.get(), new Text(rowD));
		reduceDriver.withMultiOutput("data", NullWritable.get(), new Text(rowT));

		reduceDriver.withMultiOutput("data", NullWritable.get(), new Text(rowH));
		reduceDriver.withMultiOutput("data", NullWritable.get(), new Text(rowD));
		reduceDriver.withMultiOutput("data", NullWritable.get(), new Text(rowD));
		reduceDriver.withMultiOutput("data", NullWritable.get(), new Text(rowT));

		reduceDriver.runTest();
	}

	private void setConfigParameters(Configuration conf) {
		conf.set(EdmHdpEfDPConstants.EDMHDPIF_COLSEPARATOR, ",");
	}
}
