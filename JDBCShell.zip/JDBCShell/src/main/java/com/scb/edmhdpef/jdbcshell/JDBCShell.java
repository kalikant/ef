package com.scb.edmhdpef.jdbcshell;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.io.IOUtils;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;

/**
 * Library requirements: - commons-cli, commons-logging, commons-collections,
 * commons-io, commons-lang, commons-configuration - guava - hadoop-2.4 -
 * hadoop-hdfs-2.4 - log4j, slf4j-api and slf4j-log4j - protobuf-2.5 - the JDBC
 * drivers and related classes for a database (e.g. tdgssconfig and terajdbc for
 * Teradata)
 */
public class JDBCShell {

    private static Boolean quiet = false;

    private static void printSQLException(SQLException sqle) {
        System.err.println();
        System.err.println("*** SQLException caught ***");

        while (sqle != null) {
            System.err.println(" Error code: " + sqle.getErrorCode());
            System.err.println(" SQL State: " + sqle.getSQLState());
            System.err.println(" Message: " + sqle.getMessage());
            sqle = sqle.getNextException();
        }
    }

    public static void handleSQLException(SQLException sqle) {
        printSQLException(sqle);

        throw new IllegalStateException();
    }

    public static void swallowSQLException(SQLException sqle) {
        printSQLException(sqle);
    }

    public static void printArg(String name, String arg) {
        println(name + "=" + arg);
    }

    private static void println(String string) {
        if (!quiet) {
            System.out.println(string);
        }
    }

    public static void main(String[] args) throws ClassNotFoundException, IOException {
        // int NARGS = 6;

        int NARGS = 5;
        if (args.length < NARGS) {
            throw new RuntimeException("Expected " + NARGS + " arguments at least, received " + args.length
                    + "\nUsage: JDBCShell "
                    + "<dbURI> <dbUserName> <dbPassword> <driverClass> <path_to_SQL_script> [-quiet] <key>=<value> ..."
                    + "\nExample: JDBCShell "
                    + "jdbc:teradata://10.20.172.138/DATABASE=SCO03_LND_TB,TMODE=TERA,CHARSET=UTF8 "
                    + "guest_u guest_p com.teradata.jdbc.TeraDriver "
                    + " /user/scb1499910/tdch_test/1.sql -quiet param1=val1 param2=val2 ...");
        }
        // TODO: Validation of arguments
        String dbURI = args[0];
        String user = args[1];
        String pass = args[2];
        String driver = args[3];
        String script = args[4];
        if (args.length > 5 && args[5].indexOf("-quiet") == 0) {
            NARGS = 6;
            quiet = true;
        }

        printArg("dbURI", dbURI);
        printArg("user", user);
        printArg("pass", pass);
        printArg("driver", driver);
        printArg("script", script);

        Configuration conf = new Configuration();
        String oozieConfigurationLocation = System.getProperty("oozie.action.conf.xml");
        if (oozieConfigurationLocation != null) {
            println("Loading Oozie configuration from " + oozieConfigurationLocation);
            conf.addResource(new Path(oozieConfigurationLocation));
        }

        String delimiter = System.getProperty("csv.delimiter", ",");

        // Get arguments from command-line
        if (args.length > NARGS) {
            for (int i = NARGS; i < args.length; i++) {
                println(i + ":" + args[i] + " index of=" + args[5].indexOf("-quiet"));
                String[] param = args[i].split("=");
                if (param.length == 1) {
                    System.err.println("Argument " + i + ": " + args[i] + " is not in a key=value format.");
                    continue;
                }
                String key = param[0];
                String value = param[1];
                // If value contains "="
                for (int j = 2; j < param.length; j++) {
                    value = value + "=" + param[j];
                }
                println("Adding parameter: " + key + " with value: " + value);
                conf.set(key, value);
            }
        }
        // conf.set("fs.defaultFS", hdfsURI);
        // conf.set("dfs.client.use.datanode.hostname", "true");
        FileSystem hdfs = FileSystem.get(conf);

        Path filepath = new Path(script);
        if (!hdfs.exists(filepath)) {
            System.err.println(filepath + " does not exist.");
        }
        FSDataInputStream in = hdfs.open(filepath);
        String all_stmts = null;
        try {
            all_stmts = IOUtils.toString(in);
        } finally {
            IOUtils.closeQuietly(in);
        }

        if (all_stmts.length() <= 0) {
            System.err.println("No statements to execute.");
        }
        // Assumes the script contains only executable statements
        // terminated by a ';'
        // No stored procedures, cursor definitions, or constructs like
        // temp tables
        // are recognized or supported
        String[] ls = all_stmts.split(";");
        Statement stmt = null;
        try {
            println(" Loading JDBC driver for database... ");
            Class.forName(driver);

            Connection con = DriverManager.getConnection(dbURI, user, pass);
            con.setAutoCommit(true);
            println(" Connection to database established with user: " + user);
            try {
                stmt = con.createStatement();

                for (String s : ls) {
                    String command = replaceVariables(s, conf);
                    command = command.trim();
                    if (command.isEmpty()) {
                        continue;
                    }
                    println("Executing..." + command);
                    stmt.execute(command);
                    println(command.substring(0, command.length() > 50 ? 50 : command.length()) + "...");
                    // If the command is an insert, print the table and the
                    // number of rows affected
                    if (quiet) {
                        if (command.toUpperCase().startsWith("INSERT INTO")) {
                            String tablename = command.substring("INSERT INTO".length()).split("\\(")[0].trim();
                            System.out.println("'" + tablename + "'," + stmt.getUpdateCount());
                        } else if (command.toUpperCase().startsWith("SELECT COUNT")) {
                            ResultSet rs = stmt.getResultSet();
                            if (rs.next()) {
                                long rc = rs.getLong(1);
                                String tablename = command.substring(command.indexOf("FROM") + "FROM".length() + 1,
                                        command.length()).trim();
                                System.out.println("'" + tablename + "'," + rc);
                            }
                            rs.close();
                        } else if (command.toUpperCase().startsWith("SELECT ")) {
                            ResultSet rs = stmt.getResultSet();
                            ResultSetMetaData metadata = rs.getMetaData();
                            int columnCount = metadata.getColumnCount();
                            StringBuilder header = new StringBuilder();
                            for (int i = 1; i <= columnCount; i++) {
                                if (i > 1) {
                                    header = header.append(delimiter);
                                }
                                header = header.append(metadata.getColumnName(i));
                            }
                            System.out.println(header.toString());

                            while (rs.next()) {
                                StringBuilder row = new StringBuilder();
                                for (int i = 1; i <= columnCount; i++) {
                                    if (i > 1) {
                                        row = row.append(delimiter);
                                    }
                                    Object o = rs.getObject(i);
                                    // @TODO Check for empty result set
                                    if (o != null) {
                                        row = row.append(o.toString());
                                    }
                                }
                                System.out.println(row.toString());
                            }
                            rs.close();
                        }
                    }
                }
            } finally {
                stmt.close();
                con.close();
                println(" Connection to database closed. \n");
            }
        } catch (SQLException ex) {
            handleSQLException(ex);
        }
    }

    private static String replaceVariables(String s, Configuration conf) {
        String command = s.trim();
        Pattern pattern = Pattern.compile("(\\$\\{[^\\}]*\\})");
        Matcher matcher = pattern.matcher(s);
        while (matcher.find()) {
            String group = matcher.group();
            String variableName = group.substring(2, group.length() - 1);
            String variableValue = conf.get(variableName);
            if (variableValue == null) {
                variableValue = "";
            }
            println("Replacing variable: " + variableName + " with value: " + variableValue);
            command = command.replace(group, variableValue);
        }
        return command;
    }
}