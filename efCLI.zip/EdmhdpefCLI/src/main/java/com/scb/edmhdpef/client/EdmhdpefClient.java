package com.scb.edmhdpef.client;

import com.scb.edmhdpef.EdmhdpefCommon;
import com.scb.edmhdpef.entity.EdmDataSource;
import com.scb.edmhdpef.entity.WorkflowExecution;
import com.scb.edmhdpef.vo.*;
import org.apache.commons.io.IOUtils;
import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.AuthCache;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.*;
import org.apache.http.client.protocol.HttpClientContext;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.auth.BasicScheme;
import org.apache.http.impl.client.BasicAuthCache;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.log4j.Logger;
import org.springframework.web.bind.annotation.RequestMethod;
import org.xml.sax.SAXException;

import javax.xml.bind.JAXBException;
import javax.xml.parsers.ParserConfigurationException;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.*;

import static com.scb.edmhdpef.client.util.ClientUtil.*;

/**
 * TODO overhaul to use commons cli instead of manual args parse
 * <p/>
 * TODO also look at resty implementation in influxdb java client as an example to emulate an easy code/design model
 * instead of using http-commons directly.
 * <p/>
 * TODO document and arrive at arg parsing scheme for CLI
 * <p/>
 * TODO write validation tests for the  option schema spec.
 */
public class EdmhdpefClient {

	private static final String EXECUTION_CMD = "execution";
	private static final String CONFIG_CMD = "config";
	private static final String VERSION_CMD = "version";
	private static final Logger logger = Logger.getLogger(EdmhdpefClient.class);
	private static final SimpleDateFormat sdf = new SimpleDateFormat();
	private static final String CLIENT_VERSION = "0.1";

	private String server_url = "http://localhost:12001/";

	public static void main(String[] args) throws Exception {
		System.exit(new EdmhdpefClient().run(args));
	}

	private static void printUsage() {
		System.out.println(
				"Usage: EdmhdpefClient [" + CONFIG_CMD + " | " + EXECUTION_CMD + " | " + VERSION_CMD + "] -help");
	}

	public synchronized int run(String[] args) throws Exception {

		// createWF();
		// createDS();

		// Parse arguments
		if (args.length == 0) {
			printUsage();
			return 1;
		}
		List<String> argList = new ArrayList<String>(Arrays.asList(args));
		argList.remove(0);
		try {
			if (CONFIG_CMD.equals(args[0])) {
				return configCommand(argList);
			} else if (EXECUTION_CMD.equals(args[0])) {
				return executionCommand(argList);
			} else if (VERSION_CMD.equals(args[0])) {
				return versionCommand(argList);
			} else {
				printUsage();
			}
		} catch (Exception e) {
			System.err.println(e.getMessage());
			return 1;
		}
		return 1;
	}

	private String runQuery(String url, RequestMethod method, Object parameter) throws Exception {
		try {
			CredentialsProvider provider = new BasicCredentialsProvider();

			// Create credential pair
			UsernamePasswordCredentials credentials = new UsernamePasswordCredentials(System.getProperty("user.name"),
					"");

			// Inject the credentials
			provider.setCredentials(AuthScope.ANY, credentials);

			AuthCache authCache = new BasicAuthCache();
			authCache.put(new HttpHost(server_url), new BasicScheme());

			final HttpClientContext context = HttpClientContext.create();
			context.setCredentialsProvider(provider);
			context.setAuthCache(authCache);

			// create HTTP Client
			HttpClient httpClient = HttpClientBuilder.create().setDefaultCredentialsProvider(provider).build();

			// Create new getRequest with below mentioned URL
			HttpRequestBase request = null;

			String uri = server_url + "/" + url;
			switch (method) {
			case DELETE:
				request = new HttpDelete(uri + "/" + parameter);
				break;
			case GET:
				if (parameter == null) {
					request = new HttpGet(uri);
				} else {
					request = new HttpGet(uri + "/" + parameter);
				}
				break;
			case POST:
				request = new HttpPost(uri);
				((HttpEntityEnclosingRequestBase) request)
						.setEntity(new StringEntity(EdmhdpefCommon.toXML(parameter), ContentType.APPLICATION_XML));
				break;
			case PUT:
				request = new HttpPut(uri);
				((HttpEntityEnclosingRequestBase) request)
						.setEntity(new StringEntity(EdmhdpefCommon.toXML(parameter), ContentType.APPLICATION_XML));
				break;
			default:
				throw new Exception("Unexpected error");
			}

			// Add additional header to getRequest which accepts
			// application/json data
			request.addHeader("accept", "application/xml");

			// Execute your request and catch response
			HttpResponse response = httpClient.execute(request, context);

			// Get-Capture Complete application/xml body response
			String outputMessage = IOUtils.toString(response.getEntity().getContent());

			// Check for HTTP response code: 200 = success
			if (response.getStatusLine().getStatusCode() != 200) {
				throw new RuntimeException("Failed request : " + response.getStatusLine() + '\n' + outputMessage);
			}

			return outputMessage.toString();

		} catch (IOException | JAXBException e) {
			logger.error(e);
			throw e;
		}
	}

	private int printUsageExecution(String errorMessage) {
		StringBuilder message = new StringBuilder();
		if (errorMessage != null) {
			message.append(errorMessage + "\n\n");
		}
		message.append("Usage: EdmhdpefClient execution <COMMANDS> <ARGS> <OPTS>\n");
		message.append("\tCOMMANDS:\n\n");
		message.append("\t\t-help - This help message\n\n");
		message.append("\t\t-deploy - Get the deployment configuration\n");
		message.append("\t\t\t--worflow <name> - The workflow name to deploy\n");
		message.append("\t\t\t[ --write_files ] - Write the config files to HDFS\n\n");
		message.append("\t\t-run - Run the workflow\n");
		message.append("\t\t\t--workflow <name> - The workflow name to run\n");
		message.append("\t\t\t[ --param key=value ] - Key and value parameter pair for the workflow\n\n");
		message.append("\t\t-status - Query Oozie execution status\n");
		message.append("\t\t\t[ --worflow <name> ] - The workflow name to query\n");
		message.append("\t\t\t[ --jobid <id> ] - The oozie job id\n\n");
		message.append("\tOPTIONS:\n\n");
		message.append(
				"\t\t--server <url> - The URL and port of the application server. Default is " + server_url + '\n');
		message.append("\t\t--verbose - Verbose output\n");
		message.append("\t\t--quiet - Quiet output\n");
		System.out.println(message.toString());

		return (errorMessage == null ? 0 : 1);
	}

	/**
	 * FIXME document this method as a spec!!!
	 *
	 * @param argList
	 * @return
	 * @throws Exception
	 */
	private int executionCommand(List<String> argList) throws Exception {
		ExecutionType type = null;
		String workflowName = null;
		boolean writefiles = false;
		Map<String, String> parameters = new HashMap<String, String>();
		String jobId = null;
		boolean verbose = false;
		boolean quiet = false;

		Iterator<String> it = argList.iterator();
		while (it.hasNext()) {
			String currentArg = it.next();

			if ("-help".equals(currentArg)) {
				return printUsageExecution(null);
			}
			if ("-deploy".equals(currentArg)) {
				if (type != null) {
					return printUsageExecution("Execution type already specified.");
				}
				type = ExecutionType.DEPLOY;
				continue;
			}
			if ("-run".equals(currentArg)) {
				if (type != null) {
					return printUsageExecution("Execution type already specified.");
				}
				type = ExecutionType.RUN;
				continue;
			}
			if ("-status".equals(currentArg)) {
				if (type != null) {
					return printUsageExecution("Execution type already specified.");
				}
				type = ExecutionType.STATUS;
				continue;
			}

			if ("--workflow".equals(currentArg)) {
				if (!it.hasNext()) {
					return printUsageExecution("Workflow name not specified.");
				}
				workflowName = it.next();
				continue;
			}

			if ("--write_files".equals(currentArg)) {
				writefiles = true;
				continue;
			}

			if ("--jobid".equals(currentArg)) {
				if (!it.hasNext()) {
					return printUsageExecution("Oozie job id not specified.");
				}
				jobId = it.next();
				continue;
			}

			if ("--param".equals(currentArg)) {
				if (!it.hasNext()) {
					return printUsageExecution("Parameter not specified.");
				}
				String param = it.next();
				logger.info("Processing parameter:" + param);
				String[] splittedParam = param.split("=");
				if (splittedParam.length < 2) {
					return printUsageExecution("Parameter is not in a key=value format: " + param);
				}
				String paramValue = splittedParam[1];
				for (int i = 2; i < splittedParam.length; i++) {
					paramValue = "=" + splittedParam[i];
				}
				parameters.put(splittedParam[0], paramValue);
				continue;
			}

			if ("--server".equals(currentArg)) {
				if (!it.hasNext()) {
					return printUsageExecution("Server address not specified.");
				}
				server_url = it.next() + "/";
				continue;
			}
			if ("--verbose".equals(currentArg)) {
				verbose = true;
				continue;
			}
			if ("--quiet".equals(currentArg)) {
				quiet = true;
				continue;
			}
		}

		String output = null;
		if (type == null) {
			return printUsageExecution("Execution type not specified.");
		}
		switch (type) {
		case DEPLOY:
			if (workflowName == null) {
				return printUsageExecution("Workflow name not specified.");
			}
			DeployWorkflowVO deployVO = new DeployWorkflowVO();
			deployVO.setWorkflowName(workflowName);
			deployVO.setCreateFilesInHDFS(writefiles);
			output = runQuery("execution/deploy", RequestMethod.POST, deployVO);

			if (verbose) {
				System.out.println("============ Output ============");
				System.out.println(output);
			}
			DeploymentFileListVO fileListVO;
			try {
				fileListVO = getEntityFromXMLString(output, DeploymentFileListVO.class);
			} catch (Exception e) {
				if (verbose) {
					e.printStackTrace();
				}
				System.err.println("Error recovering entity from XML: " + e.getMessage() + "-" + e);
				throw e;
			}
			if (!quiet) {
				if (deployVO.getCreateFilesInHDFS()) {
					System.out.println("The following files were created in HDFS: ");
				} else {
					System.out.println("The following files were generated: ");
				}
			}
			for (DeploymentFileVO file : fileListVO.getFiles()) {
				System.out.println(file.getFileName());
			}

			break;
		case RUN:
			if (workflowName == null) {
				return printUsageExecution("Workflow name not specified.");
			}
			RunWorkflowVO runVO = new RunWorkflowVO();
			runVO.setWorkflow(workflowName);
			runVO.setParams(parameters);
			output = runQuery("execution/run", RequestMethod.POST, runVO);
			if (verbose) {
				System.out.println("============ Output ============");
				System.out.println(output);
			}
			WorkflowExecution wex;
			try {
				wex = getEntityFromXMLString(output, WorkflowExecution.class);
			} catch (Exception e) {
				if (verbose) {
					e.printStackTrace();
				}
				System.err.println("Error recovering entity from XML: " + e.getMessage());
				throw e;
			}

			if (quiet) {
				System.out.println(wex.getJobId());
			} else {
				System.out.println("JobID: " + wex.getJobId() + " Execution date: " + sdf.format(wex.getExecutionDate())
						+ " Status: " + wex.getStatus());
			}
			break;
		case STATUS:
			if (workflowName == null && jobId == null) {
				return printUsageExecution("Must provide either workflow name or job id are compulsory.");
			}
			WorkflowStatusVO statusVO = new WorkflowStatusVO();
			statusVO.setJobId(jobId);
			statusVO.setWorkflowName(workflowName);
			output = runQuery("execution/status", RequestMethod.POST, statusVO);
			if (verbose) {
				System.out.println("============ Output ============");
				System.out.println(output);
			}
			WorkflowExecutionListVO status;
			try {
				status = getEntityFromXMLString(output, WorkflowExecutionListVO.class);
			} catch (Exception e) {
				if (verbose) {
					e.printStackTrace();
				}
				System.err.println("Error recovering entity from XML: " + e.getMessage());
				throw e;
			}

			if (status.getExecutionList().size() == 0) {
				System.err.println("Executions for workflow " + workflowName + " not found.");
			} else {
				// Sort by date
				Collections.sort(status.getExecutionList());
				for (WorkflowExecution exe : status.getExecutionList()) {
					System.out.println("JobID: " + exe.getJobId() + " Execution date: "
							+ sdf.format(exe.getExecutionDate()) + " Status: " + exe.getStatus());
				}
			}
			break;
		}

		return 0;
	}

	private int configCommand(List<String> argList) throws Exception {

		EntityType entityType = null;
		RequestMethod requestMethod = null;
		File inputFile = null;
		String workflowName = null;
		boolean verbose = false;
		boolean quiet = false;

		Iterator<String> it = argList.iterator();
		while (it.hasNext()) {
			String currentArg = it.next();

			if ("-help".equals(currentArg)) {
				return printUsageConfig(null, server_url);
			}
			if ("-entity".equals(currentArg)) {
				if (entityType != null) {
					return printUsageExecution("Entity type already specified.");
				}
				if (!it.hasNext()) {
					return printUsageExecution("Entity type not specified.");
				}
				String entity = it.next();
				if ("workflow".equalsIgnoreCase(entity)) {
					entityType = EntityType.WORKFLOW;
				}
				if ("datasource".equalsIgnoreCase(entity)) {
					entityType = EntityType.DATASOURCE;
				}
				if (entityType == null) {
					return printUsageExecution("Entity type not specified.");
				}
				continue;
			}
			if ("-create".equals(currentArg)) {
				if (requestMethod != null) {
					return printUsageConfig("Incompatible parameters", server_url);
				}
				if (!it.hasNext()) {
					return printUsageConfig("File not specified.", server_url);
				}
				inputFile = new File(it.next());
				if (!inputFile.exists()) {
					return printUsageConfig("File " + inputFile.getAbsolutePath() + " does not exist", server_url);
				}
				requestMethod = RequestMethod.PUT;
				continue;
			}
			if ("-update".equals(currentArg)) {
				if (requestMethod != null) {
					return printUsageConfig("Incompatible parameters", server_url);
				}
				if (!it.hasNext()) {
					return printUsageConfig("File not specified.", server_url);
				}
				inputFile = new File(it.next());
				if (!inputFile.exists()) {
					return printUsageConfig("File " + inputFile.getAbsolutePath() + " does not exist", server_url);
				}
				requestMethod = RequestMethod.POST;
				continue;
			}
			if ("-retrieve".equals(currentArg)) {
				if (requestMethod != null) {
					return printUsageConfig("Incompatible parameters", server_url);
				}
				if (it.hasNext()) {
					workflowName = it.next();
				}
				requestMethod = RequestMethod.GET;
				continue;
			}
			if ("-delete".equals(currentArg)) {
				if (requestMethod != null) {
					return printUsageConfig("Incompatible parameters", server_url);
				}
				if (!it.hasNext()) {
					return printUsageConfig("Workflow name not specified.", server_url);
				}
				workflowName = it.next();
				requestMethod = RequestMethod.DELETE;
				continue;
			}

			if ("--server".equals(currentArg)) {
				if (!it.hasNext()) {
					return printUsageExecution("Server address not specified.");
				}
				server_url = it.next() + "/";
				continue;
			}
			if ("--verbose".equals(currentArg)) {
				verbose = true;
				continue;
			}
			if ("--quiet".equals(currentArg)) {
				quiet = true;
				continue;
			}
		}
		if (entityType == null) {
			return printUsageConfig("Entity not specified.", server_url);
		}
		if (requestMethod == null) {
			return printUsageConfig("Command not specified.", server_url);
		}
		switch (requestMethod) {
		case PUT:
		case POST:
			if (inputFile == null) {
				return printUsageConfig("Input file not specified", server_url);
			}
			break;
		case DELETE:
			if (workflowName == null) {
				return printUsageConfig("Workflow name not specified", server_url);
			}
			break;
		default:
			break;
		}
		Object entity = null;
		switch (entityType) {
		case WORKFLOW:
			if (workflowName != null) {
				entity = workflowName;
			} else if (inputFile != null) {
				// Load from file
				try {
					entity = getEntityFromXMLFile(inputFile, WorkflowDefinitionVO.class);
				} catch (SAXException | IOException | ParserConfigurationException | JAXBException e) {
					if (verbose) {
						e.printStackTrace();
					}
					throw new RuntimeException("Error reading XML file " + inputFile.getAbsolutePath(), e);
				}
			}
			break;
		case DATASOURCE:
			if (workflowName != null) {
				entity = workflowName;
			} else if (inputFile != null) {
				// Load from file
				try {
					entity = getEntityFromXMLFile(inputFile, EdmDataSource.class);
				} catch (SAXException | IOException | ParserConfigurationException | JAXBException e) {
					if (verbose) {
						e.printStackTrace();
					}
					throw new RuntimeException("Error reading XML file " + inputFile.getAbsolutePath(), e);
				}
			}
			break;
		}

		String output = runQuery(entityType.toString().toLowerCase(), requestMethod, entity);

		if (verbose) {
			System.out.println("============ Output ============");
			System.out.println(output);
		}
		if (!quiet) {
			System.out.println("OK.");
		}

		if (requestMethod.equals(RequestMethod.GET)) {
			if (output == null || output.isEmpty()) {
				if (!quiet) {
					System.out.println("No results.");
				}
				return 0;
			}
			switch (entityType) {
			case WORKFLOW:
				WorkflowVOList wflist = getEntityFromXMLString(output, WorkflowVOList.class);
				for (WorkflowDefinitionVO wf : wflist.getWorkflowList()) {
					System.out.println("----------");
					System.out.println("Name: " + wf.getName());
					System.out.println("Description: " + wf.getDescription());
					System.out.println("Source: " + wf.getSourceName());
					System.out.println("Destination: " + wf.getDestinationName());
				}
				break;
			case DATASOURCE:
				DataSourceListVO dslist = getEntityFromXMLString(output,
						DataSourceListVO.class);
				for (EdmDataSource ds : dslist.getDatasources()) {
					System.out.println("----------");
					System.out.println("Name: " + ds.getName());
					System.out.println("Description: " + ds.getDescription());
					System.out.println("Type: " + ds.getType());
				}
				break;
			}
		}

		return 0;
	}

	public int versionCommand(List<String> argList) throws Exception {

		Iterator<String> it = argList.iterator();
		while (it.hasNext()) {
			String currentArg = it.next();

			if ("-help".equals(currentArg)) {
				return printUsageVersion(null, server_url);
			}
			if ("--server".equals(currentArg)) {
				if (!it.hasNext()) {
					return printUsageExecution("Server address not specified.");
				}
				server_url = it.next() + "/";
				continue;
			}
			if ("--client".equals(currentArg)) {
				System.out.println("Client version: " + CLIENT_VERSION);
			}
		}
		System.out.println(runQuery("/admin/version", RequestMethod.GET, null));
		return 0;

	}

	private enum EntityType {
		DATASOURCE, WORKFLOW
	}

	private enum ExecutionType {
		DEPLOY, RUN, STATUS
	}

}
