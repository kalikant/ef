package com.scb.edmhdpef.client.util;

import org.xml.sax.SAXException;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import javax.xml.parsers.ParserConfigurationException;
import java.io.File;
import java.io.IOException;
import java.io.StringReader;

/**
 * Created by The Data Team on 10-12-2015.
 */
public class ClientUtil {


    public static <T> T getEntityFromXMLString(String input, Class<?> objectClass)
            throws SAXException, IOException, ParserConfigurationException, JAXBException {
        if (input == null || input.trim().isEmpty()) {
            return null;
        }
        //FIXME no runtime typing hence try and parametrize type info!!!
        JAXBContext context = JAXBContext.newInstance(objectClass);

        Unmarshaller m = context.createUnmarshaller();
        Object entity = m.unmarshal(new StringReader(input));
        return (T) entity;
    }

    public static Object getEntityFromXMLFile(File inputFile, Class<?> objectClass)
            throws SAXException, IOException, ParserConfigurationException, JAXBException {
        JAXBContext context = JAXBContext.newInstance(objectClass);

        Unmarshaller m = context.createUnmarshaller();
        Object entity = m.unmarshal(inputFile);
        return objectClass.cast(entity);
    }

    public static int printUsageVersion(String errorMessage, String server_url) {
        StringBuilder message = new StringBuilder();
        if (errorMessage != null) {
            message.append(errorMessage + "\n\n");
        }
        message.append("Usage: EdmhdpefClient version <OPTIONS>\n");
        message.append("Prints server version and exit\n");
        message.append(
                "\t\t--server <url> - The URL and port of the application server. Default is " + server_url + '\n');
        message.append("\t\t--client - Print only client version\n");
        System.out.println(message.toString());

        return (errorMessage == null ? 0 : 1);
    }

    public static int printUsageConfig(String errorMessage, String server_url) {
        StringBuilder message = new StringBuilder();
        if (errorMessage != null) {
            message.append(errorMessage + "\n\n");
        }
        message.append("Usage: EdmhdpefClient config -entity <ENTITY> <COMMANDS> <OPTIONS>\n");
        message.append("\tENTITY:\n");
        message.append("\tMust be 'datasource' or 'workflow'\n\n");
        message.append("\tCOMMANDS:\n\n");
        message.append("\t\t-help - This help message\n\n");
        message.append("\t\t-create <file> - Creates a new entity using the provided XML file\n");
        message.append("\t\t-update <file> - Updates an existing entity using the provided XML file\n");
        message.append("\t\t-retrieve <name> - Retrieves the entity name\n");
        message.append("\t\t-delete <name> - Delete the entity 'name'\n");
        message.append("\tOPTIONS:\n\n");
        message.append(
                "\t\t--server <url> - The URL and port of the application server. Default is " + server_url + '\n');
        message.append("\t\t--verbose - Verbose output\n");
        message.append("\t\t--quiet - Quiet output\n");
        System.out.println(message.toString());

        return (errorMessage == null ? 0 : 1);
    }
}
