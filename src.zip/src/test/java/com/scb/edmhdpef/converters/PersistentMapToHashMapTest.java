package com.scb.edmhdpef.converters;

import java.util.HashMap;
import java.util.Map;

import org.junit.Assert;
import org.junit.Test;

public class PersistentMapToHashMapTest {

	@Test
	public final void testConvert_1() {
		PersistentMapToHashMap converter = new PersistentMapToHashMap();
		Assert.assertNull(converter.convert(null, null, null, null));
	}

	@Test(expected = java.lang.ClassCastException.class)
	public final void testConvert_2() {
		PersistentMapToHashMap converter = new PersistentMapToHashMap();
		Map<?, ?> cnv = (Map<?, ?>) converter.convert(null, new Object(), null, null);
		Assert.assertTrue(cnv.isEmpty());
	}

	@Test
	public final void testConvert_3() {
		PersistentMapToHashMap converter = new PersistentMapToHashMap();
		Map<?, ?> cnv = (Map<?, ?>) converter.convert(null, new HashMap<Object, Object>(), null, null);
		Assert.assertTrue(cnv.isEmpty());
	}

	@Test
	public final void testConvert_4() {
		PersistentMapToHashMap converter = new PersistentMapToHashMap();
		Map<String, String> input = new HashMap<String, String>();
		input.put("key", "value");
		Map<?, ?> cnv = (Map<?, ?>) converter.convert(null, input, null, null);
		Assert.assertEquals(input, cnv);
	}

}
