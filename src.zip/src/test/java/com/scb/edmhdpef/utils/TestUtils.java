package com.scb.edmhdpef.utils;

import com.scb.edmhdpef.services.datasourcemng.TeradataManagementTest;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import java.io.InputStream;

import static org.junit.Assert.assertNotNull;

/**
 * Created by ganesh@thedatateam.in on 09-12-2015.
 *
 * Test utils contains loads of static utils commonly paraphased with a verb to indicate action/work it does
 *
 */
public class TestUtils {
    public static <T> T unmarshal( Class<?> T, String resourceLocation) throws JAXBException {
        JAXBContext jaxbContext = JAXBContext.newInstance(T);
        InputStream resourceAsStream = T.getClassLoader().getResourceAsStream(resourceLocation);
        assertNotNull(resourceAsStream);
        return  (T)jaxbContext.createUnmarshaller().unmarshal(resourceAsStream);
    }
}
