package com.scb.edmhdpef.config.test;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.dozer.DozerBeanMapper;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.view.freemarker.FreeMarkerConfigurer;

@Configuration
@ComponentScan(basePackages = { "com.scb.edmhdpef.*" })
@EnableWebMvc
public class EdmhdpefConfigurationTest {

	@Bean
	public static PropertySourcesPlaceholderConfigurer getPropertySourcesPlaceholderConfigurer() throws IOException {
		PropertySourcesPlaceholderConfigurer ppc = new PropertySourcesPlaceholderConfigurer();
		ppc.setLocations(getResources());
		ppc.setIgnoreUnresolvablePlaceholders(true);
		return ppc;
	}

	@Bean
	public DozerBeanMapper mappingService() {
		DozerBeanMapper mappingService = new DozerBeanMapper();
		List<String> mappingFileUrls = new ArrayList<String>();
		mappingFileUrls.add("dozer-bean-mappings.xml");
		mappingService.setMappingFiles(mappingFileUrls);
		return mappingService;
	}

	@Bean
	public FreeMarkerConfigurer freeMarkerConfig() {
		FreeMarkerConfigurer freeMarkerConfig = new FreeMarkerConfigurer();
		freeMarkerConfig.setTemplateLoaderPath("classpath:templates");
		return freeMarkerConfig;
	}

	private static Resource[] getResources() throws IOException {
		List<Resource> resources = new ArrayList<Resource>();
		resources.addAll(
				Arrays.asList(new PathMatchingResourcePatternResolver().getResources("classpath:*.properties")));
		resources.addAll(Arrays
				.asList(new PathMatchingResourcePatternResolver().getResources("file:/etc/edmhdpef/*.properties")));
		return resources.toArray(new Resource[resources.size()]);
	}
}
