package com.scb.edmhdpef.controller;

import static org.junit.Assert.assertNotNull;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.web.WebAppConfiguration;

import com.scb.edmhdpef.config.EdmhdpefConfiguration;
import com.scb.edmhdpef.exceptions.EdmHdpEfAppException;
import com.scb.edmhdpef.exceptions.EdmHdpEfInternalException;
import com.scb.edmhdpef.exceptions.EdmHdpEfNotImplementedException;

/**
 * The class <code>ExceptionControllerTest</code> contains tests for the class
 * <code>{@link ExceptionController}</code>.
 */
@RunWith(MockitoJUnitRunner.class)
@WebAppConfiguration
@ContextConfiguration(classes = { EdmhdpefConfiguration.class })
public class ExceptionControllerTest {

	@Autowired
	@InjectMocks
	private ExceptionController fixture;

	/**
	 * Perform pre-test initialization.
	 *
	 * @throws Exception
	 *             if the initialization fails for some reason
	 */
	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
	}

	/**
	 * Run the String
	 * handleAPIException(EdmHdpEfAppException,HttpServletResponse) method test.
	 *
	 * @throws Exception
	 */
	@Test
	public void testHandleAPIException_1() throws Exception {
		EdmHdpEfAppException e = new EdmHdpEfAppException(
				com.scb.edmhdpef.exceptions.EdmHdpEfAppException.AppExceptionCode.ENTITY_ALREADY_EXISTS, "",
				new Throwable());

		String result = fixture.handleAPIException(e, null);

		assertNotNull(result);
	}

	/**
	 * Run the String
	 * handleAPIException(EdmHdpEfInternalException,HttpServletResponse) method
	 * test.
	 *
	 * @throws Exception
	 */
	@Test
	public void testHandleAPIException_2() throws Exception {
		EdmHdpEfInternalException e = new EdmHdpEfInternalException(
				EdmHdpEfInternalException.InternalExceptionCode.DATA_STORAGE_ERROR, "");

		String result = fixture.handleAPIException(e, null);

		assertNotNull(result);
	}

	/**
	 * Run the String
	 * handleAPIException(EdmHdpEfNotImplementedException,HttpServletResponse)
	 * method test.
	 *
	 * @throws Exception
	 */
	@Test
	public void testHandleAPIException_3() throws Exception {
		EdmHdpEfNotImplementedException e = new EdmHdpEfNotImplementedException("");

		String result = fixture.handleAPIException(e, null);

		assertNotNull(result);
	}
}