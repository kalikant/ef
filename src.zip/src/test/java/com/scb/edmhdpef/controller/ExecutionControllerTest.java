package com.scb.edmhdpef.controller;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.web.WebAppConfiguration;

import com.scb.edmhdpef.config.EdmhdpefConfiguration;
import com.scb.edmhdpef.entity.EdmWorkflow;
import com.scb.edmhdpef.entity.WorkflowExecution;
import com.scb.edmhdpef.services.execution.ExecutionService;
import com.scb.edmhdpef.vo.DeployWorkflowVO;
import com.scb.edmhdpef.vo.DeploymentFileListVO;
import com.scb.edmhdpef.vo.RunWorkflowVO;
import com.scb.edmhdpef.vo.WorkflowExecutionListVO;
import com.scb.edmhdpef.vo.WorkflowStatusVO;

/**
 * The class <code>ExecutionControllerTest</code> contains tests for the class
 * <code>{@link ExecutionController}</code>.
 */
@RunWith(MockitoJUnitRunner.class)
@WebAppConfiguration
@ContextConfiguration(classes = { EdmhdpefConfiguration.class })
public class ExecutionControllerTest {

	// Create Mock
	@Mock
	private ExecutionService executionService;

	@Autowired
	@InjectMocks
	ExecutionController fixture;

	/**
	 * Perform pre-test initialization.
	 *
	 * @throws Exception
	 *             if the initialization fails for some reason
	 */
	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
	}

	/**
	 * Run the DeploymentFileListVO deployWorkFlow(DeployWorkflowVO) method
	 * test.
	 *
	 * @throws Exception
	 */
	@Test
	public void testDeployWorkFlow_1() throws Exception {
		DeployWorkflowVO deployWorkflowVO = new DeployWorkflowVO();

		when(executionService.deployWorkflow(any(DeployWorkflowVO.class))).thenReturn(new HashMap<String, String>());

		DeploymentFileListVO result = fixture.deployWorkFlow(deployWorkflowVO);

		assertNotNull(result);
	}

	/**
	 * Run the WorkflowExecutionListVO queryStatus(WorkflowStatusVO) method
	 * test.
	 *
	 * @throws Exception
	 */
	@Test
	public void testQueryStatus_1() throws Exception {
		WorkflowStatusVO status = new WorkflowStatusVO();
		status.setWorkflowName("");
		status.setJobId("");

		when(executionService.queryStatus(any(WorkflowExecution.class))).thenReturn(new ArrayList<WorkflowExecution>());

		WorkflowExecutionListVO result = fixture.queryStatus(status);

		assertNotNull(result);
	}

	/**
	 * Run the WorkflowExecution runWorkflow(RunWorkflowVO) method test.
	 *
	 * @throws Exception
	 */
	@Test
	public void testRunWorkflow_1() throws Exception {
		RunWorkflowVO runWorkflow = new RunWorkflowVO();
		runWorkflow.setWorkflow("name");
		runWorkflow.setParams(new HashMap<String, String>());

		WorkflowExecution we = new WorkflowExecution();
		we.setJobId("jobid");
		we.setExecutionDate(new Date());
		we.setWorkflow(new EdmWorkflow());
		we.getWorkflow().setName("name");

		when(executionService.runWorkflow(any(WorkflowExecution.class))).thenReturn(we);

		WorkflowExecution result = fixture.runWorkflow(runWorkflow);

		assertNotNull(result);
	}
}