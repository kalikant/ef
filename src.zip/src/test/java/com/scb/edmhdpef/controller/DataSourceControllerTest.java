package com.scb.edmhdpef.controller;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.mockito.Mockito.when;

import java.util.ArrayList;

import javax.activation.DataSource;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.web.WebAppConfiguration;

import com.scb.edmhdpef.config.EdmhdpefConfiguration;
import com.scb.edmhdpef.entity.EdmDataSource;
import com.scb.edmhdpef.services.configuration.DatasourceConfigService;
import com.scb.edmhdpef.vo.DataSourceListVO;

/**
 * The class <code>DataSourceControllerTest</code> contains tests for the class
 * <code>{@link DataSourceController}</code>.
 */
@RunWith(MockitoJUnitRunner.class)
@WebAppConfiguration
@ContextConfiguration(classes = { EdmhdpefConfiguration.class })
public class DataSourceControllerTest {

	// Create Mock
	@Mock
	private DatasourceConfigService datasourceConfigService;

	@Mock
	private DataSource dataSource;

	@Autowired
	@InjectMocks
	private DataSourceController fixture;

	/**
	 * Perform pre-test initialization.
	 *
	 * @throws Exception
	 *             if the initialization fails for some reason
	 */
	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
	}

	/**
	 * Run the EdmDataSource createdatasource(EdmDataSource) method test.
	 *
	 * @throws Exception
	 */
	@Test
	public void testCreatedatasource_1() throws Exception {
		EdmDataSource datasource = new EdmDataSource();
		when(datasourceConfigService.createDataSource(datasource)).thenReturn(datasource);

		EdmDataSource result = fixture.createDataSource(datasource);

		assertNotNull(result);
	}

	/**
	 * Run the String deletedatasource(EdmDataSource) method test.
	 *
	 * @throws Exception
	 */
	@Test
	public void testDeletedatasource_1() throws Exception {

		String result = fixture.deleteDataSource(null);

		assertNotNull(result);
	}

	/**
	 * Run the List<EdmDataSource> listdatasource(EdmDataSource) method test.
	 *
	 * @throws Exception
	 */
	@Test
	public void testListdatasource_1() throws Exception {
		EdmDataSource datasource = new EdmDataSource();

		when(datasourceConfigService.retrieveDataSources(datasource)).thenReturn(new ArrayList<EdmDataSource>());

		DataSourceListVO result = fixture.listDataSource(null);

		assertNull(result);
	}

	/**
	 * Run the EdmDataSource updatedatasource(EdmDataSource) method test.
	 *
	 * @throws Exception
	 */
	@Test
	public void testUpdatedatasource_1() throws Exception {
		EdmDataSource datasource = new EdmDataSource();

		when(datasourceConfigService.updateDataSource(datasource)).thenReturn(datasource);

		EdmDataSource result = fixture.updateDataSource(datasource);

		assertNotNull(result);
	}
}