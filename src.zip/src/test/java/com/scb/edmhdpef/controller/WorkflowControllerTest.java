package com.scb.edmhdpef.controller;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import org.dozer.DozerBeanMapper;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.web.WebAppConfiguration;

import com.scb.edmhdpef.config.EdmhdpefConfiguration;
import com.scb.edmhdpef.services.configuration.WorkflowConfigService;
import com.scb.edmhdpef.vo.WorkflowDefinitionVO;
import com.scb.edmhdpef.vo.WorkflowVOList;

/**
 * The class <code>WorkflowControllerTest</code> contains tests for the class
 * <code>{@link WorkflowController}</code>.
 *
 */
@RunWith(MockitoJUnitRunner.class)
@WebAppConfiguration
@ContextConfiguration(classes = { EdmhdpefConfiguration.class })
public class WorkflowControllerTest {

	@Mock
	WorkflowConfigService workflowConfigService;

	@Mock
	private DozerBeanMapper mappingService;

	@Autowired
	@InjectMocks
	WorkflowController fixture;

	/**
	 * Perform pre-test initialization.
	 *
	 * @throws Exception
	 *             if the initialization fails for some reason
	 */
	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
	}

	/**
	 * Run the WorkflowDefinitionVO createWorkflow(WorkflowDefinitionVO) method
	 * test.
	 *
	 * @throws Exception
	 */
	@Test
	public void testCreateWorkflow_1() throws Exception {

		WorkflowDefinitionVO workflow = new WorkflowDefinitionVO();

		WorkflowDefinitionVO result = fixture.createWorkflow(workflow);

		assertNull(result);
	}

	/**
	 * Run the String deleteWorkflow(WorkflowDefinitionVO) method test.
	 *
	 * @throws Exception
	 */
	@Test
	public void testDeleteWorkflow_1() throws Exception {

		String result = fixture.deleteWorkflow(null);

		assertNotNull(result);
	}

	/**
	 * Run the List<WorkflowDefinitionVO> listWorkflow(WorkflowDefinitionVO)
	 * method test.
	 *
	 * @throws Exception
	 */
	@Test
	public void testListWorkflow_1() throws Exception {

		WorkflowVOList result = fixture.listWorkflow(null);

		assertNull(result);
	}

	/**
	 * Run the WorkflowDefinitionVO updateWorkflow(WorkflowDefinitionVO) method
	 * test.
	 *
	 * @throws Exception
	 */
	@Test
	public void testUpdateWorkflow_1() throws Exception {
		WorkflowDefinitionVO workflow = new WorkflowDefinitionVO();

		WorkflowDefinitionVO result = fixture.updateWorkflow(workflow);

		assertNull(result);
	}

}