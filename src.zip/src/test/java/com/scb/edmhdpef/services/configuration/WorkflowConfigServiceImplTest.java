package com.scb.edmhdpef.services.configuration;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import org.dozer.DozerBeanMapper;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.web.WebAppConfiguration;

import com.scb.edmhdpef.config.EdmhdpefConfiguration;
import com.scb.edmhdpef.entity.DataTransferSpecification;
import com.scb.edmhdpef.entity.EdmDataSource;
import com.scb.edmhdpef.entity.EdmWorkflow;
import com.scb.edmhdpef.enums.BusinessDayBehaviorEnum;
import com.scb.edmhdpef.enums.EdmDataSourceTypeEnum;
import com.scb.edmhdpef.enums.EdmWorkflowTypeEnum;
import com.scb.edmhdpef.exceptions.EdmHdpEfNotImplementedException;
import com.scb.edmhdpef.services.database.DataAccessService;
import com.scb.edmhdpef.services.database.HiveDumpService;
import com.scb.edmhdpef.services.datasourcemng.DataSourceManagementSelector;
import com.scb.edmhdpef.services.datasourcemng.HiveManagement;
import com.scb.edmhdpef.services.datasourcemng.TeradataManagement;

/**
 * The class <code>WorkflowConfigServiceImplTest</code> contains tests for the
 * class <code>{@link WorkflowConfigServiceImpl}</code>.
 */
@RunWith(MockitoJUnitRunner.class)
@WebAppConfiguration
@ContextConfiguration(classes = { EdmhdpefConfiguration.class })
public class WorkflowConfigServiceImplTest {

	@Mock
	DataAccessService dataAccess;

	@Mock
	HiveDumpService hiveDumpService;

	@Mock
	DozerBeanMapper mappingService;

	@Mock
	DataSourceManagementSelector dataSourceManagementSelector;

	@Mock
	HiveManagement hiveManagement;

	@Mock
	TeradataManagement teradataManagement;

	@Autowired
	@InjectMocks
	WorkflowConfigServiceImpl fixture;

	/**
	 * Perform pre-test initialization.
	 * 
	 * @throws EdmHdpEfNotImplementedException
	 */
	@Before
	public void setUp() throws EdmHdpEfNotImplementedException {
		MockitoAnnotations.initMocks(this);
		when(dataSourceManagementSelector.getDataSourceManagement(any(EdmDataSource.class))).thenReturn(hiveManagement);
	}

	/**
	 * Run the EdmWorkflow createWorkflow(EdmWorkflow) method test.
	 *
	 * @throws Exception
	 *
	 */
	@Test(expected = com.scb.edmhdpef.exceptions.EdmHdpEfAppException.class)
	public void testCreateWorkflow_1() throws Exception {

		EdmWorkflow workflow = new EdmWorkflow();

		EdmWorkflow result = fixture.createWorkflow(workflow);

		assertNotNull(result);
	}

	/**
	 * Run the EdmWorkflow createWorkflow(EdmWorkflow) method test.
	 *
	 * @throws Exception
	 *
	 */
	@Test(expected = com.scb.edmhdpef.exceptions.EdmHdpEfAppException.class)
	public void testCreateWorkflow_2() throws Exception {
		EdmWorkflow workflow = new EdmWorkflow();
		workflow.setName("");

		EdmWorkflow result = fixture.createWorkflow(workflow);

		assertNotNull(result);
	}

	/**
	 * Run the EdmWorkflow createWorkflow(EdmWorkflow) method test.
	 *
	 * @throws Exception
	 *
	 */
	@Test(expected = com.scb.edmhdpef.exceptions.EdmHdpEfAppException.class)
	public void testCreateWorkflow_3() throws Exception {
		EdmWorkflow workflow = new EdmWorkflow();
		workflow.setName("wf");

		EdmWorkflow result = fixture.createWorkflow(workflow);

		assertNotNull(result);
	}

	/**
	 * Run the EdmWorkflow createWorkflow(EdmWorkflow) method test.
	 *
	 * @throws Exception
	 *
	 */
	@Test(expected = com.scb.edmhdpef.exceptions.EdmHdpEfAppException.class)
	public void testCreateWorkflow_5() throws Exception {
		EdmWorkflow workflow = new EdmWorkflow();
		workflow.setName("wf");
		workflow.setType(EdmWorkflowTypeEnum.TABLE_GROUP);
		workflow.setSource(new EdmDataSource());

		EdmWorkflow result = fixture.createWorkflow(workflow);

		assertNotNull(result);
	}

	/**
	 * Run the EdmWorkflow createWorkflow(EdmWorkflow) method test.
	 *
	 * @throws Exception
	 *
	 */
	@Test(expected = com.scb.edmhdpef.exceptions.EdmHdpEfAppException.class)
	public void testCreateWorkflow_6() throws Exception {
		EdmWorkflow workflow = new EdmWorkflow();
		workflow.setName("wf");
		workflow.setType(EdmWorkflowTypeEnum.TABLE_GROUP);
		workflow.setSource(new EdmDataSource());
		workflow.setDestination(new EdmDataSource());

		EdmWorkflow result = fixture.createWorkflow(workflow);

		assertNotNull(result);
	}

	/**
	 * Run the EdmWorkflow createWorkflow(EdmWorkflow) method test.
	 *
	 * @throws Exception
	 *
	 */
	@Test(expected = com.scb.edmhdpef.exceptions.EdmHdpEfAppException.class)
	public void testCreateWorkflow_7() throws Exception {
		EdmWorkflow workflow = new EdmWorkflow();
		workflow.setName("wf");
		workflow.setType(EdmWorkflowTypeEnum.TABLE_GROUP);
		workflow.setSource(new EdmDataSource());
		workflow.setDestination(new EdmDataSource());
		workflow.getSource().setName("src");

		EdmWorkflow result = fixture.createWorkflow(workflow);

		assertNotNull(result);
	}

	/**
	 * Run the EdmWorkflow createWorkflow(EdmWorkflow) method test.
	 *
	 * @throws Exception
	 *
	 */
	@Test(expected = com.scb.edmhdpef.exceptions.EdmHdpEfAppException.class)
	public void testCreateWorkflow_8() throws Exception {
		EdmWorkflow workflow = new EdmWorkflow();
		workflow.setName("wf");
		workflow.setType(EdmWorkflowTypeEnum.TABLE_GROUP);
		workflow.setSource(new EdmDataSource());
		workflow.setDestination(new EdmDataSource());
		workflow.getSource().setName("src");
		workflow.getDestination().setName("dst");

		EdmWorkflow result = fixture.createWorkflow(workflow);

		assertNotNull(result);
	}

	/**
	 * Run the EdmWorkflow createWorkflow(EdmWorkflow) method test.
	 *
	 * @throws Exception
	 *
	 */
	@Test(expected = com.scb.edmhdpef.exceptions.EdmHdpEfAppException.class)
	public void testCreateWorkflow_9() throws Exception {
		EdmWorkflow workflow = new EdmWorkflow();
		workflow.setName("wf");
		workflow.setType(EdmWorkflowTypeEnum.TABLE_GROUP);
		workflow.setSource(new EdmDataSource());
		workflow.setDestination(new EdmDataSource());
		workflow.getSource().setName("src");
		workflow.getDestination().setName("dst");
		workflow.setDataTransferSpecification(new ArrayList<DataTransferSpecification>());

		EdmWorkflow result = fixture.createWorkflow(workflow);

		assertNotNull(result);
	}

	/**
	 * Run the EdmWorkflow createWorkflow(EdmWorkflow) method test.
	 *
	 * @throws Exception
	 *
	 */
	@Test(expected = com.scb.edmhdpef.exceptions.EdmHdpEfAppException.class)
	public void testCreateWorkflow_10() throws Exception {
		EdmWorkflow workflow = new EdmWorkflow();
		workflow.setName("wf");
		workflow.setType(EdmWorkflowTypeEnum.TABLE_GROUP);
		workflow.setSource(new EdmDataSource());
		workflow.setDestination(new EdmDataSource());
		workflow.getSource().setName("src");
		workflow.getSource().setType(EdmDataSourceTypeEnum.HIVE);
		workflow.getDestination().setName("dst");
		workflow.setDataTransferSpecification(new ArrayList<DataTransferSpecification>());
		workflow.getDataTransferSpecification().add(new DataTransferSpecification());

		EdmWorkflow result = fixture.createWorkflow(workflow);

		assertNotNull(result);
	}

	/**
	 * Run the EdmWorkflow createWorkflow(EdmWorkflow) method test.
	 *
	 * @throws Exception
	 *
	 */
	@Test(expected = com.scb.edmhdpef.exceptions.EdmHdpEfAppException.class)
	public void testCreateWorkflow_11() throws Exception {
		EdmWorkflow workflow = new EdmWorkflow();
		workflow.setName("wf");
		workflow.setType(EdmWorkflowTypeEnum.TABLE_GROUP);
		workflow.setSource(new EdmDataSource());
		workflow.setDestination(new EdmDataSource());
		workflow.getSource().setName("src");
		workflow.getSource().setType(EdmDataSourceTypeEnum.HIVE);
		workflow.getDestination().setName("dst");
		when(dataAccess.retrieveById(EdmDataSource.class, "src")).thenReturn(workflow.getSource());
		workflow.setDataTransferSpecification(new ArrayList<DataTransferSpecification>());
		workflow.getDataTransferSpecification().add(new DataTransferSpecification());

		EdmWorkflow result = fixture.createWorkflow(workflow);

		assertNotNull(result);
	}

	/**
	 * Run the EdmWorkflow createWorkflow(EdmWorkflow) method test.
	 *
	 * @throws Exception
	 *
	 */
	@Test(expected = com.scb.edmhdpef.exceptions.EdmHdpEfAppException.class)
	public void testCreateWorkflow_12() throws Exception {
		EdmWorkflow workflow = new EdmWorkflow();
		workflow.setName("wf");
		workflow.setType(EdmWorkflowTypeEnum.TABLE_GROUP);
		workflow.setSource(new EdmDataSource());
		workflow.setDestination(new EdmDataSource());
		workflow.getSource().setName("src");
		workflow.getSource().setType(EdmDataSourceTypeEnum.HIVE);
		workflow.getDestination().setName("dst");
		workflow.getDestination().setType(EdmDataSourceTypeEnum.TERADATA);
		workflow.setDataTransferSpecification(new ArrayList<DataTransferSpecification>());
		workflow.getDataTransferSpecification().add(new DataTransferSpecification());

		when(dataAccess.retrieveById(EdmDataSource.class, "src")).thenReturn(workflow.getSource());
		when(dataAccess.retrieveById(EdmDataSource.class, "dst")).thenReturn(workflow.getDestination());

		EdmWorkflow result = fixture.createWorkflow(workflow);

		assertNotNull(result);
	}

	/**
	 * Run the EdmWorkflow createWorkflow(EdmWorkflow) method test.
	 *
	 * @throws Exception
	 *
	 */
	@Test(expected = com.scb.edmhdpef.exceptions.EdmHdpEfAppException.class)
	public void testCreateWorkflow_13() throws Exception {
		EdmWorkflow workflow = new EdmWorkflow();
		workflow.setName("wf");
		workflow.setType(EdmWorkflowTypeEnum.TABLE_GROUP);
		workflow.setSource(new EdmDataSource());
		workflow.setDestination(new EdmDataSource());
		workflow.getSource().setName("src");
		workflow.getSource().setType(EdmDataSourceTypeEnum.HIVE);
		workflow.getDestination().setName("dst");
		workflow.getDestination().setType(EdmDataSourceTypeEnum.TERADATA);
		when(dataAccess.retrieveById(EdmDataSource.class, "src")).thenReturn(workflow.getSource());
		when(dataAccess.retrieveById(EdmDataSource.class, "dst")).thenReturn(workflow.getDestination());
		workflow.setDataTransferSpecification(new ArrayList<DataTransferSpecification>());
		DataTransferSpecification spec = new DataTransferSpecification();
		workflow.getDataTransferSpecification().add(spec);

		EdmWorkflow result = fixture.createWorkflow(workflow);

		assertNotNull(result);
	}

	/**
	 * Run the EdmWorkflow createWorkflow(EdmWorkflow) method test.
	 *
	 * @throws Exception
	 *
	 */
	@Test(expected = com.scb.edmhdpef.exceptions.EdmHdpEfAppException.class)
	public void testCreateWorkflow_14() throws Exception {
		EdmWorkflow workflow = new EdmWorkflow();
		workflow.setName("wf");
		workflow.setType(EdmWorkflowTypeEnum.TABLE_GROUP);
		workflow.setSource(new EdmDataSource());
		workflow.setDestination(new EdmDataSource());
		workflow.getSource().setName("src");
		workflow.getSource().setType(EdmDataSourceTypeEnum.HIVE);
		workflow.getDestination().setName("dst");
		workflow.getDestination().setType(EdmDataSourceTypeEnum.TERADATA);
		when(dataAccess.retrieveById(EdmDataSource.class, "src")).thenReturn(workflow.getSource());
		when(dataAccess.retrieveById(EdmDataSource.class, "dst")).thenReturn(workflow.getDestination());
		workflow.setDataTransferSpecification(new ArrayList<DataTransferSpecification>());
		DataTransferSpecification spec = new DataTransferSpecification();
		spec.setSourceDatabase("srcDb");
		workflow.getDataTransferSpecification().add(spec);

		EdmWorkflow result = fixture.createWorkflow(workflow);

		assertNotNull(result);
	}

	/**
	 * Run the EdmWorkflow createWorkflow(EdmWorkflow) method test.
	 *
	 * @throws Exception
	 *
	 */
	@Test(expected = com.scb.edmhdpef.exceptions.EdmHdpEfAppException.class)
	public void testCreateWorkflow_15() throws Exception {
		EdmWorkflow workflow = new EdmWorkflow();
		workflow.setName("wf");
		workflow.setType(EdmWorkflowTypeEnum.TABLE_GROUP);
		workflow.setSource(new EdmDataSource());
		workflow.setDestination(new EdmDataSource());
		workflow.getSource().setName("src");
		workflow.getSource().setType(EdmDataSourceTypeEnum.HIVE);
		workflow.getDestination().setName("dst");
		workflow.getDestination().setType(EdmDataSourceTypeEnum.TERADATA);
		when(dataAccess.retrieveById(EdmDataSource.class, "src")).thenReturn(workflow.getSource());
		when(dataAccess.retrieveById(EdmDataSource.class, "dst")).thenReturn(workflow.getDestination());
		workflow.setDataTransferSpecification(new ArrayList<DataTransferSpecification>());
		DataTransferSpecification spec = new DataTransferSpecification();
		spec.setSourceDatabase("srcDb");
		spec.setSourceTable("srcTable");
		workflow.getDataTransferSpecification().add(spec);

		EdmWorkflow result = fixture.createWorkflow(workflow);

		assertNotNull(result);
	}

	/**
	 * Run the EdmWorkflow createWorkflow(EdmWorkflow) method test.
	 *
	 * @throws Exception
	 *
	 */
	@Test(expected = com.scb.edmhdpef.exceptions.EdmHdpEfAppException.class)
	public void testCreateWorkflow_16() throws Exception {
		EdmWorkflow workflow = new EdmWorkflow();
		workflow.setName("wf");
		workflow.setType(EdmWorkflowTypeEnum.TABLE_GROUP);
		workflow.setSource(new EdmDataSource());
		workflow.setDestination(new EdmDataSource());
		workflow.getSource().setName("src");
		workflow.getSource().setType(EdmDataSourceTypeEnum.HIVE);
		workflow.getDestination().setName("dst");
		workflow.getDestination().setType(EdmDataSourceTypeEnum.TERADATA);
		when(dataAccess.retrieveById(EdmDataSource.class, "src")).thenReturn(workflow.getSource());
		when(dataAccess.retrieveById(EdmDataSource.class, "dst")).thenReturn(workflow.getDestination());
		workflow.setDataTransferSpecification(new ArrayList<DataTransferSpecification>());
		DataTransferSpecification spec = new DataTransferSpecification();
		spec.setSourceDatabase("srcDb");
		spec.setSourceTable("source_country_table");
		workflow.getDataTransferSpecification().add(spec);

		EdmWorkflow result = fixture.createWorkflow(workflow);

		assertNotNull(result);
	}

	/**
	 * Run the EdmWorkflow createWorkflow(EdmWorkflow) method test.
	 *
	 * @throws Exception
	 *
	 */
	@Test(expected = com.scb.edmhdpef.exceptions.EdmHdpEfAppException.class)
	public void testCreateWorkflow_17() throws Exception {
		EdmWorkflow workflow = new EdmWorkflow();
		workflow.setName("wf");
		workflow.setType(EdmWorkflowTypeEnum.TABLE_GROUP);
		workflow.setSource(new EdmDataSource());
		workflow.setDestination(new EdmDataSource());
		workflow.getSource().setName("src");
		workflow.getSource().setType(EdmDataSourceTypeEnum.HIVE);
		workflow.getDestination().setName("dst");
		workflow.getDestination().setType(EdmDataSourceTypeEnum.TERADATA);
		when(dataAccess.retrieveById(EdmDataSource.class, "src")).thenReturn(workflow.getSource());
		when(dataAccess.retrieveById(EdmDataSource.class, "dst")).thenReturn(workflow.getDestination());
		workflow.setDataTransferSpecification(new ArrayList<DataTransferSpecification>());
		DataTransferSpecification spec = new DataTransferSpecification();
		spec.setSourceTable("source_country_table");
		spec.setSourceDatabase("srcDb");
		spec.setDestinationDatabase("dstdb");
		workflow.getDataTransferSpecification().add(spec);

		EdmWorkflow result = fixture.createWorkflow(workflow);

		assertNotNull(result);
	}

	/**
	 * Run the EdmWorkflow createWorkflow(EdmWorkflow) method test.
	 *
	 * @throws Exception
	 *
	 */
	@Test(expected = com.scb.edmhdpef.exceptions.EdmHdpEfAppException.class)
	public void testCreateWorkflow_18() throws Exception {
		EdmWorkflow workflow = new EdmWorkflow();
		workflow.setName("wf");
		workflow.setType(EdmWorkflowTypeEnum.TABLE_GROUP);
		workflow.setSource(new EdmDataSource());
		workflow.setDestination(new EdmDataSource());
		workflow.getSource().setName("src");
		workflow.getSource().setType(EdmDataSourceTypeEnum.HIVE);
		workflow.getDestination().setName("dst");
		workflow.getDestination().setType(EdmDataSourceTypeEnum.TERADATA);
		workflow.setDataTransferSpecification(new ArrayList<DataTransferSpecification>());
		DataTransferSpecification spec = new DataTransferSpecification();
		spec.setSourceTable("source_country_table");
		spec.setSourceDatabase("srcDb");
		spec.setDestinationTable("dstTable");
		spec.setDestinationDatabase("dstdb");
		workflow.getDataTransferSpecification().add(spec);
		when(dataAccess.retrieveById(EdmDataSource.class, "src")).thenReturn(workflow.getSource());
		when(dataAccess.retrieveById(EdmDataSource.class, "dst")).thenReturn(workflow.getDestination());
		when(dataAccess.retrieveById(EdmWorkflow.class, "wf")).thenReturn(workflow);
		when(dataAccess.saveOrUpdateObject(any(EdmWorkflow.class))).thenReturn(workflow);

		EdmWorkflow result = fixture.createWorkflow(workflow);

		assertNotNull(result);
	}

	/**
	 * Run the EdmWorkflow createWorkflow(EdmWorkflow) method test.
	 *
	 * @throws Exception
	 *
	 */
	@Test(expected = com.scb.edmhdpef.exceptions.EdmHdpEfAppException.class)
	public void testCreateWorkflow_19() throws Exception {
		EdmWorkflow workflow = new EdmWorkflow();
		workflow.setName("wf");
		workflow.setType(EdmWorkflowTypeEnum.TABLE_GROUP);
		workflow.setSource(new EdmDataSource());
		workflow.setDestination(new EdmDataSource());
		workflow.getSource().setName("src");
		workflow.getSource().setType(EdmDataSourceTypeEnum.HIVE);
		workflow.getDestination().setName("dst");
		workflow.getDestination().setType(EdmDataSourceTypeEnum.TERADATA);
		workflow.setDataTransferSpecification(new ArrayList<DataTransferSpecification>());
		DataTransferSpecification spec = new DataTransferSpecification();
		spec.setSourceTable("source_country_table");
		spec.setSourceDatabase("srcDb");
		spec.setDestinationTable("dstTable");
		spec.setDestinationDatabase("dstdb");
		spec.setFilterCondition("col1=3");
		workflow.getDataTransferSpecification().add(spec);
		when(dataAccess.retrieveById(EdmDataSource.class, "src")).thenReturn(workflow.getSource());
		when(dataAccess.retrieveById(EdmDataSource.class, "dst")).thenReturn(workflow.getDestination());
		when(dataAccess.retrieveById(EdmWorkflow.class, "wf")).thenReturn(workflow);
		when(dataAccess.saveOrUpdateObject(any(EdmWorkflow.class))).thenReturn(workflow);

		EdmWorkflow result = fixture.createWorkflow(workflow);

		assertNotNull(result);
	}

	/**
	 * Run the EdmWorkflow createWorkflow(EdmWorkflow) method test.
	 *
	 * @throws Exception
	 *
	 */
	@Test(expected = com.scb.edmhdpef.exceptions.EdmHdpEfAppException.class)
	public void testCreateWorkflow_20() throws Exception {
		EdmWorkflow workflow = new EdmWorkflow();
		workflow.setName("wf");
		workflow.setType(EdmWorkflowTypeEnum.TABLE_GROUP);
		workflow.setSource(new EdmDataSource());
		workflow.setDestination(new EdmDataSource());
		workflow.getSource().setName("src");
		workflow.getSource().setType(EdmDataSourceTypeEnum.HIVE);
		workflow.getDestination().setName("dst");
		workflow.getDestination().setType(EdmDataSourceTypeEnum.TERADATA);
		workflow.setDataTransferSpecification(new ArrayList<DataTransferSpecification>());
		DataTransferSpecification spec = new DataTransferSpecification();
		spec.setSourceTable("source_country_table");
		spec.setSourceDatabase("srcDb");
		spec.setDestinationTable("dstTable");
		spec.setDestinationDatabase("dstdb");
		spec.setFilterCondition("col1=${test}");
		workflow.getDataTransferSpecification().add(spec);
		when(dataAccess.retrieveById(EdmDataSource.class, "src")).thenReturn(workflow.getSource());
		when(dataAccess.retrieveById(EdmDataSource.class, "dst")).thenReturn(workflow.getDestination());
		when(dataAccess.retrieveById(EdmWorkflow.class, "wf")).thenReturn(workflow);
		when(dataAccess.saveOrUpdateObject(any(EdmWorkflow.class))).thenReturn(workflow);

		EdmWorkflow result = fixture.createWorkflow(workflow);

		assertNotNull(result);
		assertNotNull(result.getParameters());
		assertTrue(result.getParameters().contains("test"));
	}

	/**
	 * Run the EdmWorkflow createWorkflow(EdmWorkflow) method test.
	 *
	 * @throws Exception
	 *
	 */
	@Test
	public void testCreateWorkflow_21() throws Exception {
		EdmWorkflow workflow = new EdmWorkflow();
		workflow.setName("wf");
		workflow.setType(EdmWorkflowTypeEnum.TABLE_GROUP);
		workflow.setSource(new EdmDataSource());
		workflow.setDestination(new EdmDataSource());
		workflow.getSource().setName("src");
		workflow.getSource().setType(EdmDataSourceTypeEnum.HIVE);
		workflow.getDestination().setName("dst");
		workflow.getDestination().setType(EdmDataSourceTypeEnum.TERADATA);
		workflow.setDataTransferSpecification(new ArrayList<DataTransferSpecification>());
		DataTransferSpecification spec = new DataTransferSpecification();
		spec.setSourceTable("source_country_table");
		spec.setSourceDatabase("srcDb");
		spec.setDestinationTable("dstTable");
		spec.setDestinationDatabase("dstdb");
		workflow.getDataTransferSpecification().add(spec);

		when(dataAccess.retrieveById(EdmDataSource.class, workflow.getSource().getName()))
				.thenReturn(workflow.getSource());
		when(dataAccess.retrieveById(EdmDataSource.class, "dst")).thenReturn(workflow.getDestination());
		when(dataAccess.retrieveById(EdmWorkflow.class, "wf")).thenReturn(null);
		when(dataAccess.saveOrUpdateObject(any(EdmWorkflow.class))).thenReturn(workflow);

		EdmWorkflow result = fixture.createWorkflow(workflow);

		assertNotNull(result);
	}

	/**
	 * Run the EdmWorkflow createWorkflow(EdmWorkflow) method test.
	 *
	 * @throws Exception
	 *
	 */
	@Test
	public void testCreateWorkflow_22() throws Exception {
		EdmWorkflow workflow = new EdmWorkflow();
		workflow.setName("wf");
		workflow.setType(EdmWorkflowTypeEnum.TABLE_GROUP);
		workflow.setSource(new EdmDataSource());
		workflow.setDestination(new EdmDataSource());
		workflow.getSource().setName("src");
		workflow.getSource().setType(EdmDataSourceTypeEnum.HIVE);
		workflow.getDestination().setName("dst");
		workflow.getDestination().setType(EdmDataSourceTypeEnum.TERADATA);
		workflow.setDataTransferSpecification(new ArrayList<DataTransferSpecification>());
		DataTransferSpecification spec = new DataTransferSpecification();
		spec.setSourceTable("source_country_table");
		spec.setSourceDatabase("srcDb");
		spec.setDestinationTable("dstTable");
		spec.setDestinationDatabase("dstdb");
		DataTransferSpecification spec2 = new DataTransferSpecification();
		spec2.setSourceTable("source_country_table2");
		spec2.setSourceDatabase("srcDb2");
		spec2.setDestinationTable("dstTable2");
		spec2.setDestinationDatabase("dstdb2");
		workflow.getDataTransferSpecification().add(spec);
		workflow.getDataTransferSpecification().add(spec2);
		when(dataAccess.retrieveById(EdmDataSource.class, workflow.getSource().getName()))
				.thenReturn(workflow.getSource());
		when(dataAccess.retrieveById(EdmDataSource.class, "dst")).thenReturn(workflow.getDestination());
		when(dataAccess.retrieveById(EdmWorkflow.class, "wf")).thenReturn(null);
		when(dataAccess.saveOrUpdateObject(any(EdmWorkflow.class))).thenReturn(workflow);

		EdmWorkflow result = fixture.createWorkflow(workflow);

		assertNotNull(result);
	}

	/**
	 * Run the EdmWorkflow createWorkflow(EdmWorkflow) method test.
	 *
	 * @throws Exception
	 *
	 */
	@Test(expected = com.scb.edmhdpef.exceptions.EdmHdpEfAppException.class)
	public void testCreateWorkflow_23() throws Exception {
		EdmWorkflow workflow = new EdmWorkflow();
		workflow.setName("wf");
		workflow.setType(EdmWorkflowTypeEnum.TABLE_GROUP);
		workflow.setSource(new EdmDataSource());
		workflow.setDestination(new EdmDataSource());
		workflow.getSource().setName("src");
		workflow.getSource().setType(EdmDataSourceTypeEnum.HIVE);
		workflow.getDestination().setName("dst");
		workflow.getDestination().setType(EdmDataSourceTypeEnum.TERADATA);
		workflow.setDataTransferSpecification(new ArrayList<DataTransferSpecification>());
		DataTransferSpecification spec = new DataTransferSpecification();
		spec.setSourceTable("source_country_table");
		spec.setSourceDatabase("srcDb");
		spec.setDestinationTable("dstTable");
		spec.setDestinationDatabase("dstdb");
		spec.setBusinessDayBehavior(BusinessDayBehaviorEnum.ALL);
		DataTransferSpecification spec2 = new DataTransferSpecification();
		spec2.setSourceTable("source_country_table2");
		spec2.setSourceDatabase("srcDb2");
		spec2.setDestinationTable("dstTable2");
		spec2.setDestinationDatabase("dstdb2");
		spec2.setBusinessDayBehavior(BusinessDayBehaviorEnum.LATEST);
		workflow.getDataTransferSpecification().add(spec);
		when(dataAccess.retrieveById(EdmDataSource.class, "src")).thenReturn(workflow.getSource());
		when(dataAccess.retrieveById(EdmDataSource.class, "dst")).thenReturn(workflow.getDestination());
		when(dataAccess.retrieveById(EdmWorkflow.class, "wf")).thenReturn(null);
		when(dataAccess.saveOrUpdateObject(any(EdmWorkflow.class))).thenReturn(workflow);

		EdmWorkflow result = fixture.createWorkflow(workflow);

		assertNotNull(result);
	}

	/**
	 * Run the EdmWorkflow createWorkflow(EdmWorkflow) method test.
	 *
	 * @throws Exception
	 *
	 */
	@Test(expected = com.scb.edmhdpef.exceptions.EdmHdpEfAppException.class)
	public void testCreateWorkflow_24() throws Exception {
		EdmWorkflow workflow = new EdmWorkflow();
		workflow.setName("wf");
		workflow.setType(EdmWorkflowTypeEnum.TABLE_GROUP);
		workflow.setSource(new EdmDataSource());
		workflow.setDestination(new EdmDataSource());
		workflow.getSource().setName("src");
		workflow.getSource().setType(EdmDataSourceTypeEnum.HIVE);
		workflow.getDestination().setName("dst");
		workflow.getDestination().setType(EdmDataSourceTypeEnum.TERADATA);
		workflow.setDataTransferSpecification(new ArrayList<DataTransferSpecification>());
		DataTransferSpecification spec = new DataTransferSpecification();
		spec.setSourceTable("source_country_table");
		spec.setSourceDatabase("srcDb");
		spec.setDestinationTable("dstTable");
		spec.setDestinationDatabase("dstdb");
		spec.setBusinessDayBehavior(BusinessDayBehaviorEnum.ALL);
		DataTransferSpecification spec2 = new DataTransferSpecification();
		spec2.setSourceTable("source_country_table2");
		spec2.setSourceDatabase("srcDb2");
		spec2.setDestinationTable("dstTable2");
		spec2.setDestinationDatabase("dstdb2");
		spec2.setBusinessDayBehavior(BusinessDayBehaviorEnum.ALL);
		workflow.getDataTransferSpecification().add(spec);
		workflow.getDataTransferSpecification().add(spec2);
		when(dataAccess.retrieveById(EdmDataSource.class, "src")).thenReturn(workflow.getSource());
		when(dataAccess.retrieveById(EdmDataSource.class, "dst")).thenReturn(workflow.getDestination());
		when(dataAccess.retrieveById(EdmWorkflow.class, "wf")).thenReturn(null);
		when(dataAccess.saveOrUpdateObject(any(EdmWorkflow.class))).thenReturn(workflow);

		EdmWorkflow result = fixture.createWorkflow(workflow);

		assertNotNull(result);
	}

	/**
	 * Run the EdmWorkflow createWorkflow(EdmWorkflow) method test.
	 *
	 * @throws Exception
	 *
	 */
	@Test
	public void testCreateWorkflow_25() throws Exception {
		EdmWorkflow workflow = new EdmWorkflow();
		workflow.setName("wf");
		workflow.setType(EdmWorkflowTypeEnum.TABLE_GROUP);
		workflow.setSource(new EdmDataSource());
		workflow.setDestination(new EdmDataSource());
		workflow.getSource().setName("src");
		workflow.getSource().setType(EdmDataSourceTypeEnum.HIVE);
		workflow.getDestination().setName("dst");
		workflow.getDestination().setType(EdmDataSourceTypeEnum.TERADATA);
		workflow.setDataTransferSpecification(new ArrayList<DataTransferSpecification>());
		DataTransferSpecification spec = new DataTransferSpecification();
		spec.setSourceTable("source_country_table");
		spec.setSourceDatabase("srcDb");
		spec.setDestinationTable("dstTable");
		spec.setDestinationDatabase("dstdb");
		spec.setBusinessDayBehavior(BusinessDayBehaviorEnum.ALL);
		DataTransferSpecification spec2 = new DataTransferSpecification();
		spec2.setSourceTable("source_country_table2");
		spec2.setSourceDatabase("srcDb2");
		spec2.setDestinationTable("dstTable2");
		spec2.setDestinationDatabase("dstdb2");
		spec2.setBusinessDayBehavior(BusinessDayBehaviorEnum.ALL);
		workflow.getDataTransferSpecification().add(spec);
		workflow.getDataTransferSpecification().add(spec2);
		workflow.setBatchToPartitionDatabase("storage");
		when(dataAccess.retrieveById(EdmDataSource.class, "src")).thenReturn(workflow.getSource());
		when(dataAccess.retrieveById(EdmDataSource.class, "dst")).thenReturn(workflow.getDestination());
		when(dataAccess.retrieveById(EdmWorkflow.class, "wf")).thenReturn(null);
		when(dataAccess.saveOrUpdateObject(any(EdmWorkflow.class))).thenReturn(workflow);

		EdmWorkflow result = fixture.createWorkflow(workflow);

		assertNotNull(result);
	}

	/**
	 * Run the void deleteWorkflow(EdmWorkflow) method test.
	 *
	 * @throws Exception
	 *
	 */
	@Test(expected = com.scb.edmhdpef.exceptions.EdmHdpEfAppException.class)
	public void testDeleteWorkflow_1() throws Exception {
		EdmWorkflow workflow = new EdmWorkflow();
		workflow.setName((String) null);

		fixture.deleteWorkflow(workflow);
	}

	/**
	 * Run the void deleteWorkflow(EdmWorkflow) method test.
	 *
	 * @throws Exception
	 *
	 */
	@Test(expected = com.scb.edmhdpef.exceptions.EdmHdpEfAppException.class)
	public void testDeleteWorkflow_2() throws Exception {
		EdmWorkflow workflow = new EdmWorkflow();
		workflow.setName("");

		fixture.deleteWorkflow(workflow);
	}

	/**
	 * Run the void deleteWorkflow(EdmWorkflow) method test.
	 *
	 * @throws Exception
	 *
	 */
	@Test(expected = com.scb.edmhdpef.exceptions.EdmHdpEfAppException.class)
	public void testDeleteWorkflow_3() throws Exception {
		EdmWorkflow workflow = new EdmWorkflow();
		workflow.setName("wf");

		fixture.deleteWorkflow(workflow);
	}

	/**
	 * Run the void deleteWorkflow(EdmWorkflow) method test.
	 *
	 * @throws Exception
	 *
	 */
	@Test
	public void testDeleteWorkflow_4() throws Exception {
		EdmWorkflow workflow = new EdmWorkflow();
		workflow.setName("wf");

		when(dataAccess.retrieveById(EdmWorkflow.class, "wf")).thenReturn(workflow);

		fixture.deleteWorkflow(workflow);
	}

	/**
	 * Run the List<EdmWorkflow> retrieveWorkflows(EdmWorkflow) method test.
	 *
	 * @throws Exception
	 *
	 */
	@Test
	public void testRetrieveWorkflows_1() throws Exception {

		List<EdmWorkflow> result = fixture.retrieveWorkflows(null);
		assertNotNull(result);
	}

	/**
	 * Run the List<EdmWorkflow> retrieveWorkflows(EdmWorkflow) method test.
	 *
	 * @throws Exception
	 *
	 */
	@Test
	public void testRetrieveWorkflows_2() throws Exception {
		EdmWorkflow criteria = new EdmWorkflow();
		criteria.setName("");

		List<EdmWorkflow> result = fixture.retrieveWorkflows(criteria);
		assertNotNull(result);
	}

	/**
	 * Run the List<EdmWorkflow> retrieveWorkflows(EdmWorkflow) method test.
	 *
	 * @throws Exception
	 *
	 */
	@Test
	public void testRetrieveWorkflows_3() throws Exception {
		EdmWorkflow criteria = new EdmWorkflow();
		criteria.setName("wf");

		List<EdmWorkflow> result = fixture.retrieveWorkflows(criteria);

		assertNotNull(result);
	}

	/**
	 * Run the EdmWorkflow updateWorkflow(EdmWorkflow) method test.
	 *
	 * @throws Exception
	 *
	 */
	@Test(expected = com.scb.edmhdpef.exceptions.EdmHdpEfAppException.class)
	public void testUpdateWorkflow_1() throws Exception {
		EdmWorkflow workflow = new EdmWorkflow();

		EdmWorkflow result = fixture.updateWorkflow(workflow);

		assertNotNull(result);
	}

	/**
	 * Run the EdmWorkflow updateWorkflow(EdmWorkflow) method test.
	 *
	 * @throws Exception
	 *
	 */
	@Test(expected = com.scb.edmhdpef.exceptions.EdmHdpEfAppException.class)
	public void testUpdateWorkflow_2() throws Exception {
		EdmWorkflow workflow = new EdmWorkflow();
		workflow.setName("");

		EdmWorkflow result = fixture.updateWorkflow(workflow);

		assertNotNull(result);
	}

	/**
	 * Run the EdmWorkflow updateWorkflow(EdmWorkflow) method test.
	 *
	 * @throws Exception
	 *
	 */
	@Test(expected = com.scb.edmhdpef.exceptions.EdmHdpEfAppException.class)
	public void testUpdateWorkflow_4() throws Exception {
		EdmWorkflow workflow = new EdmWorkflow();
		workflow.setType(EdmWorkflowTypeEnum.TABLE_GROUP);
		workflow.setDataTransferSpecification(new LinkedList<DataTransferSpecification>());
		workflow.setDescription("");
		workflow.setName("wf");

		EdmWorkflow result = fixture.updateWorkflow(workflow);

		assertNotNull(result);
	}

	/**
	 * Run the EdmWorkflow updateWorkflow(EdmWorkflow) method test.
	 *
	 * @throws Exception
	 *
	 */
	@Test(expected = com.scb.edmhdpef.exceptions.EdmHdpEfAppException.class)
	public void testUpdateWorkflow_5() throws Exception {
		EdmWorkflow workflow = new EdmWorkflow();
		workflow.setType(EdmWorkflowTypeEnum.TABLE_GROUP);
		workflow.setDataTransferSpecification(new LinkedList<DataTransferSpecification>());
		workflow.setDescription("");
		workflow.setName("wf");
		workflow.getDataTransferSpecification().add(new DataTransferSpecification());

		EdmWorkflow result = fixture.updateWorkflow(workflow);

		assertNotNull(result);
	}

	/**
	 * Run the EdmWorkflow updateWorkflow(EdmWorkflow) method test.
	 *
	 * @throws Exception
	 *
	 */
	@Test(expected = com.scb.edmhdpef.exceptions.EdmHdpEfAppException.class)
	public void testUpdateWorkflow_6() throws Exception {

		EdmWorkflow workflow = new EdmWorkflow();
		workflow.setName("wf");
		workflow.setType(EdmWorkflowTypeEnum.TABLE_GROUP);
		workflow.setSource(new EdmDataSource());
		workflow.setDestination(new EdmDataSource());
		workflow.getSource().setName("src");
		workflow.getSource().setType(EdmDataSourceTypeEnum.HIVE);
		workflow.getDestination().setName("dst");
		workflow.getDestination().setType(EdmDataSourceTypeEnum.TERADATA);
		workflow.setDataTransferSpecification(new ArrayList<DataTransferSpecification>());
		DataTransferSpecification spec = new DataTransferSpecification();
		spec.setSourceTable("source_country_table");
		spec.setSourceDatabase("srcDb");
		spec.setDestinationTable("dstTable");
		spec.setDestinationDatabase("dstdb");
		workflow.getDataTransferSpecification().add(spec);

		when(dataAccess.retrieveById(EdmDataSource.class, "src")).thenReturn(workflow.getSource());
		when(dataAccess.retrieveById(EdmDataSource.class, "dst")).thenReturn(workflow.getDestination());
		when(dataAccess.retrieveById(EdmWorkflow.class, "wf")).thenReturn(null);

		EdmWorkflow result = fixture.updateWorkflow(workflow);

		assertNotNull(result);
	}

	/**
	 * Run the EdmWorkflow updateWorkflow(EdmWorkflow) method test.
	 *
	 * @throws Exception
	 *
	 */
	@Test
	public void testUpdateWorkflow_7() throws Exception {

		EdmWorkflow workflow = new EdmWorkflow();
		workflow.setName("wf");
		workflow.setType(EdmWorkflowTypeEnum.TABLE_GROUP);
		workflow.setSource(new EdmDataSource());
		workflow.setDestination(new EdmDataSource());
		workflow.getSource().setName("src");
		workflow.getSource().setType(EdmDataSourceTypeEnum.HIVE);
		workflow.getDestination().setName("dst");
		workflow.getDestination().setType(EdmDataSourceTypeEnum.TERADATA);
		workflow.setDataTransferSpecification(new ArrayList<DataTransferSpecification>());
		DataTransferSpecification spec = new DataTransferSpecification();
		spec.setSourceTable("source_country_table");
		spec.setSourceDatabase("srcDb");
		spec.setDestinationTable("dstTable");
		spec.setDestinationDatabase("dstdb");
		workflow.getDataTransferSpecification().add(spec);

		when(dataAccess.retrieveById(EdmDataSource.class, "src")).thenReturn(workflow.getSource());
		when(dataAccess.retrieveById(EdmDataSource.class, "dst")).thenReturn(workflow.getDestination());
		when(dataAccess.retrieveById(EdmWorkflow.class, "wf")).thenReturn(workflow);
		when(dataAccess.saveOrUpdateObject(any(EdmWorkflow.class))).thenReturn(workflow);

		EdmWorkflow result = fixture.updateWorkflow(workflow);

		assertNotNull(result);
	}

}