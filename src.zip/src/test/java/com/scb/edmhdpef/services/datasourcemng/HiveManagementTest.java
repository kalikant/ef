package com.scb.edmhdpef.services.datasourcemng;

import com.scb.edmhdpef.EdmhdpefCommon;
import com.scb.edmhdpef.EdmhdpefConstants;
import com.scb.edmhdpef.config.EdmhdpefConfiguration;
import com.scb.edmhdpef.entity.DataTransferSpecification;
import com.scb.edmhdpef.entity.EdmColumns;
import com.scb.edmhdpef.entity.EdmDataSource;
import com.scb.edmhdpef.entity.EdmWorkflow;
import com.scb.edmhdpef.enums.BusinessDayBehaviorEnum;
import com.scb.edmhdpef.enums.EdmDataSourceTypeEnum;
import com.scb.edmhdpef.enums.EdmWorkflowTypeEnum;
import com.scb.edmhdpef.exceptions.EdmHdpEfAppException;
import com.scb.edmhdpef.exceptions.EdmHdpEfInternalException;
import com.scb.edmhdpef.exceptions.EdmHdpEfNotImplementedException;
import com.scb.edmhdpef.services.architecture.TemplateCreation;
import org.apache.html.dom.HTMLDocumentImpl;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.web.WebAppConfiguration;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.util.*;

import static org.junit.Assert.*;

@RunWith(MockitoJUnitRunner.class)
@WebAppConfiguration
@ContextConfiguration(classes = { EdmhdpefConfiguration.class })
public class HiveManagementTest {

	private Document doc;

	@Mock
	private TemplateCreation templateCreation;

	@Mock
	private OozieActionBuilder oozieActionBuilder;

	@Autowired
	@InjectMocks
	private HiveManagement fixture;

	@Before
	public void setUp() throws ParserConfigurationException {
		MockitoAnnotations.initMocks(this);

		DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder docBuilder = docFactory.newDocumentBuilder();

		doc = docBuilder.newDocument();
	}

	/**
	 * Run the List<Element> getDestinationActions(Document,EdmWorkflow) method
	 * test.
	 *
	 * @throws Exception
	 */
	@Test(expected = EdmHdpEfNotImplementedException.class)
	public void testGetDestinationActions_1() throws Exception {

		Document doc = new HTMLDocumentImpl();
		EdmWorkflow workflow = new EdmWorkflow();

		List<Element> result = fixture.getDeployDstActions(doc, workflow);

		assertNotNull(result);
	}

	/**
	 * Run the Map<String, String> getDestinationScripts(EdmWorkflow) method
	 * test.
	 *
	 * @throws Exception
	 */
	@Test(expected = EdmHdpEfNotImplementedException.class)
	public void testGetDestinationScripts_1() throws Exception {

		EdmWorkflow workflow = new EdmWorkflow();

		Map<String, String> result = fixture.getDeployDstScripts(workflow);

		assertNotNull(result);
	}

	/**
	 * Run the List<Element> getSourceActions(Document,EdmWorkflow) method test.
	 *
	 * @throws Exception
	 */
	@Test(expected = EdmHdpEfInternalException.class)
	public void testGetSourceActions_1() throws Exception {

		Document doc = new HTMLDocumentImpl();
		EdmWorkflow workflow = new EdmWorkflow();

		List<Element> result = fixture.getDeploySrcActions(doc, workflow);

		assertNotNull(result);
	}

	/**
	 * Run the List<Element> getSourceActions(Document,EdmWorkflow) method test.
	 *
	 * @throws Exception
	 */
	@Test(expected = EdmHdpEfInternalException.class)
	public void testGetSourceActions_2() throws Exception {

		Document doc = new HTMLDocumentImpl();
		EdmWorkflow workflow = new EdmWorkflow();
		workflow.setSource(new EdmDataSource());
		workflow.setDestination(new EdmDataSource());
		workflow.setParameters(new HashSet<String>());
		workflow.setName("wf");

		List<Element> result = fixture.getDeploySrcActions(doc, workflow);

		assertNotNull(result);
	}

	/**
	 * Run the List<Element> getSourceActions(Document,EdmWorkflow) method test.
	 *
	 * @throws Exception
	 */
	@Test(expected = EdmHdpEfInternalException.class)
	public void testGetSourceActions_3() throws Exception {

		Document doc = new HTMLDocumentImpl();
		EdmWorkflow workflow = new EdmWorkflow();
		workflow.setSource(new EdmDataSource());
		workflow.setDestination(new EdmDataSource());
		workflow.setParameters(new HashSet<String>());
		workflow.setBatchToPartitionDatabase("");
		workflow.setName("wf");

		List<Element> result = fixture.getDeploySrcActions(doc, workflow);

		assertNotNull(result);
	}

	/**
	 * Run the List<Element> getSourceActions(Document,EdmWorkflow) method test.
	 *
	 * @throws Exception
	 */
	@Test(expected = EdmHdpEfInternalException.class)
	public void testGetSourceActions_4() throws Exception {

		Document doc = new HTMLDocumentImpl();
		EdmWorkflow workflow = new EdmWorkflow();
		workflow.setSource(new EdmDataSource());
		workflow.setDestination(new EdmDataSource());
		workflow.setBatchToPartitionDatabase("");
		workflow.setName("wf");
		HashSet<String> params = new HashSet<String>();
		params.add("p1");
		workflow.setParameters(params);

		List<Element> result = fixture.getDeploySrcActions(doc, workflow);

		assertNotNull(result);
	}

	/**
	 * Run the List<Element> getSourceActions(Document,EdmWorkflow) method test.
	 *
	 * @throws Exception
	 */
	@Test(expected = EdmHdpEfInternalException.class)
	public void testGetSourceActions_5() throws Exception {

		Document doc = new HTMLDocumentImpl();
		EdmWorkflow workflow = new EdmWorkflow();
		workflow.setSource(new EdmDataSource());
		workflow.setDestination(new EdmDataSource());
		workflow.setBatchToPartitionDatabase("");
		workflow.setName("wf");
		HashSet<String> params = new HashSet<String>();
		params.add("p1");
		params.add("businessday");
		workflow.setParameters(params);

		List<Element> result = fixture.getDeploySrcActions(doc, workflow);

		assertNotNull(result);
	}

	/**
	 * Run the List<Element> getSourceActions(Document,EdmWorkflow) method test.
	 *
	 * @throws Exception
	 */
	@Test
	public void testGetSourceActions_6() throws Exception {

		Document doc = new HTMLDocumentImpl();
		EdmWorkflow workflow = new EdmWorkflow();

		EdmDataSource source = new EdmDataSource();
		source.setType(EdmDataSourceTypeEnum.HIVE);
		source.setParameters(new HashMap<String, String>());
		workflow.setSource(source);

		EdmDataSource destination = new EdmDataSource();
		destination.setType(EdmDataSourceTypeEnum.TERADATA);
		destination.setParameters(new HashMap<String, String>());
		workflow.setDestination(destination);

		workflow.setType(EdmWorkflowTypeEnum.TABLE_GROUP);

		workflow.setBatchToPartitionDatabase("");
		workflow.setName("wf");
		HashSet<String> params = new HashSet<String>();
		params.add("p1");
		params.add("businessday");
		workflow.setParameters(params);
		List<DataTransferSpecification> dataTransferSpecification = new ArrayList<DataTransferSpecification>();
		DataTransferSpecification spec = new DataTransferSpecification();
		dataTransferSpecification.add(spec);
		workflow.setDataTransferSpecification(dataTransferSpecification);

		List<Element> result = fixture.getDeploySrcActions(doc, workflow);

		assertNotNull(result);
	}

	/**
	 * Run the List<Element> getSourceActions(Document,EdmWorkflow) method test.
	 *
	 * @throws Exception
	 */
	@Test(expected = EdmHdpEfInternalException.class)
	public void testGetSourceScripts_1() throws Exception {

		EdmWorkflow workflow = new EdmWorkflow();

		Map<String, String> result = fixture.getDeploySrcScripts(workflow);

		assertNotNull(result);
		assertTrue(result.isEmpty());
	}

	/**
	 * Run the List<Element> getSourceActions(Document,EdmWorkflow) method test.
	 *
	 * @throws Exception
	 */
	@Test(expected = EdmHdpEfInternalException.class)
	public void testGetSourceScripts_2() throws Exception {

		EdmWorkflow workflow = new EdmWorkflow();
		workflow.setSource(new EdmDataSource());
		workflow.setDestination(new EdmDataSource());
		workflow.setParameters(new HashSet<String>());
		workflow.setName("wf");
		workflow.setType(EdmWorkflowTypeEnum.TABLE_GROUP);

		Map<String, String> result = fixture.getDeploySrcScripts(workflow);

		assertNotNull(result);
		Set<String> expected = new HashSet<String>();
		assertEquals(expected, result.keySet());
	}

	/**
	 * Run the List<Element> getSourceActions(Document,EdmWorkflow) method test.
	 *
	 * @throws Exception
	 */
	@Test(expected = EdmHdpEfInternalException.class)
	public void testGetSourceScripts_3() throws Exception {

		EdmWorkflow workflow = new EdmWorkflow();
		workflow.setSource(new EdmDataSource());
		workflow.setDestination(new EdmDataSource());
		workflow.setParameters(new HashSet<String>());
		workflow.setBatchToPartitionDatabase("");
		workflow.setName("wf");
		workflow.setType(EdmWorkflowTypeEnum.TABLE_GROUP);

		Map<String, String> result = fixture.getDeploySrcScripts(workflow);

		assertNotNull(result);
		Set<String> expected = new HashSet<String>();
		assertEquals(expected, result.keySet());
	}

	/**
	 * Run the List<Element> getSourceActions(Document,EdmWorkflow) method test.
	 *
	 * @throws Exception
	 */
	@Test(expected = EdmHdpEfInternalException.class)
	public void testGetSourceScripts_4() throws Exception {

		EdmWorkflow workflow = new EdmWorkflow();
		workflow.setSource(new EdmDataSource());
		workflow.setDestination(new EdmDataSource());
		workflow.setBatchToPartitionDatabase("");
		workflow.setName("wf");
		workflow.setType(EdmWorkflowTypeEnum.TABLE_GROUP);

		HashSet<String> params = new HashSet<String>();
		params.add("p1");
		workflow.setParameters(params);

		Map<String, String> result = fixture.getDeploySrcScripts(workflow);

		assertNotNull(result);
		Set<String> expected = new HashSet<String>();
		assertEquals(expected, result.keySet());
	}

	/**
	 * Run the List<Element> getSourceActions(Document,EdmWorkflow) method test.
	 *
	 * @throws Exception
	 */
	@Test(expected = EdmHdpEfInternalException.class)
	public void testGetSourceScripts_5() throws Exception {

		EdmWorkflow workflow = new EdmWorkflow();
		workflow.setSource(new EdmDataSource());
		workflow.setDestination(new EdmDataSource());
		workflow.setBatchToPartitionDatabase("");
		workflow.setName("wf");
		workflow.setType(EdmWorkflowTypeEnum.TABLE_GROUP);

		HashSet<String> params = new HashSet<String>();
		params.add("p1");
		params.add("businessday");
		workflow.setParameters(params);

		Map<String, String> result = fixture.getDeploySrcScripts(workflow);

		assertNotNull(result);
		Set<String> expected = new HashSet<String>();
		assertEquals(expected, result.keySet());
	}

	/**
	 * Run the List<Element> getSourceActions(Document,EdmWorkflow) method test.
	 *
	 * @throws Exception
	 */
	@Test
	public void testGetSourceScripts_6() throws Exception {

		EdmWorkflow workflow = new EdmWorkflow();

		EdmDataSource source = new EdmDataSource();
		source.setType(EdmDataSourceTypeEnum.HIVE);
		source.setParameters(new HashMap<String, String>());
		workflow.setSource(source);

		EdmDataSource destination = new EdmDataSource();
		destination.setType(EdmDataSourceTypeEnum.TERADATA);
		destination.setParameters(new HashMap<String, String>());
		workflow.setDestination(destination);

		workflow.setBatchToPartitionDatabase("");
		workflow.setName("wf");
		workflow.setType(EdmWorkflowTypeEnum.TABLE_GROUP);

		HashSet<String> params = new HashSet<String>();
		params.add("p1");
		params.add("businessday");
		workflow.setParameters(params);
		List<DataTransferSpecification> dataTransferSpecification = new ArrayList<DataTransferSpecification>();
		DataTransferSpecification spec = new DataTransferSpecification();
		dataTransferSpecification.add(spec);
		workflow.setDataTransferSpecification(dataTransferSpecification);

		Map<String, String> result = fixture.getDeploySrcScripts(workflow);

		assertNotNull(result);
		Set<String> expected = new HashSet<String>();
		expected.add("wf-src.hql");
		assertEquals(expected, result.keySet());
	}

	/**
	 * Run the List<Element> getSourceActions(Document,EdmWorkflow) method test.
	 *
	 * @throws Exception
	 */
	@Test
	public void testGetSourceScripts_7() throws Exception {

		EdmWorkflow workflow = new EdmWorkflow();

		EdmDataSource source = new EdmDataSource();
		source.setType(EdmDataSourceTypeEnum.HIVE);
		source.setParameters(new HashMap<String, String>());
		workflow.setSource(source);

		EdmDataSource destination = new EdmDataSource();
		destination.setType(EdmDataSourceTypeEnum.TERADATA);
		destination.setParameters(new HashMap<String, String>());
		workflow.setDestination(destination);

		workflow.setBatchToPartitionDatabase("");
		workflow.setName("wf");
		workflow.setType(EdmWorkflowTypeEnum.TABLE_GROUP);

		HashSet<String> params = new HashSet<String>();
		params.add("p1");
		params.add("businessday");
		workflow.setParameters(params);
		List<DataTransferSpecification> dataTransferSpecification = new ArrayList<DataTransferSpecification>();
		DataTransferSpecification spec = new DataTransferSpecification();
		dataTransferSpecification.add(spec);
		DataTransferSpecification spec2 = new DataTransferSpecification();
		dataTransferSpecification.add(spec2);
		workflow.setDataTransferSpecification(dataTransferSpecification);

		Map<String, String> result = fixture.getDeploySrcScripts(workflow);

		assertNotNull(result);
		Set<String> expected = new HashSet<String>();
		expected.add("wf-src.hql");
		assertEquals(expected, result.keySet());
	}

	/**
	 * Run the List<Element> getSourceActions(Document,EdmWorkflow) method test.
	 *
	 * @throws Exception
	 */
	@Test
	public void testGetSourceScripts_8() throws Exception {

		EdmWorkflow workflow = new EdmWorkflow();

		EdmDataSource source = new EdmDataSource();
		source.setType(EdmDataSourceTypeEnum.HIVE);
		source.setParameters(new HashMap<String, String>());
		workflow.setSource(source);

		EdmDataSource destination = new EdmDataSource();
		destination.setType(EdmDataSourceTypeEnum.TERADATA);
		destination.setParameters(new HashMap<String, String>());
		workflow.setDestination(destination);

		workflow.setBatchToPartitionDatabase("");
		workflow.setName("wf");
		workflow.setType(EdmWorkflowTypeEnum.TABLE_GROUP);

		HashSet<String> params = new HashSet<String>();
		params.add("p1");
		params.add("businessday");
		workflow.setParameters(params);
		List<DataTransferSpecification> dataTransferSpecification = new ArrayList<DataTransferSpecification>();
		DataTransferSpecification spec = new DataTransferSpecification();
		spec.setFilterCondition("col1=2");
		dataTransferSpecification.add(spec);
		workflow.setDataTransferSpecification(dataTransferSpecification);

		Map<String, String> result = fixture.getDeploySrcScripts(workflow);

		assertNotNull(result);
		Set<String> expected = new HashSet<String>();
		expected.add("wf-src.hql");
		assertEquals(expected, result.keySet());
	}

	/**
	 * Run the boolean isBusinessDayRequired(EdmWorkflow) method test.
	 *
	 * @throws Exception
	 */
	@Test
	public void testIsBusinessDayRequired_1() throws Exception {

		EdmWorkflow workflow = new EdmWorkflow();
		workflow.setDataTransferSpecification(new LinkedList<DataTransferSpecification>());

		boolean result = EdmhdpefCommon.isBusinessDayRequired(workflow);

		// add additional test code here
		assertEquals(false, result);
	}

	@Test
	public void sourceActions_NoBDay() throws EdmHdpEfAppException, EdmHdpEfInternalException {

		List<Element> elements = fixture.getDeploySrcActions(doc, getWorkflow());

		Assert.assertEquals(1, elements.size());
	}

	@Test
	public void sourceActions_BDayLatest() throws EdmHdpEfAppException, EdmHdpEfInternalException {

		EdmWorkflow workflow = getWorkflow();
		for (DataTransferSpecification spec : workflow.getDataTransferSpecification()) {
			spec.setBusinessDayBehavior(BusinessDayBehaviorEnum.LATEST);
		}

		List<Element> elements = fixture.getDeploySrcActions(doc, workflow);

		Assert.assertEquals(2, elements.size());

	}

	@Test
	public void sourceActions_BDayAll() throws EdmHdpEfAppException, EdmHdpEfInternalException {

		EdmWorkflow workflow = getWorkflow();
		for (DataTransferSpecification spec : workflow.getDataTransferSpecification()) {
			spec.setBusinessDayBehavior(BusinessDayBehaviorEnum.ALL);
		}

		List<Element> elements = fixture.getDeploySrcActions(doc, workflow);

		Assert.assertEquals(2, elements.size());
	}

	@Test
	public void sourceScripts_NoBDay() throws EdmHdpEfAppException, EdmHdpEfInternalException {

		Map<String, String> scripts = fixture.getDeploySrcScripts(getWorkflow());

		Assert.assertEquals(1, scripts.size());
		Assert.assertTrue(scripts.containsKey("workflow-src.hql"));

	}

	@Test
	public void sourceScripts_BDayLatest() throws EdmHdpEfAppException, EdmHdpEfInternalException {

		EdmWorkflow workflow = getWorkflow();
		for (DataTransferSpecification spec : workflow.getDataTransferSpecification()) {
			spec.setBusinessDayBehavior(BusinessDayBehaviorEnum.LATEST);
		}

		Map<String, String> scripts = fixture.getDeploySrcScripts(workflow);

		Assert.assertEquals(2, scripts.size());
		Assert.assertTrue(scripts.containsKey("getPartitionInfoForBusinessDay.sh"));
		Assert.assertTrue(scripts.containsKey("workflow-src.hql"));
	}

	@Test
	public void sourceScripts_BDayAll() throws EdmHdpEfAppException, EdmHdpEfInternalException {

		EdmWorkflow workflow = getWorkflow();
		for (DataTransferSpecification spec : workflow.getDataTransferSpecification()) {
			spec.setBusinessDayBehavior(BusinessDayBehaviorEnum.ALL);
		}

		Map<String, String> scripts = fixture.getDeploySrcScripts(workflow);

		Assert.assertEquals(2, scripts.size());
		Assert.assertTrue(scripts.containsKey("getPartitionInfoForBusinessDay.sh"));
		Assert.assertTrue(scripts.containsKey("workflow-src.hql"));

	}

	@Test
	public void isBusinessDayRequired_NO_false() {
		boolean result = EdmhdpefCommon.isBusinessDayRequired(getWorkflow());
		Assert.assertFalse(result);
	}

	@Test
	public void isBusinessDayRequired_notset_false() {
		EdmWorkflow workflow = getWorkflow();
		for (DataTransferSpecification spec : workflow.getDataTransferSpecification()) {
			spec.setBusinessDayBehavior(null);
		}
		boolean result = EdmhdpefCommon.isBusinessDayRequired(workflow);
		Assert.assertFalse(result);
	}

	@Test
	public void isBusinessDayRequired_ALL_true() {
		EdmWorkflow workflow = getWorkflow();
		for (DataTransferSpecification spec : workflow.getDataTransferSpecification()) {
			spec.setBusinessDayBehavior(BusinessDayBehaviorEnum.ALL);
		}
		boolean result = EdmhdpefCommon.isBusinessDayRequired(workflow);
		Assert.assertTrue(result);
	}

	@Test
	public void isBusinessDayRequired_LATEST_true() {
		EdmWorkflow workflow = getWorkflow();
		for (DataTransferSpecification spec : workflow.getDataTransferSpecification()) {
			spec.setBusinessDayBehavior(BusinessDayBehaviorEnum.LATEST);
		}
		boolean result = EdmhdpefCommon.isBusinessDayRequired(workflow);
		Assert.assertTrue(result);
	}

	private EdmWorkflow getWorkflow() {
		EdmWorkflow workflow = new EdmWorkflow();
		workflow.setName("workflow");

		EdmDataSource source = new EdmDataSource();
		source.setType(EdmDataSourceTypeEnum.HIVE);
		source.setParameters(new HashMap<String, String>());
		source.getParameters().put(EdmhdpefConstants.DS_PARAM_HIVE_HIVESITEFILE, "fixture.xml");
		source.getParameters().put(EdmhdpefConstants.DS_PARAM_HIVE_TEZSITEFILE, "tez.xml");
		workflow.setSource(source);

		EdmDataSource destination = new EdmDataSource();
		destination.setType(EdmDataSourceTypeEnum.TERADATA);
		destination.setParameters(new HashMap<String, String>());
		workflow.setDestination(destination);

		workflow.setType(EdmWorkflowTypeEnum.TABLE_GROUP);
		List<DataTransferSpecification> specs = new ArrayList<DataTransferSpecification>();

		specs.add(createDataTransferSpecification("src", "dst"));
		specs.add(createDataTransferSpecification("src2", "dst2"));
		workflow.setDataTransferSpecification(specs);
		return workflow;
	}

	private DataTransferSpecification createDataTransferSpecification(String src, String dst) {
		DataTransferSpecification spec = new DataTransferSpecification();
		spec.setBusinessDayBehavior(BusinessDayBehaviorEnum.NO);
		spec.setSourceDatabase(src + "DB");
		spec.setSourceTable(src + "Table");
		spec.setDestinationDatabase(dst + "DB");
		spec.setDestinationTable(dst + "Table");
		List<EdmColumns> columns = new ArrayList<EdmColumns>();
		EdmColumns col = new EdmColumns();
		col.setDestination(dst + "Col");
		col.setSource(src + "Col");
		EdmColumns col2 = new EdmColumns();
		col2.setDestination(dst + "Col2");
		col2.setSource(src + "Col2");
		columns.add(col);
		columns.add(col2);
		spec.setColumns(columns);
		return spec;
	}
}
