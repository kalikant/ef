package com.scb.edmhdpef.services.architecture.security;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Collection;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.web.WebAppConfiguration;

import com.scb.edmhdpef.config.EdmhdpefConfiguration;

@RunWith(MockitoJUnitRunner.class)
@WebAppConfiguration
@ContextConfiguration(classes = { EdmhdpefConfiguration.class })
public class EFAuthenticationProviderTest {

	@Mock
	private UserDetailsService userDetailsService;

	@Autowired
	@InjectMocks
	private EFAuthenticationProvider provider;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
	}

	@Test(expected = NullPointerException.class)
	public final void testAuthenticate_1() {
		provider.authenticate(null);
	}

	@Test(expected = BadCredentialsException.class)
	public final void testAuthenticate_2() {
		Authentication auth = new Authentication() {

			private static final long serialVersionUID = 1L;

			@Override
			public String getName() {
				return "name";
			}

			@Override
			public void setAuthenticated(boolean isAuthenticated) throws IllegalArgumentException {


			}

			@Override
			public boolean isAuthenticated() {

				return false;
			}

			@Override
			public Object getPrincipal() {

				return null;
			}

			@Override
			public Object getDetails() {

				return null;
			}

			@Override
			public Object getCredentials() {

				return null;
			}

			@Override
			public Collection<? extends GrantedAuthority> getAuthorities() {

				return null;
			}
		};

		when(userDetailsService.loadUserByUsername(any(String.class))).thenReturn(null);

		Assert.assertNotNull(provider.authenticate(auth));
	}

	@Test
	public final void testAuthenticate_3() {
		Authentication auth = new Authentication() {

			private static final long serialVersionUID = 1L;

			@Override
			public String getName() {
				return "name";
			}

			@Override
			public void setAuthenticated(boolean isAuthenticated) throws IllegalArgumentException {


			}

			@Override
			public boolean isAuthenticated() {

				return false;
			}

			@Override
			public Object getPrincipal() {

				return null;
			}

			@Override
			public Object getDetails() {

				return null;
			}

			@Override
			public Object getCredentials() {

				return null;
			}

			@Override
			public Collection<? extends GrantedAuthority> getAuthorities() {

				return null;
			}
		};
		when(userDetailsService.loadUserByUsername(any(String.class)))
				.thenReturn(new User("user", "pass", new ArrayList<GrantedAuthority>()));

		Assert.assertNotNull(provider.authenticate(auth));
	}

	@Test
	public final void testSupports() {
		Assert.assertTrue(provider.supports(null));
	}

}
