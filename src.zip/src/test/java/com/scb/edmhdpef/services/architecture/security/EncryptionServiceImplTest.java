package com.scb.edmhdpef.services.architecture.security;

import java.util.HashMap;
import java.util.Map;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.web.WebAppConfiguration;

import com.scb.edmhdpef.config.EdmhdpefConfiguration;
import com.scb.edmhdpef.exceptions.EdmHdpEfInternalException;
import com.scb.edmhdpef.services.database.DataAccessService;

@RunWith(MockitoJUnitRunner.class)
@WebAppConfiguration
@ContextConfiguration(classes = { EdmhdpefConfiguration.class })
public class EncryptionServiceImplTest {

	@Mock
	private DataAccessService dataAccess;

	@Autowired
	@InjectMocks
	private EncryptionServiceImpl fixture;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		fixture.initIt();
	}

	@Test
	public final void testEncryptParameters_1() throws EdmHdpEfInternalException {
		Assert.assertNull(fixture.encryptParameters(null));
	}

	@Test
	public final void testEncryptParameters_2() throws EdmHdpEfInternalException {
		HashMap<String, String> hmap = new HashMap<String, String>();
		Assert.assertTrue(fixture.encryptParameters(hmap).isEmpty());
	}

	@Test
	public final void testEncryptParameters_3() throws EdmHdpEfInternalException {
		HashMap<String, String> hmap = new HashMap<String, String>();
		hmap.put("var1", "value1");
		Assert.assertEquals(fixture.encryptParameters(hmap), hmap);
	}

	@Test
	public final void testEncryptParameters_4() throws EdmHdpEfInternalException {
		HashMap<String, String> hmap1 = new HashMap<String, String>();
		hmap1.put("var1", "value1");
		hmap1.put("password", "pass1");
		Map<String, String> hmap2 = fixture.encryptParameters(hmap1);
		Assert.assertTrue(hmap2.get("password").startsWith("ENC"));
	}

	@Test
	public final void testDecryptParameters_1() throws EdmHdpEfInternalException {
		Assert.assertNull(fixture.decryptParameters(null));
	}

	@Test
	public final void testDecryptParameters_2() throws EdmHdpEfInternalException {
		HashMap<String, String> hmap = new HashMap<String, String>();
		Assert.assertTrue(fixture.decryptParameters(hmap).isEmpty());
	}

	@Test
	public final void testDecryptParameters_3() throws EdmHdpEfInternalException {
		HashMap<String, String> hmap = new HashMap<String, String>();
		hmap.put("var1", "value1");
		Assert.assertEquals(fixture.decryptParameters(hmap), hmap);
	}

	@Test(expected = EdmHdpEfInternalException.class)
	public final void testDecryptParameters_4() throws EdmHdpEfInternalException {
		HashMap<String, String> hmap1 = new HashMap<String, String>();
		hmap1.put("var1", "value1");
		hmap1.put("password", "ENC(Úb[{òç~ªv-f¤Fs)");
		Map<String, String> hmap2 = fixture.decryptParameters(hmap1);
		Assert.assertFalse(hmap2.get("password").startsWith("ENC"));
	}

}
