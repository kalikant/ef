package com.scb.edmhdpef.services.configuration;

import static org.junit.Assert.assertNotNull;

import java.util.HashMap;
import java.util.List;

import org.dozer.DozerBeanMapper;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.web.WebAppConfiguration;

import com.scb.edmhdpef.config.EdmhdpefConfiguration;
import com.scb.edmhdpef.entity.EdmDataSource;
import com.scb.edmhdpef.enums.EdmDataSourceTypeEnum;
import com.scb.edmhdpef.services.architecture.security.EncryptionService;
import com.scb.edmhdpef.services.database.DataAccessService;
import com.scb.edmhdpef.services.datasourcemng.DataSourceManagementSelector;

/**
 * The class <code>DatasourceConfigServiceImplTest</code> contains tests for the
 * class <code>{@link DatasourceConfigServiceImpl}</code>.
 */
@RunWith(MockitoJUnitRunner.class)
@WebAppConfiguration
@ContextConfiguration(classes = { EdmhdpefConfiguration.class })
public class DatasourceConfigServiceImplTest {
	@Mock
	DataAccessService dataAccess;

	@Mock
	EncryptionService encryptionService;

	@Mock
	DataSourceManagementSelector dataSourceManagementSelector;

	@Mock
	DozerBeanMapper mappingService;

	@Autowired
	@InjectMocks
	DatasourceConfigServiceImpl fixture;

	/**
	 * Perform pre-test initialization.
	 *
	 * @throws Exception
	 *             if the initialization fails for some reason
	 */
	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
	}

	/**
	 * Run the EdmDataSource createDataSource(EdmDataSource) method test.
	 *
	 * @throws Exception
	 *
	 */
	@Test(expected = com.scb.edmhdpef.exceptions.EdmHdpEfAppException.class)
	public void testCreateDataSource_1() throws Exception {
		EdmDataSource dataSource = new EdmDataSource();

		EdmDataSource result = fixture.createDataSource(dataSource);

		assertNotNull(result);
	}

	/**
	 * Run the EdmDataSource createDataSource(EdmDataSource) method test.
	 *
	 * @throws Exception
	 *
	 */
	@Test(expected = com.scb.edmhdpef.exceptions.EdmHdpEfAppException.class)
	public void testCreateDataSource_3() throws Exception {
		EdmDataSource dataSource = new EdmDataSource();
		dataSource.setName("");

		EdmDataSource result = fixture.createDataSource(dataSource);

		assertNotNull(result);
	}

	/**
	 * Run the void deleteDataSource(EdmDataSource) method test.
	 *
	 * @throws Exception
	 *
	 */
	@Test(expected = com.scb.edmhdpef.exceptions.EdmHdpEfAppException.class)
	public void testDeleteDataSource_1() throws Exception {
		EdmDataSource dataSource = new EdmDataSource();
		dataSource.setName((String) null);

		fixture.deleteDataSource(dataSource);
	}

	/**
	 * Run the List<EdmDataSource> retrieveDataSources(EdmDataSource) method
	 * test.
	 *
	 * @throws Exception
	 *
	 */
	@Test
	public void testRetrieveDataSources_1() throws Exception {
		EdmDataSource criteria = new EdmDataSource();
		criteria.setName("");

		List<EdmDataSource> result = fixture.retrieveDataSources(criteria);

		assertNotNull(result);
	}

	/**
	 * Run the EdmDataSource updateDataSource(EdmDataSource) method test.
	 *
	 * @throws Exception
	 *
	 */
	@Test(expected = com.scb.edmhdpef.exceptions.EdmHdpEfAppException.class)
	public void testUpdateDataSource_1() throws Exception {
		EdmDataSource dataSource = new EdmDataSource();

		EdmDataSource result = fixture.updateDataSource(dataSource);

		assertNotNull(result);
	}

	/**
	 * Run the EdmDataSource updateDataSource(EdmDataSource) method test.
	 *
	 * @throws Exception
	 *
	 */
	@Test(expected = com.scb.edmhdpef.exceptions.EdmHdpEfAppException.class)
	public void testUpdateDataSource_2() throws Exception {
		EdmDataSource dataSource = new EdmDataSource();
		dataSource.setName("");

		EdmDataSource result = fixture.updateDataSource(dataSource);

		assertNotNull(result);
	}

	/**
	 * Run the EdmDataSource updateDataSource(EdmDataSource) method test.
	 *
	 * @throws Exception
	 *
	 */
	@Test(expected = com.scb.edmhdpef.exceptions.EdmHdpEfAppException.class)
	public void testUpdateDataSource_3() throws Exception {
		EdmDataSource dataSource = new EdmDataSource();
		dataSource.setName("");
		dataSource.setDescription("");
		dataSource.setType(EdmDataSourceTypeEnum.HIVE);
		dataSource.setParameters(new HashMap<String, String>());

		EdmDataSource result = fixture.updateDataSource(dataSource);

		assertNotNull(result);
	}
}