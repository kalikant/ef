package com.scb.edmhdpef.services.database;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Criterion;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.web.WebAppConfiguration;

import com.scb.edmhdpef.config.EdmhdpefConfiguration;
import com.scb.edmhdpef.entity.EdmDataSource;
import com.scb.edmhdpef.exceptions.EdmHdpEfInternalException;

@RunWith(MockitoJUnitRunner.class)
@WebAppConfiguration
@ContextConfiguration(classes = { EdmhdpefConfiguration.class })
public class DataAccessServiceImplTest {

	@Mock
	private SessionFactory sessionFactory;

	@Autowired
	@InjectMocks
	DataAccessServiceImpl dataAccessService;

	/**
	 * Perform pre-test initialization.
	 *
	 * @throws Exception
	 *             if the initialization fails for some reason
	 */
	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		Session session = Mockito.mock(Session.class);
		Criteria criteria = Mockito.mock(Criteria.class);
		when(sessionFactory.getCurrentSession()).thenReturn(session);
		when(session.createCriteria(any(Class.class))).thenReturn(criteria);
		when(criteria.add(any(Criterion.class))).thenReturn(criteria);
	}

	@Test(expected = java.lang.NullPointerException.class)
	public final void testRetrieveByCriteria_1() {
		Object o = this.dataAccessService.retrieveByCriteria(null);
		assertNull(o);
	}

	@Test
	public final void testRetrieveByCriteria_2() {
		List<Object> o = this.dataAccessService.retrieveByCriteria(new EdmDataSource());
		assertTrue(o.isEmpty());
	}

	@Test
	public final void testSaveOrUpdateObject_1() throws EdmHdpEfInternalException {
		Object o = this.dataAccessService.saveOrUpdateObject(null);
		assertNull(o);
	}

	@Test
	public final void testSaveOrUpdateObject_2() throws EdmHdpEfInternalException {
		EdmDataSource o = (EdmDataSource) this.dataAccessService.saveOrUpdateObject(new EdmDataSource());
		assertNotNull(o);
	}

	@Test
	public final void testDeleteObject_1() throws EdmHdpEfInternalException {
		this.dataAccessService.deleteObject(null);
	}

	@Test
	public final void testDeleteObject_2() throws EdmHdpEfInternalException {
		this.dataAccessService.deleteObject(new EdmDataSource());
	}

	@Test
	public final void testRetrieveById_1() {
		EdmDataSource o = (EdmDataSource) this.dataAccessService.retrieveById(EdmDataSource.class, null);
		assertNull(o);
	}

	@Test
	public final void testRetrieveById_2() {
		EdmDataSource o = (EdmDataSource) this.dataAccessService.retrieveById(EdmDataSource.class, new String("id"));
		assertNull(o);
	}

}
