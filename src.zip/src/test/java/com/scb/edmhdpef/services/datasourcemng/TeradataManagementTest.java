package com.scb.edmhdpef.services.datasourcemng;

import static com.scb.edmhdpef.utils.TestUtils.unmarshal;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.spy;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.*;

import javax.xml.bind.JAXBException;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import com.scb.edmhdpef.controller.DataSourceController;
import com.scb.edmhdpef.controller.WorkflowController;
import com.scb.edmhdpef.services.configuration.WorkflowConfigService;
import com.scb.edmhdpef.services.execution.ExecutionService;
import com.scb.edmhdpef.vo.DeployWorkflowVO;
import com.scb.edmhdpef.vo.WorkflowDefinitionVO;
import org.apache.commons.io.FileUtils;
import org.apache.html.dom.HTMLDocumentImpl;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.junit.*;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.AnnotationConfigWebContextLoader;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.transaction.annotation.Transactional;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.scb.edmhdpef.config.EdmhdpefConfiguration;
import com.scb.edmhdpef.entity.DataTransferSpecification;
import com.scb.edmhdpef.entity.EdmDataSource;
import com.scb.edmhdpef.entity.EdmWorkflow;
import com.scb.edmhdpef.enums.BusinessDayBehaviorEnum;
import com.scb.edmhdpef.exceptions.EdmHdpEfAppException;
import com.scb.edmhdpef.exceptions.EdmHdpEfInternalException;
import com.scb.edmhdpef.exceptions.EdmHdpEfNotImplementedException;
import com.scb.edmhdpef.services.architecture.TemplateCreation;
import com.scb.edmhdpef.services.architecture.security.EncryptionService;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(classes = { EdmhdpefConfiguration.class },loader = AnnotationConfigWebContextLoader.class)
public class TeradataManagementTest {

	private Document doc;

	@Autowired
	private EncryptionService encryptionService;

	@Autowired
	private TemplateCreation templateCreation;

	@Autowired
	private OozieActionBuilder oozieActionBuilder;


	@Autowired
	private WorkflowConfigService workflowConfigService;

	@Autowired
	private TeradataManagement teradata;

	@Autowired
	private WorkflowController workflowController;

	@Autowired
	private DataSourceController dataSourceController;

	@Autowired
	private SessionFactory sessionFactory;

	@Autowired
	private ExecutionService executionService;


	@BeforeClass
	public static void setupClass() throws IOException {
		FileUtils.deleteDirectory(new File("edmhdpef.db"));
		Properties props=new Properties();
		try {
			props.load(TeradataManagementTest.class.getClassLoader().getResourceAsStream("test.properties"));
			System.getProperties().putAll(props);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}


	/**
	 *
	 * @throws ParserConfigurationException
     */
	@Before
	public void setUp() throws ParserConfigurationException {
		DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
		doc = docBuilder.newDocument();

	}


	/**
	 * Run the List<Element> getDestinationActions(Document,EdmWorkflow) method
	 * test.
	 *
	 * @throws Exception
	 */
	@Test
	public void testGetDestinationActions_1() throws Exception {
		Document doc = new HTMLDocumentImpl();
		EdmWorkflow workflow = getEdmWorkflow("xmls/workflow3.xml", "xmls/ds.xml", "xmls/ds2.xml");
		List<Element> result = teradata.getDeployDstActions(doc, workflow);
		//TODO make specificational test
		assertNotNull(result);
	}

	/**
	 * Run the Map<String, String> getDestinationScripts(EdmWorkflow) method
	 * test.
	 * @throws Exception
	 */
	@Test
	public void testGetDestinationScripts_1() throws Exception {
		EdmWorkflow workflow = getEdmWorkflow("xmls/workflow3.xml", "xmls/ds.xml", "xmls/ds2.xml");
		Map<String, String> result = teradata.getDeployDstScripts(workflow);
		//TODO make specificational test
		assertNotNull(result);
	}

	/**
	 * Run the List<Element> getSourceActions(Document,EdmWorkflow) method test.
	 * @throws Exception
	 */
	@Test
	public void testGetSourceActions_1() throws Exception {
		Document doc = new HTMLDocumentImpl();
		EdmWorkflow workflow = getEdmWorkflow("TD2HDFS/ae_lat_td_hdfs.xml", "TD2HDFS/sithdfs.xml", "TD2HDFS/source.xml");
		List<Element> result = teradata.getDeploySrcActions(doc, workflow);
		//TODO make specificational test
		assertNotNull(result);
		DeployWorkflowVO scheduleScriptVO = new DeployWorkflowVO();
		scheduleScriptVO.setCreateFilesInHDFS(false);
		scheduleScriptVO.setWorkflowName("ae_lat_td_hdfs");
		executionService.deployWorkflow(scheduleScriptVO);

	}

	private EdmWorkflow getEdmWorkflow(String resourceLocation, String resourceLocation1, String resourceLocation2) throws JAXBException, EdmHdpEfAppException, EdmHdpEfInternalException, EdmHdpEfNotImplementedException {
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		session.saveOrUpdate((EdmDataSource) unmarshal(EdmDataSource.class, resourceLocation1));
		session.saveOrUpdate((EdmDataSource) unmarshal(EdmDataSource.class, resourceLocation2));
		session.saveOrUpdate((EdmDataSource) unmarshal(EdmDataSource.class,"xmls/ds3.xml"));
		session.saveOrUpdate((EdmDataSource) unmarshal(EdmDataSource.class,"xmls/ds4.xml"));
		session.getTransaction().commit();
		WorkflowDefinitionVO workflowVO =  unmarshal( WorkflowDefinitionVO.class, resourceLocation);
		try{workflowController.deleteWorkflow(workflowVO.getName());}catch (Exception ex){}
		workflowController.createWorkflow(workflowVO);
		return getEdmWorkflow(workflowVO);
	}

	private EdmWorkflow getEdmWorkflow(WorkflowDefinitionVO workflowVO1) throws JAXBException {
		EdmWorkflow criteria = new EdmWorkflow();
		criteria.setName(workflowVO1.getName());
		return workflowConfigService.retrieveWorkflows(criteria).get(0);
	}

	/**
	 * Run the Map<String, String> getSourceScripts(EdmWorkflow) method test.
	 * @throws Exception
	 *
	 */
	@Test
	public void testGetSourceScripts_1() throws Exception {
		EdmWorkflow workflow = getEdmWorkflow("TD2HDFS/ae_lat_td_hdfs.xml", "TD2HDFS/sithdfs.xml", "TD2HDFS/source.xml");
		Map<String, String> result = teradata.getDeploySrcScripts(workflow);
		//TODO make specificational test
		assertNotNull(result);
	}

	/**
	 *
	 * @throws EdmHdpEfAppException
	 * @throws EdmHdpEfInternalException
	 * @throws EdmHdpEfNotImplementedException
	 * @throws JAXBException
     */
	@Test
	public void destinationActions_NoBDay()
			throws EdmHdpEfAppException, EdmHdpEfInternalException, EdmHdpEfNotImplementedException, JAXBException {
		List<Element> elements = teradata.getDeployDstActions(doc, getEdmWorkflow("xmls/workflow3.xml", "xmls/ds.xml", "xmls/ds2.xml"));
		//TODO make specificational test
		Assert.assertEquals(1, elements.size());
	}

	/**
	 *
	 * @throws EdmHdpEfAppException
	 * @throws EdmHdpEfInternalException
	 * @throws EdmHdpEfNotImplementedException
     */
	@Test
	public void destinationActions_BDayLatest()
			throws EdmHdpEfAppException, EdmHdpEfInternalException, EdmHdpEfNotImplementedException, JAXBException {

		EdmWorkflow workflow = getEdmWorkflow("xmls/workflow3.xml", "xmls/ds.xml", "xmls/ds2.xml");
		for (DataTransferSpecification spec : workflow.getDataTransferSpecification()) {
			spec.setBusinessDayBehavior(BusinessDayBehaviorEnum.LATEST);
		}
		List<Element> elements = teradata.getDeployDstActions(doc, workflow);
		Assert.assertEquals(1, elements.size());
	}

	@Test
	public void destinationActions_BDayAll()
			throws EdmHdpEfAppException, EdmHdpEfInternalException, EdmHdpEfNotImplementedException, JAXBException {

		EdmWorkflow workflow = getEdmWorkflow("xmls/workflow3.xml", "xmls/ds.xml", "xmls/ds2.xml");
		for (DataTransferSpecification spec : workflow.getDataTransferSpecification()) {
			spec.setBusinessDayBehavior(BusinessDayBehaviorEnum.ALL);
		}
		List<Element> elements = teradata.getDeployDstActions(doc, workflow);
		Assert.assertEquals(1, elements.size());
	}

	@Test
	public void destinationScripts_NoBDay()
			throws EdmHdpEfAppException, EdmHdpEfInternalException, EdmHdpEfNotImplementedException, JAXBException {

		Map<String, String> scripts = teradata.getDeployDstScripts(getEdmWorkflow("xmls/workflow3.xml", "xmls/ds.xml", "xmls/ds2.xml"));
		Assert.assertEquals(getOutputFileSet(), scripts.keySet());
	}

	@Test
	public void destinationScripts_BDayLatest()
			throws EdmHdpEfAppException, EdmHdpEfInternalException, EdmHdpEfNotImplementedException, JAXBException {

		EdmWorkflow workflow = getEdmWorkflow("xmls/workflow3.xml", "xmls/ds.xml", "xmls/ds2.xml");
		for (DataTransferSpecification spec : workflow.getDataTransferSpecification()) {
			spec.setBusinessDayBehavior(BusinessDayBehaviorEnum.LATEST);
		}

		Map<String, String> scripts = teradata.getDeployDstScripts(workflow);
		Assert.assertEquals(getOutputFileSet(), scripts.keySet());
	}

	@Test
	public void destinationScripts_BDayAll()
			throws EdmHdpEfAppException, EdmHdpEfInternalException, EdmHdpEfNotImplementedException, JAXBException {

		EdmWorkflow workflow = getEdmWorkflow("xmls/workflow3.xml", "xmls/ds.xml", "xmls/ds2.xml");
		for (DataTransferSpecification spec : workflow.getDataTransferSpecification()) {
			spec.setBusinessDayBehavior(BusinessDayBehaviorEnum.ALL);
		}
		Map<String, String> scripts = teradata.getDeployDstScripts(workflow);
		Assert.assertEquals(getOutputFileSet(), scripts.keySet());
	}


	@Test
	public void testGetDeploySrcScripts() throws Exception {

		EdmWorkflow workflow = getEdmWorkflow("xmls/workflow3.xml", "xmls/ds.xml", "xmls/ds2.xml");
		Map<String, String> deploySrcScripts = teradata.getDeploySrcScripts(workflow);
		//TODO add more apt specificational assertions
		System.out.println(deploySrcScripts.values().iterator().next());
		assertNotNull(deploySrcScripts);
	}

	private Set<String> getOutputFileSet() {
		String files="JDBCShell.jar, TD_split_tmp_table.sql, lib/td/teradata-connector-1.4.0.jar, TD_create_tmp_table.sql, lib/td/tdgssconfig.jar, TD_count_tmp_table.sql, lib/td/terajdbc4.jar, TD_drop_tmp_table.sql, workflow3-dst.sh";
		String[] split = files.split(",");
		Set<String> fileSet = new HashSet<String>();
		for(String str:split)
		{
			fileSet.add(str.trim());
		}

		return fileSet;
	}



	public WorkflowController getWorkflowController() {
		return workflowController;
	}

	public void setWorkflowController(WorkflowController workflowController) {
		this.workflowController = workflowController;
	}

	public DataSourceController getDataSourceController() {
		return dataSourceController;
	}

	public void setDataSourceController(DataSourceController dataSourceController) {
		this.dataSourceController = dataSourceController;
	}



	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	public WorkflowConfigService getWorkflowConfigService() {
		return workflowConfigService;
	}

	public void setWorkflowConfigService(WorkflowConfigService workflowConfigService) {
		this.workflowConfigService = workflowConfigService;
	}


	public ExecutionService getExecutionService() {
		return executionService;
	}

	public void setExecutionService(ExecutionService executionService) {
		this.executionService = executionService;
	}
}
