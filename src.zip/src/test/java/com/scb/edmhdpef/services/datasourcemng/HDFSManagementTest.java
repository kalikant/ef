package com.scb.edmhdpef.services.datasourcemng;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.html.dom.HTMLDocumentImpl;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.util.ReflectionTestUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.scb.edmhdpef.config.EdmhdpefConfiguration;
import com.scb.edmhdpef.entity.DataTransferSpecification;
import com.scb.edmhdpef.entity.EdmColumns;
import com.scb.edmhdpef.entity.EdmDataSource;
import com.scb.edmhdpef.entity.EdmWorkflow;
import com.scb.edmhdpef.enums.BusinessDayBehaviorEnum;
import com.scb.edmhdpef.enums.EdmDataSourceTypeEnum;
import com.scb.edmhdpef.enums.EdmWorkflowTypeEnum;
import com.scb.edmhdpef.exceptions.EdmHdpEfAppException;
import com.scb.edmhdpef.exceptions.EdmHdpEfInternalException;
import com.scb.edmhdpef.exceptions.EdmHdpEfNotImplementedException;
import com.scb.edmhdpef.services.architecture.TemplateCreation;
import com.scb.edmhdpef.services.architecture.security.EncryptionService;

@RunWith(MockitoJUnitRunner.class)
@WebAppConfiguration
@ContextConfiguration(classes = { EdmhdpefConfiguration.class })
public class HDFSManagementTest {

	private Document doc;

	@Mock
	private EncryptionService encryptionService;

	@Mock
	private TemplateCreation templateCreation;

	@Mock
	private OozieActionBuilder oozieActionBuilder;

	@Autowired
	@InjectMocks
	private HDFSManagement hdfs;

	@Before
	public void setUp() throws ParserConfigurationException {
		DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder docBuilder = docFactory.newDocumentBuilder();

		doc = docBuilder.newDocument();

		MockitoAnnotations.initMocks(this);

		ReflectionTestUtils.setField(hdfs, "dataProcessingJar", "edmhdpef-mr-0.0.1.jar");
	}

	/**
	 * Run the List<Element> getDestinationActions(Document,EdmWorkflow) method
	 * test.
	 *
	 * @throws Exception
	 */
	@Test(expected = EdmHdpEfInternalException.class)
	public void testGetDestinationActions_1() throws Exception {
		Document doc = new HTMLDocumentImpl();
		EdmWorkflow workflow = new EdmWorkflow();
		workflow.setName("wf");
		workflow.setParameters(new HashSet<String>());

		List<Element> result = hdfs.getDeployDstActions(doc, workflow);

		// add additional test code here
		assertNotNull(result);
	}

	/**
	 * Run the Map<String, String> getDestinationScripts(EdmWorkflow) method
	 * test.
	 *
	 * @throws Exception
	 */
	@Test(expected = EdmHdpEfInternalException.class)
	public void testGetDestinationScripts_1() throws Exception {
		EdmWorkflow workflow = new EdmWorkflow();
		workflow.setName("wf");
		workflow.setDestination(new EdmDataSource());
		workflow.setDataTransferSpecification(new LinkedList<DataTransferSpecification>());

		when(encryptionService.decryptParameters(null)).thenReturn(null);

		Map<String, String> result = hdfs.getDeployDstScripts(workflow);

		assertNotNull(result);
	}

	/**
	 * Run the List<Element> getSourceActions(Document,EdmWorkflow) method test.
	 *
	 * @throws Exception
	 */
	@Test(expected = EdmHdpEfNotImplementedException.class)
	public void testGetSourceActions_1() throws Exception {
		Document doc = new HTMLDocumentImpl();
		EdmWorkflow workflow = new EdmWorkflow();

		List<Element> result = hdfs.getDeploySrcActions(doc, workflow);

		assertNotNull(result);
	}

	/**
	 * Run the Map<String, String> getSourceScripts(EdmWorkflow) method test.
	 *
	 * @throws Exception
	 *
	 */
	@Test(expected = EdmHdpEfNotImplementedException.class)
	public void testGetSourceScripts_1() throws Exception {
		EdmWorkflow workflow = new EdmWorkflow();

		Map<String, String> result = hdfs.getDeploySrcScripts(workflow);

		assertNotNull(result);
	}

	@Test
	public void destinationActions_NoBDay()
			throws EdmHdpEfAppException, EdmHdpEfInternalException, EdmHdpEfNotImplementedException {

		List<Element> elements = hdfs.getDeployDstActions(doc, getWorkflow());

		Assert.assertEquals(1, elements.size());
	}

	@Test
	public void destinationActions_BDayLatest()
			throws EdmHdpEfAppException, EdmHdpEfInternalException, EdmHdpEfNotImplementedException {

		EdmWorkflow workflow = getWorkflow();
		for (DataTransferSpecification spec : workflow.getDataTransferSpecification()) {
			spec.setBusinessDayBehavior(BusinessDayBehaviorEnum.LATEST);
		}

		List<Element> elements = hdfs.getDeployDstActions(doc, workflow);

		Assert.assertEquals(1, elements.size());

	}

	@Test
	public void destinationActions_BDayAll()
			throws EdmHdpEfAppException, EdmHdpEfInternalException, EdmHdpEfNotImplementedException {

		EdmWorkflow workflow = getWorkflow();
		for (DataTransferSpecification spec : workflow.getDataTransferSpecification()) {
			spec.setBusinessDayBehavior(BusinessDayBehaviorEnum.ALL);
		}

		List<Element> elements = hdfs.getDeployDstActions(doc, workflow);

		Assert.assertEquals(1, elements.size());
	}

	@Test
	public void destinationScripts_Generic()
			throws EdmHdpEfAppException, EdmHdpEfInternalException, EdmHdpEfNotImplementedException {

		EdmWorkflow workflow = getWorkflow();
		workflow.setType(EdmWorkflowTypeEnum.GENERIC);

		Map<String, String> scripts = hdfs.getDeployDstScripts(workflow);

		Assert.assertTrue(scripts.isEmpty());
	}

	@Test
	public void destinationScripts_TableGroup()
			throws EdmHdpEfAppException, EdmHdpEfInternalException, EdmHdpEfNotImplementedException {

		Map<String, String> scripts = hdfs.getDeployDstScripts(getWorkflow());

		Assert.assertEquals(getOutputFileSet(), scripts.keySet());
	}

	private EdmWorkflow getWorkflow() {
		EdmWorkflow workflow = new EdmWorkflow();
		workflow.setName("workflow");

		EdmDataSource source = new EdmDataSource();
		source.setType(EdmDataSourceTypeEnum.HIVE);
		source.setParameters(new HashMap<String, String>());
		workflow.setSource(source);

		EdmDataSource destination = new EdmDataSource();
		destination.setType(EdmDataSourceTypeEnum.HDFS);
		destination.setParameters(new HashMap<String, String>());

		workflow.setDestination(destination);
		workflow.setType(EdmWorkflowTypeEnum.TABLE_GROUP);
		List<DataTransferSpecification> specs = new ArrayList<DataTransferSpecification>();

		specs.add(createDataTransferSpecification("src", "dst"));
		specs.add(createDataTransferSpecification("src2", "dst2"));
		workflow.setDataTransferSpecification(specs);
		return workflow;
	}

	private DataTransferSpecification createDataTransferSpecification(String src, String dst) {
		DataTransferSpecification spec = new DataTransferSpecification();
		spec.setBusinessDayBehavior(BusinessDayBehaviorEnum.NO);
		spec.setSourceDatabase(src + "DB");
		spec.setSourceTable(src + "Table");
		spec.setDestinationDatabase(dst + "DB");
		spec.setDestinationTable(dst + "Table");
		List<EdmColumns> columns = new ArrayList<EdmColumns>();
		EdmColumns col = new EdmColumns();
		col.setDestination(dst + "Col");
		col.setSource(src + "Col");
		EdmColumns col2 = new EdmColumns();
		col2.setDestination(dst + "Col2");
		col2.setSource(src + "Col2");
		columns.add(col);
		columns.add(col2);
		spec.setColumns(columns);
		return spec;
	}

	private Set<String> getOutputFileSet() {
		Set<String> fileSet = new HashSet<String>();

        fileSet.add("workflow-dst.sh");
        fileSet.add("edmhdpef-mr-0.0.1.jar");

		return fileSet;
	}
}
