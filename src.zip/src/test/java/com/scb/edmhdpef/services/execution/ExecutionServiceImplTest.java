package com.scb.edmhdpef.services.execution;

import static org.junit.Assert.assertNotNull;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

import org.apache.oozie.client.OozieClient;
import org.apache.oozie.client.WorkflowJob;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.util.ReflectionTestUtils;

import com.scb.edmhdpef.entity.DataTransferSpecification;
import com.scb.edmhdpef.entity.EdmColumns;
import com.scb.edmhdpef.entity.EdmDataSource;
import com.scb.edmhdpef.entity.EdmWorkflow;
import com.scb.edmhdpef.entity.WorkflowExecution;
import com.scb.edmhdpef.enums.BusinessDayBehaviorEnum;
import com.scb.edmhdpef.enums.EdmDataSourceTypeEnum;
import com.scb.edmhdpef.enums.EdmWorkflowTypeEnum;
import com.scb.edmhdpef.exceptions.EdmHdpEfAppException;
import com.scb.edmhdpef.services.architecture.security.EncryptionService;
import com.scb.edmhdpef.services.database.DataAccessService;
import com.scb.edmhdpef.services.datasourcemng.TeradataManagement;
import com.scb.edmhdpef.vo.DeployWorkflowVO;

/**
 * The class <code>ExecutionServiceImplTest</code> contains tests for the class
 * <code>{@link ExecutionServiceImpl}</code>.
 */
@RunWith(PowerMockRunner.class)
@PrepareForTest({ ExecutionServiceImpl.class, OozieClient.class })
public class ExecutionServiceImplTest {

    @Mock
    DataAccessService dataAccess;

    @Mock
    EncryptionService encryptionService;

    @Autowired
    @InjectMocks
    ExecutionServiceImpl fixture;

    String oozieUrl = "http://localhost:11000/oozie";

    /**
     * Perform pre-test initialization.
     *
     * @throws Exception
     *             if the initialization fails for some reason
     */
    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);

        ReflectionTestUtils.setField(fixture, "oozieURL", oozieUrl);
        ReflectionTestUtils.setField(fixture, "oozieWorkflowPath", "oozieWorkflowPath");
        ReflectionTestUtils.setField(fixture, "oozieUserName", "oozieUserName");
        ReflectionTestUtils.setField(fixture, "oozieQueueName", "oozieQueueName");
        ReflectionTestUtils.setField(fixture, "oozieNameNode", "oozieNameNode");
        ReflectionTestUtils.setField(fixture, "oozieJobTracker", "oozieJobTracker");

        OozieClient oozieClient = Mockito.mock(OozieClient.class);
        PowerMockito.whenNew(OozieClient.class).withArguments(Mockito.any(String.class)).thenReturn(oozieClient);
        WorkflowJob wj = Mockito.mock(WorkflowJob.class);
        Mockito.when(oozieClient.getJobInfo(Mockito.anyString())).thenReturn(wj);
        Mockito.when(wj.getStatus()).thenReturn(WorkflowJob.Status.SUCCEEDED);
    }

    /**
     * Run the Map<String, String> deployWorkflow(DeployWorkflowVO) method test.
     *
     * @throws Exception
     */
    @Test(expected = EdmHdpEfAppException.class)
    public void testDeployWorkflow_1() throws Exception {
        DeployWorkflowVO deployWorkflowVO = new DeployWorkflowVO();
        deployWorkflowVO.setWorkflowName(null);

        Map<String, String> result = fixture.deployWorkflow(deployWorkflowVO);

        assertNotNull(result);
    }

    /**
     * Run the Map<String, String> deployWorkflow(DeployWorkflowVO) method test.
     *
     * @throws Exception
     */
    @Test(expected = EdmHdpEfAppException.class)
    public void testDeployWorkflow_2() throws Exception {
        DeployWorkflowVO deployWorkflowVO = new DeployWorkflowVO();
        deployWorkflowVO.setWorkflowName("wf");

        Map<String, String> result = fixture.deployWorkflow(deployWorkflowVO);

        assertNotNull(result);
    }

    /**
     * Run the List<WorkflowExecution> queryStatus(WorkflowExecution) method
     * test with status=null.
     *
     * @throws Exception
     */
    @Test(expected = EdmHdpEfAppException.class)
    public void queryStatus_status_null() throws Exception {
        WorkflowExecution status = null;

        fixture.queryStatus(status);
    }

    /**
     * Run the List<WorkflowExecution> queryStatus(WorkflowExecution) method
     * test with workflow=null.
     *
     * @throws Exception
     */
    @Test(expected = EdmHdpEfAppException.class)
    public void testQueryStatus_2() throws Exception {
        WorkflowExecution status = new WorkflowExecution();
        status.setWorkflow(null);
        status.setJobId(null);

        fixture.queryStatus(status);
    }

    /**
     * Run the List<WorkflowExecution> queryStatus(WorkflowExecution) method
     * test.
     *
     * @throws Exception
     */
    @Test(expected = EdmHdpEfAppException.class)
    public void testQueryStatus_3() throws Exception {
        WorkflowExecution status = new WorkflowExecution();
        EdmWorkflow workflow = new EdmWorkflow();
        status.setWorkflow(workflow);
        status.setJobId(null);

        fixture.queryStatus(status);
    }

    /**
     * Run the List<WorkflowExecution> queryStatus(WorkflowExecution) method
     * test.
     *
     * @throws Exception
     */
    @Test
    public void testQueryStatus_4() throws Exception {
        WorkflowExecution status = new WorkflowExecution();
        EdmWorkflow workflow = new EdmWorkflow();
        workflow.setName("workflow");
        status.setWorkflow(workflow);
        status.setJobId(null);

        List<WorkflowExecution> result = fixture.queryStatus(status);

        assertNotNull(result);
    }

    /**
     * Run the List<WorkflowExecution> queryStatus(WorkflowExecution) method
     * test.
     *
     * @throws Exception
     */
    @Test
    public void testQueryStatus_5() throws Exception {
        WorkflowExecution status = getWorkflowExecution();

        List<WorkflowExecution> result = fixture.queryStatus(status);

        assertNotNull(result);
    }

    /**
     * Run the WorkflowExecution runWorkflow(WorkflowExecution) method test.
     *
     * @throws Exception
     */
    @Test(expected = EdmHdpEfAppException.class)
    public void testRunWorkflow_1() throws Exception {
        WorkflowExecution runWorkflow = null;

        WorkflowExecution result = fixture.runWorkflow(runWorkflow);

        assertNotNull(result);
    }

    /**
     * Run the WorkflowExecution runWorkflow(WorkflowExecution) method test.
     *
     * @throws Exception
     */
    @Test(expected = EdmHdpEfAppException.class)
    public void testRunWorkflow_2() throws Exception {
        WorkflowExecution runWorkflow = getWorkflowExecution();
        runWorkflow.setParameters(null);

        WorkflowExecution result = fixture.runWorkflow(runWorkflow);

        assertNotNull(result);
    }

    /**
     * Run the WorkflowExecution runWorkflow(WorkflowExecution) method test.
     *
     * @throws Exception
     */
    @SuppressWarnings({ "rawtypes", "unchecked" })
    @Test
    public void testRunWorkflow_3() throws Exception {
        WorkflowExecution runWorkflow = getWorkflowExecution();

        List list = new ArrayList<WorkflowExecution>();
        list.add(runWorkflow);
        Mockito.when(dataAccess.retrieveByCriteria(Mockito.any(WorkflowExecution.class))).thenReturn(list);
        Mockito.when(dataAccess.retrieveWorkflowExecutionByWorkflowName(Mockito.any(String.class))).thenReturn(list);

        WorkflowExecution result = fixture.runWorkflow(runWorkflow);

        assertNotNull(result);
    }

    /**
     * Run the WorkflowExecution runWorkflow(WorkflowExecution) method test.
     *
     * @throws Exception
     */
    @SuppressWarnings({ "unchecked", "rawtypes" })
    @Test
    public void testRunWorkflow_4() throws Exception {
        WorkflowExecution runWorkflow = getWorkflowExecution();

        List list = new ArrayList<WorkflowExecution>();
        list.add(runWorkflow);
        Mockito.when(dataAccess.retrieveByCriteria(Mockito.any(WorkflowExecution.class))).thenReturn(list);
        Mockito.when(dataAccess.retrieveWorkflowExecutionByWorkflowName(Mockito.any(String.class))).thenReturn(list);

        WorkflowExecution result = fixture.runWorkflow(runWorkflow);

        assertNotNull(result);
    }

    private WorkflowExecution getWorkflowExecution() throws Exception {
        WorkflowExecution runWorkflow = new WorkflowExecution();
        EdmWorkflow wf = getWorkflow();
        Mockito.when(dataAccess.retrieveById(EdmWorkflow.class, "wf")).thenReturn(wf);

        runWorkflow.setWorkflow(wf);
        runWorkflow.setParameters(new HashMap<String, String>());

        return runWorkflow;
    }

    private EdmWorkflow getWorkflow() {
        EdmWorkflow workflow = new EdmWorkflow();
        workflow.setName("wf");
        workflow.setType(EdmWorkflowTypeEnum.GENERIC);
        workflow.setParameters(new HashSet<String>());
        workflow.setSource(new EdmDataSource());
        workflow.getSource().setType(EdmDataSourceTypeEnum.HIVE);
        workflow.getSource().setParameters(new HashMap<String, String>());
        EdmDataSource destination = new EdmDataSource();
        destination.setType(EdmDataSourceTypeEnum.TERADATA);
        destination.setParameters(new HashMap<String, String>());
        destination.getParameters().put(TeradataManagement.DS_PARAM_TERADATA_JDBCSTRING, "jdbc:teradata://server");
        workflow.setDestination(destination);

        List<DataTransferSpecification> specs = new ArrayList<DataTransferSpecification>();

        specs.add(createDataTransferSpecification("src", "dst"));
        specs.add(createDataTransferSpecification("src2", "dst2"));
        workflow.setDataTransferSpecification(specs);

        return workflow;
    }

    private DataTransferSpecification createDataTransferSpecification(String src, String dst) {
        DataTransferSpecification spec = new DataTransferSpecification();
        spec.setBusinessDayBehavior(BusinessDayBehaviorEnum.NO);
        spec.setSourceDatabase(src + "DB");
        spec.setSourceTable(src + "Table");
        spec.setDestinationDatabase(dst + "DB");
        spec.setDestinationTable(dst + "Table");
        List<EdmColumns> columns = new ArrayList<EdmColumns>();
        EdmColumns col = new EdmColumns();
        col.setDestination(dst + "Col");
        col.setSource(src + "Col");
        EdmColumns col2 = new EdmColumns();
        col2.setDestination(dst + "Col2");
        col2.setSource(src + "Col2");
        columns.add(col);
        columns.add(col2);
        spec.setColumns(columns);
        return spec;
    }

}