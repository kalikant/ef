package com.scb.edmhdpef.services.execution;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataOutputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.util.ReflectionTestUtils;

import com.scb.edmhdpef.config.EdmhdpefConfiguration;
import com.scb.edmhdpef.entity.DataTransferSpecification;
import com.scb.edmhdpef.entity.EdmColumns;
import com.scb.edmhdpef.entity.EdmDataSource;
import com.scb.edmhdpef.entity.EdmWorkflow;
import com.scb.edmhdpef.enums.BusinessDayBehaviorEnum;
import com.scb.edmhdpef.enums.EdmDataSourceTypeEnum;
import com.scb.edmhdpef.enums.EdmWorkflowTypeEnum;
import com.scb.edmhdpef.exceptions.EdmHdpEfInternalException;
import com.scb.edmhdpef.exceptions.EdmHdpEfNotImplementedException;
import com.scb.edmhdpef.services.datasourcemng.DataSourceManagementSelector;
import com.scb.edmhdpef.services.datasourcemng.HiveManagement;
import com.scb.edmhdpef.services.datasourcemng.TeradataManagement;

/**
 * The class <code>DeployWorkflowFilesServiceImplTest</code> contains tests for
 * the class <code>{@link DeployWorkflowFilesServiceImpl}</code>.
 *
 */
@RunWith(PowerMockRunner.class)
@WebAppConfiguration
@ContextConfiguration(classes = { EdmhdpefConfiguration.class })
@PrepareForTest({ FileSystem.class })
public class DeployWorkflowFilesServiceImplTest {

	@Mock
	private HiveManagement hiveManagement;

	@Mock
	private DataSourceManagementSelector dataSourceManagementSelector;

	@Autowired
	@InjectMocks
	DeployWorkflowFilesServiceImpl fixture;

	/**
	 * Perform pre-test initialization.
	 * 
	 * @throws EdmHdpEfNotImplementedException
	 *
	 * @throws Exception
	 *             if the initialization fails for some reason
	 */
	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		when(dataSourceManagementSelector.getDataSourceManagement(any(EdmDataSource.class))).thenReturn(hiveManagement);

		PowerMockito.mockStatic(FileSystem.class);
		FileSystem fs = Mockito.mock(FileSystem.class);
		when(FileSystem.get(any(Configuration.class))).thenReturn(fs);
		when(fs.exists(any(Path.class))).thenReturn(true);
		when(fs.create(any(Path.class), any(Boolean.class))).thenReturn(Mockito.mock(FSDataOutputStream.class));

		ReflectionTestUtils.setField(fixture, "hadoopDefaultFS", "hdfs://127.0.0.1:8020");
	}

	/**
	 * Run the Map<String, String> getWorkFlowAndScripts(EdmWorkflow) method
	 * test.
	 *
	 * @throws Exception
	 */
	@Test(expected = EdmHdpEfInternalException.class)
	public void testGetWorkFlowAndScripts_1() throws Exception {

		Map<String, String> result = fixture.getWorkFlowAndScripts(null);

		assertNotNull(result);
	}

	/**
	 * Run the Map<String, String> getWorkFlowAndScripts(EdmWorkflow) method
	 * test.
	 *
	 * @throws Exception
	 */
	@Test(expected = EdmHdpEfInternalException.class)
	public void testGetWorkFlowAndScripts_1b() throws Exception {
		EdmWorkflow workflow = new EdmWorkflow();

		Map<String, String> result = fixture.getWorkFlowAndScripts(workflow);

		assertNotNull(result);
	}

	/**
	 * Run the Map<String, String> getWorkFlowAndScripts(EdmWorkflow) method
	 * test.
	 *
	 * @throws Exception
	 */
	@Test(expected = EdmHdpEfInternalException.class)
	public void testGetWorkFlowAndScripts_2() throws Exception {
		EdmWorkflow workflow = new EdmWorkflow();
		workflow.setName("wf");
		workflow.setType(EdmWorkflowTypeEnum.GENERIC);
		workflow.setSource(new EdmDataSource());

		Map<String, String> result = fixture.getWorkFlowAndScripts(workflow);

		assertNotNull(result);
	}

	/**
	 * Run the Map<String, String> getWorkFlowAndScripts(EdmWorkflow) method
	 * test.
	 *
	 * @throws Exception
	 */
	@Test(expected = EdmHdpEfInternalException.class)
	public void testGetWorkFlowAndScripts_3() throws Exception {
		EdmWorkflow workflow = new EdmWorkflow();
		workflow.setName("wf");
		workflow.setSource(new EdmDataSource());

		Map<String, String> result = fixture.getWorkFlowAndScripts(workflow);

		assertNotNull(result);
	}

	/**
	 * Run the Map<String, String> getWorkFlowAndScripts(EdmWorkflow) method
	 * test.
	 *
	 * @throws Exception
	 */
	@Test(expected = EdmHdpEfInternalException.class)
	public void testGetWorkFlowAndScripts_4() throws Exception {
		EdmWorkflow workflow = new EdmWorkflow();
		workflow.setName("wf");
		workflow.setType(EdmWorkflowTypeEnum.GENERIC);
		workflow.setDestination(new EdmDataSource());
		workflow.setSource(new EdmDataSource());

		Map<String, String> result = fixture.getWorkFlowAndScripts(workflow);

		assertNotNull(result);
	}

	/**
	 * Run the Map<String, String> getWorkFlowAndScripts(EdmWorkflow) method
	 * test.
	 *
	 * @throws Exception
	 */
	@Test(expected = EdmHdpEfInternalException.class)
	public void testGetWorkFlowAndScripts_5() throws Exception {
		EdmWorkflow workflow = new EdmWorkflow();
		workflow.setName("wf");
		workflow.setType(EdmWorkflowTypeEnum.GENERIC);
		workflow.setDestination(new EdmDataSource());
		workflow.setSource(new EdmDataSource());
		workflow.getSource().setType(EdmDataSourceTypeEnum.TERADATA);

		Map<String, String> result = fixture.getWorkFlowAndScripts(workflow);

		assertNotNull(result);
	}

	/**
	 * Run the Map<String, String> getWorkFlowAndScripts(EdmWorkflow) method
	 * test.
	 *
	 * @throws Exception
	 */
	@Test(expected = EdmHdpEfInternalException.class)
	public void testGetWorkFlowAndScripts_6() throws Exception {
		EdmWorkflow workflow = new EdmWorkflow();
		workflow.setName("wf");
		workflow.setType(EdmWorkflowTypeEnum.GENERIC);
		workflow.setDestination(new EdmDataSource());
		workflow.setSource(new EdmDataSource());
		workflow.getSource().setType(EdmDataSourceTypeEnum.HIVE);

		Map<String, String> result = fixture.getWorkFlowAndScripts(workflow);

		assertNotNull(result);
	}

	/**
	 * Run the Map<String, String> getWorkFlowAndScripts(EdmWorkflow) method
	 * test.
	 *
	 * @throws Exception
	 */
	@Test(expected = EdmHdpEfInternalException.class)
	public void testGetWorkFlowAndScripts_7() throws Exception {
		EdmWorkflow workflow = new EdmWorkflow();
		workflow.setName("wf");
		workflow.setType(EdmWorkflowTypeEnum.GENERIC);
		workflow.setDestination(new EdmDataSource());
		workflow.setSource(new EdmDataSource());
		workflow.getSource().setType(EdmDataSourceTypeEnum.HIVE);
		workflow.getDestination().setType(EdmDataSourceTypeEnum.HIVE);

		Map<String, String> result = fixture.getWorkFlowAndScripts(workflow);

		assertNotNull(result);
	}

	/**
	 * Run the Map<String, String> getWorkFlowAndScripts(EdmWorkflow) method
	 * test.
	 *
	 * @throws Exception
	 */
	@Test
	public void testGetWorkFlowAndScripts_8() throws Exception {
		EdmWorkflow workflow = getWorkflow();

		Map<String, String> result = fixture.getWorkFlowAndScripts(workflow);

		assertNotNull(result);
	}

	/**
	 * Run the Map<String, String> getWorkFlowAndScripts(EdmWorkflow) method
	 * test.
	 *
	 * @throws Exception
	 */
	@Test
	public void testGetWorkFlowAndScripts_9() throws Exception {
		EdmWorkflow workflow = getWorkflow();
		workflow.setName("wf");
		workflow.setType(EdmWorkflowTypeEnum.TABLE_GROUP);
		workflow.getSource().setType(EdmDataSourceTypeEnum.HIVE);
		workflow.getDestination().setType(EdmDataSourceTypeEnum.TERADATA);

		Map<String, String> result = fixture.getWorkFlowAndScripts(workflow);

		assertNotNull(result);
	}

	/**
	 * Run the Map<String, String> writeWorkFlowAndScripts(EdmWorkflow) method
	 * test.
	 *
	 * @throws Exception
	 */
	@Test
	public void testWriteWorkFlowAndScripts_1() throws Exception {
		EdmWorkflow workflow = getWorkflow();
		Map<String, String> files = new HashMap<String, String>();

		fixture.writeWorkFlowAndScripts(workflow, files);

		assertNotNull(files);
	}

	/**
	 * Run the Map<String, String> writeWorkFlowAndScripts(EdmWorkflow) method
	 * test.
	 *
	 * @throws Exception
	 */
	@Test
	public void testWriteWorkFlowAndScripts_2() throws Exception {
		EdmWorkflow workflow = getWorkflow();
		Map<String, String> files = new HashMap<String, String>();
		files.put("file", "");
		fixture.writeWorkFlowAndScripts(workflow, files);

		assertNotNull(files);
	}

	/**
	 * Run the Map<String, String> writeWorkFlowAndScripts(EdmWorkflow) method
	 * test.
	 *
	 * @throws Exception
	 */
	@Test
	public void testWriteWorkFlowAndScripts_3() throws Exception {
		EdmWorkflow workflow = getWorkflow();
		Map<String, String> files = new HashMap<String, String>();
		files.put("file1", "");
		files.put("file2", "file2content");

		fixture.writeWorkFlowAndScripts(workflow, files);

		assertNotNull(files);
	}

	private EdmWorkflow getWorkflow() {
		EdmWorkflow workflow = new EdmWorkflow();
		workflow.setName("wf");
		workflow.setType(EdmWorkflowTypeEnum.GENERIC);
		workflow.setParameters(new HashSet<String>());
		workflow.setSource(new EdmDataSource());
		workflow.getSource().setType(EdmDataSourceTypeEnum.HIVE);
		workflow.getSource().setParameters(new HashMap<String, String>());
		EdmDataSource destination = new EdmDataSource();
		destination.setType(EdmDataSourceTypeEnum.TERADATA);
		destination.setParameters(new HashMap<String, String>());
		destination.getParameters().put(TeradataManagement.DS_PARAM_TERADATA_JDBCSTRING, "jdbc:teradata://server");
		workflow.setDestination(destination);
		List<DataTransferSpecification> specs = new ArrayList<DataTransferSpecification>();

		specs.add(createDataTransferSpecification("src", "dst"));
		specs.add(createDataTransferSpecification("src2", "dst2"));
		workflow.setDataTransferSpecification(specs);

		return workflow;
	}

	private DataTransferSpecification createDataTransferSpecification(String src, String dst) {
		DataTransferSpecification spec = new DataTransferSpecification();
		spec.setBusinessDayBehavior(BusinessDayBehaviorEnum.NO);
		spec.setSourceDatabase(src + "DB");
		spec.setSourceTable(src + "Table");
		spec.setDestinationDatabase(dst + "DB");
		spec.setDestinationTable(dst + "Table");
		List<EdmColumns> columns = new ArrayList<EdmColumns>();
		EdmColumns col = new EdmColumns();
		col.setDestination(dst + "Col");
		col.setSource(src + "Col");
		EdmColumns col2 = new EdmColumns();
		col2.setDestination(dst + "Col2");
		col2.setSource(src + "Col2");
		columns.add(col);
		columns.add(col2);
		spec.setColumns(columns);
		return spec;
	}

}