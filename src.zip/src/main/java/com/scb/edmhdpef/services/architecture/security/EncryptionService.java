package com.scb.edmhdpef.services.architecture.security;

import java.util.Map;

import com.scb.edmhdpef.exceptions.EdmHdpEfInternalException;

public interface EncryptionService {

	Map<String, String> encryptParameters(Map<String, String> parameters)
			throws EdmHdpEfInternalException;

	Map<String, String> decryptParameters(Map<String, String> parameters)
			throws EdmHdpEfInternalException;

}
