package com.scb.edmhdpef.services.database;

import java.io.Serializable;
import java.util.List;

import javax.annotation.Resource;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Example;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.concurrent.ListenableFutureCallback;

import com.scb.edmhdpef.entity.WorkflowExecution;
import com.scb.edmhdpef.exceptions.EdmHdpEfInternalException;

@Service("dataAccessService")
@Transactional
public class DataAccessServiceImpl implements DataAccessService {

	private Logger logger = LoggerFactory.getLogger(DataAccessServiceImpl.class);

	@Value("${hive.SaveEntities.RetryCount}")
	private int retryCount;

	@Value("${hive.SaveEntities.WaitingTimeBetweenRetries}")
	private long sleepingTimeBetweenRetries;

	/** Hibernate's Session Factory. */
	@Resource
	private SessionFactory sessionFactory;

	@Resource
	private HiveDumpService hiveDumpService;

	@SuppressWarnings("unchecked")
	@Override
	public List<Object> retrieveByCriteria(Object obj) {
		Criteria criteria = this.sessionFactory.getCurrentSession().createCriteria(obj.getClass())
				.add(Example.create(obj));
		return criteria.list();
	}

	@Override
	public Object saveOrUpdateObject(Object obj) throws EdmHdpEfInternalException {
		logger.info("Save object " + obj);
		Session session = this.sessionFactory.getCurrentSession();
		session.saveOrUpdate(obj);
		session.flush();
		session.refresh(obj);
        writeToHiveWithCallback("SAVE", obj, retryCount);
		return obj;
	}

	@Override
	public void deleteObject(Object obj) throws EdmHdpEfInternalException {
		logger.info("Deleting object " + obj);
		this.sessionFactory.getCurrentSession().delete(obj);
        writeToHiveWithCallback("DELETE", obj, retryCount);
	}

	@Override
	public Object retrieveById(Class<?> cls, Serializable id) {
		return this.sessionFactory.getCurrentSession().get(cls, id);
	}

	private void writeToHiveWithCallback(final String type, final Object obj, final int retryCount2) {
		if (retryCount2 == 0) {
			return;
		}
		logger.info("Writing operation " + type + " on Hive, attempt " + (retryCount - retryCount2 + 1) + " out of "
				+ retryCount);
		try {
			if (retryCount2 < retryCount) {
				Thread.sleep(sleepingTimeBetweenRetries);
			}
			this.hiveDumpService.writeToHive(type, obj).addCallback(new ListenableFutureCallback<Boolean>() {

				@Override
				public void onSuccess(Boolean result) {
					if (!Boolean.TRUE.equals(result)) {
						writeToHiveWithCallback(type, obj, retryCount2 - 1);
					}
				}

				@Override
				public void onFailure(Throwable ex) {
					writeToHiveWithCallback(type, obj, retryCount2 - 1);
				}
			});
		} catch (EdmHdpEfInternalException | InterruptedException e) {
			e.printStackTrace();
			writeToHiveWithCallback(type, obj, retryCount2 - 1);
		}

	}

	@SuppressWarnings("unchecked")
	@Override
	public List<WorkflowExecution> retrieveWorkflowExecutionByWorkflowName(String name) {
		Criteria criteria = this.sessionFactory.getCurrentSession().createCriteria(WorkflowExecution.class);
		criteria.add(Restrictions.eq("workflow.name", name));
		return criteria.list();
	}
}
