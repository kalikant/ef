package com.scb.edmhdpef.services.execution;

import java.util.Map;

import com.scb.edmhdpef.entity.EdmWorkflow;
import com.scb.edmhdpef.exceptions.EdmHdpEfAppException;
import com.scb.edmhdpef.exceptions.EdmHdpEfInternalException;
import com.scb.edmhdpef.exceptions.EdmHdpEfNotImplementedException;

public interface DeployWorkflowFilesService {

	Map<String, String> getWorkFlowAndScripts(EdmWorkflow workflow)
			throws EdmHdpEfAppException, EdmHdpEfInternalException,
			EdmHdpEfNotImplementedException;

	void writeWorkFlowAndScripts(EdmWorkflow workflow, Map<String, String> files)
			throws EdmHdpEfAppException, EdmHdpEfInternalException,
			EdmHdpEfNotImplementedException;

}
