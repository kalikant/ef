package com.scb.edmhdpef.services.execution;

import java.util.List;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.scb.edmhdpef.entity.DataProcessing;
import com.scb.edmhdpef.entity.EdmWorkflow;
import com.scb.edmhdpef.enums.DataProcessingType;
import com.scb.edmhdpef.exceptions.EdmHdpEfAppException;
import com.scb.edmhdpef.exceptions.EdmHdpEfInternalException;
import com.scb.edmhdpef.exceptions.EdmHdpEfNotImplementedException;
import com.scb.edmhdpef.services.model.EdmhdpefProperty;

public interface DataProcessingService {

	List<EdmhdpefProperty> getOptions(DataProcessingType type);

	void validateOptions(EdmWorkflow workflow, DataProcessing dataProcessing)
			throws EdmHdpEfAppException, EdmHdpEfInternalException;

	List<Element> getDeployProcessingActions(Document doc, EdmWorkflow workflow)
			throws EdmHdpEfAppException, EdmHdpEfInternalException, EdmHdpEfNotImplementedException;
}
