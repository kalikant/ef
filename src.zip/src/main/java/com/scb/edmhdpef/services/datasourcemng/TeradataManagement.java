package com.scb.edmhdpef.services.datasourcemng;

import com.scb.edmhdpef.EdmhdpefCommon;
import com.scb.edmhdpef.EdmhdpefConstants;
import com.scb.edmhdpef.entity.DataTransferSpecification;
import com.scb.edmhdpef.entity.EdmColumns;
import com.scb.edmhdpef.entity.EdmWorkflow;
import com.scb.edmhdpef.exceptions.EdmHdpEfAppException;
import com.scb.edmhdpef.exceptions.EdmHdpEfAppException.AppExceptionCode;
import com.scb.edmhdpef.exceptions.EdmHdpEfInternalException;
import com.scb.edmhdpef.exceptions.EdmHdpEfInternalException.InternalExceptionCode;
import com.scb.edmhdpef.exceptions.EdmHdpEfNotImplementedException;
import com.scb.edmhdpef.exceptions.EdmHdpEfNotImplementedException.NotImplementedExceptionCode;
import com.scb.edmhdpef.filters.DelegatingFilterProxyImpl;
import com.scb.edmhdpef.services.architecture.TemplateCreation;
import com.scb.edmhdpef.services.architecture.security.EncryptionService;
import com.scb.edmhdpef.services.model.EdmhdpefProperty;
import com.scb.edmhdpef.services.model.OozieAction;
import org.apache.commons.beanutils.BeanUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import javax.annotation.Resource;
import java.util.*;
import java.util.Map.Entry;

@Service
public class TeradataManagement implements DataSourceManagement {

    public static final String DS_PARAM_TERADATA_JDBCSTRING = "jdbcstring";
    public static final String DS_PARAM_TERADATA_USERNAME = "username";
    public static final String DS_PARAM_TERADATA_PASSWORD = "password";

    public static final String DS_OPTION_TERADATA_COMMAND_ARGS = "TDCHOptionalArgs";
    public static final String DS_OPTION_TERADATA_INSERT_METHOD = "tdInsertMethod";
    public static final String DS_OPTION_TERADATA_CLUSTER_JAVA_PATH = "clusterJavaPath";
    public static final String DS_OPTION_TERADATA_CLUSTER_HIVE_LIB_JARS = "clusterHiveLibJars";
    public static final String DS_OPTION_TERADATA_CLASSPATH_JARS = "cpJars";
    public static final String DS_OPTION_TERADATA_TDCH_JAR = "tdchJar";
    @Value("${edmhdpef.server.hostname}")
    public String hostName;
    @Resource
    private EncryptionService encryptionService;
    @Resource
    private TemplateCreation templateCreation;
    @Resource
    private OozieActionBuilder oozieActionBuilder;
    @Value(value = "${teradata.tdch.jar}")
    private String tdchJar;
    @Value(value = "${teradata.libjars}")
    private String tdLibJars;
    @Value("${hive.tmp.database}")
    private String tmpDatabase;
    @Value("${hive.tmp.directory}")
    private String tmpDirectory;
    @Value("${edmhdpef.hive.database}")
    private String hiveDatabase;
    @Value("${edmhdpef.cluster.java.path}")
    private String clusterJavaPath;
    @Value("${edmhdpef.cluster.hive.libjars}")
    private String clusterHiveLibJars;
    @Value("${teradata.tdch.insert.method}")
    private String tdInsertMethod;
    @Value("${fs.defaultFS}")
    private String defaultFS;

    @Override
    public List<Element> getDeploySrcActions(Document doc, EdmWorkflow workflow)
            throws EdmHdpEfNotImplementedException, EdmHdpEfInternalException {

        List<DataTransferSpecification> dataTransferSpecification = workflow.getDataTransferSpecification();
        List<Element> elementList = new ArrayList<Element>();
        List<String> actionNames = new ArrayList<>();
        for (DataTransferSpecification spec : dataTransferSpecification)
            actionNames.add("action_" + getWorkflowShellActionName(spec));
        int i = 0;
        for (DataTransferSpecification spec : dataTransferSpecification) {
            // Action shell
            i++;
            OozieAction shellAction = new OozieAction();
            String actionDestination = i < dataTransferSpecification.size() ? actionNames.get(i) : "end";
            shellAction.setActionDestination(actionDestination);
            String actionName = i > 1 ? actionNames.get(i - 1) : EdmhdpefCommon.getSourceActionName(workflow);
            shellAction.setActionName(actionName);
            shellAction.setCaptureOutput(false);
            shellAction.setDocument(doc);
            shellAction.setFileName(getWorkflowShellActionName(spec) + "-dst.sh");
            Map<String, String> options = new HashMap<>();
            shellAction.setOptions(options);
            shellAction.setParameters(workflow.getParameters());
            shellAction.setRequiredFiles(this.getDeploySrcScripts(workflow).keySet());
            shellAction.setWorkflow(workflow);
            elementList.add(this.oozieActionBuilder.createOozieShellAction(shellAction));

        }
        return elementList;
    }

    private String getWorkflowShellActionName(DataTransferSpecification spec) {
        return spec.getSourceTable() + "_" + spec.getDestinationTable();
    }

    @Override
    public List<Element> getDeployDstActions(Document doc, EdmWorkflow workflow)
            throws EdmHdpEfAppException, EdmHdpEfInternalException, EdmHdpEfNotImplementedException {
        EdmhdpefCommon.validateWorkflowForDeployment(workflow);

        if (doc == null) {
            throw new EdmHdpEfInternalException(InternalExceptionCode.ERROR_CREATING_CONFIG_FILES);
        }

        HashMap<String, String> options = new HashMap<String, String>();
        // Default options
        for (EdmhdpefProperty property : getOptions()) {
            options.put(property.getPropertyName(), property.getDefaultValue());
        }
        // Workflow options
        if (workflow.getDestinationOptions() != null) {
            options.putAll(workflow.getDestinationOptions());
        }
        options.put("tmpDirectory", tmpDirectory);
        options.put("tmpDatabase", tmpDatabase);
        // Tmp table
        String tmpTable = "edmhdpef_" + workflow.getName() + "_${wf:actionData('"
                + EdmhdpefCommon.getSourceActionName(workflow) + "')['"
                + EdmhdpefConstants.SPEC_PARAM_MAX_PARTITION_BDAY + "']}";
        if (workflow.getProcessing() != null && !workflow.getProcessing().isEmpty()) {
            tmpTable = tmpTable + "_" + workflow.getProcessing().size();
        }
        options.put("tmptable", tmpTable);

        options.put("exec_timestamp", "${exec_timestamp}");
        options.put("exec_datehour", "${exec_datehour}");

        // Parameters to get business day
        if (EdmhdpefCommon.isBusinessDayRequired(workflow)) {
            // Add max business day
            options.put("MAX_BUSINESS_DAY",
                    "${firstNotNull(wf:actionData('" + EdmhdpefCommon.getSourceActionName(workflow) + "')['"
                            + EdmhdpefConstants.SPEC_PARAM_MAX_PARTITION_BDAY + "'], '\"\"')}");
        }


        // Action shell
        OozieAction shellAction = new OozieAction();
        shellAction.setActionDestination("end");
        shellAction.setActionName(EdmhdpefCommon.getDestinationActionName(workflow));
        shellAction.setCaptureOutput(false);
        shellAction.setDocument(doc);
        shellAction.setFileName(workflow.getName() + "-dst.sh");
        shellAction.setOptions(options);
        shellAction.setParameters(workflow.getParameters());
        shellAction.setRequiredFiles(this.getDeployDstScripts(workflow).keySet());
        shellAction.setWorkflow(workflow);

        List<Element> elementList = new ArrayList<Element>();
        elementList.add(this.oozieActionBuilder.createOozieShellAction(shellAction));
        return elementList;
    }

    @Override
    public Map<String, String> getDeploySrcScripts(EdmWorkflow workflow) throws EdmHdpEfNotImplementedException, EdmHdpEfInternalException {
        Map<String, String> destinationFiles = new HashMap<>();
        HashMap<String, Object> model = new HashMap<>();
        model.putAll(workflow.getSource().getParameters());
        model.putAll(workflow.getDestination().getParameters());
        model.putAll(workflow.getSourceOptions());
        model.putAll(workflow.getDestinationOptions());
        model.put("restPort", String.valueOf(DelegatingFilterProxyImpl.port));
        model.put("nnFsUrl", defaultFS);
        model.put("tdchJar", tdchJar);
        for (DataTransferSpecification spec : workflow.getDataTransferSpecification())
            try {
                model.putAll(BeanUtils.describe(spec));
                model.put("sourcetable", spec.getSourceTable());
                List<EdmColumns> columns = spec.getColumns();
                StringBuilder sourceFieldsNameBuilder = new StringBuilder();
                StringBuilder destFieldsNameBuilder = new StringBuilder();
                for (EdmColumns col : columns) {
                    sourceFieldsNameBuilder.append(col.getSource() + ",");
                    destFieldsNameBuilder.append(col.getDestination() + ",");
                }
                model.put("restHost", hostName);
                model.put("shell_username", EdmhdpefCommon.getUser());
                model.put("sourcefieldnames", sourceFieldsNameBuilder.deleteCharAt(sourceFieldsNameBuilder.length() - 1).toString());
                model.put("targetfieldnames", destFieldsNameBuilder.deleteCharAt(destFieldsNameBuilder.length() - 1).toString());
                model.put("targetfieldnames", destFieldsNameBuilder.deleteCharAt(destFieldsNameBuilder.length() - 1).toString());
                model.put("warehouse", spec.getDestinationDatabase() + "/" + spec.getDestinationTable());
                destinationFiles.put(getWorkflowShellActionName(spec) + "-dst.sh",
                        this.templateCreation.getTemplate("teradata/workflow-src.sh", model));

            } catch (Exception e) {
                throw new EdmHdpEfInternalException(InternalExceptionCode.ERROR_CREATING_CONFIG_FILES, e.getMessage(), e);
            }
        ;

        appendTDCHJars(destinationFiles);
        return destinationFiles;
    }

    @Override
    public Map<String, String> getDeployDstScripts(EdmWorkflow workflow)
            throws EdmHdpEfAppException, EdmHdpEfInternalException, EdmHdpEfNotImplementedException {
        EdmhdpefCommon.validateWorkflowForDeployment(workflow);
        Map<String, String> sourceOptions = workflow.getSourceOptions();

        Map<String, String> destinationFiles = new HashMap<String, String>();

        appendTDCHJars(destinationFiles);


        Map<String, String> dstParams = workflow.getDestination().getParameters();
        if (dstParams == null) {
            throw new EdmHdpEfInternalException(InternalExceptionCode.ERROR_CREATING_CONFIG_FILES);
        }

        HashMap<String, Object> model = new HashMap<String, Object>();
        model.put("workflowName", workflow.getName());
        model.put("sourceType", workflow.getDestination().getType());
        model.put("dataTransferSpecs", workflow.getDataTransferSpecification());
        model.put("wfparams", workflow.getParameters());
        model.put("MAX_BUSINESS_DAY", "MAX_BUSINESS_DAY");
        model.put("tmpDatabase", tmpDatabase);
        model.put("tmpDirectory", tmpDirectory);
        model.put("hiveDatabase", hiveDatabase);
        model.put("edmhdpefServerPort", Integer.toString(DelegatingFilterProxyImpl.port));
        model.put("edmhdpefServerHostname", hostName);
        model.put("shell_username", EdmhdpefCommon.getUser());
        // Default values for parameters
        for (EdmhdpefProperty param : getParameters()) {
            model.put(param.getPropertyName(), param.getDefaultValue());
        }
        // Datasource parameters
        for (Entry<String, String> entry : dstParams.entrySet()) {
            model.put(entry.getKey(), entry.getValue());
        }
        // Default values for options
        for (EdmhdpefProperty option : getOptions()) {
            model.put(option.getPropertyName(), option.getDefaultValue());
        }
        // Setted Values for options
        if (workflow.getDestinationOptions() != null) {
            for (Entry<String, String> entry : workflow.getDestinationOptions().entrySet()) {
                model.put(entry.getKey(), entry.getValue());
            }
        }

        // Identify max no. of columns
        int maxCols = -1;
        for (DataTransferSpecification spec : workflow.getDataTransferSpecification()) {
            maxCols = Math.max(maxCols, spec.getColumns().size());
        }
        model.put("maxCols", maxCols);
        model.put("bdayRequired", EdmhdpefCommon.isBusinessDayRequired(workflow));


        /*
         * SQL file to create temporary table
         */
        List<Integer> typeSizes = new ArrayList<Integer>(Collections.nCopies(maxCols, Integer.valueOf(1)));

        for (DataTransferSpecification spec : workflow.getDataTransferSpecification()) {
            int count = 0;
            for (EdmColumns col : spec.getColumns()) {
                Integer colsize = Integer.valueOf(sizeOfType(col.getDatatype()));
                if (typeSizes.get(count) < colsize) {
                    typeSizes.set(count, colsize);
                }
                count++;
            }
        }
        model.put("typeSizes", typeSizes);

        destinationFiles.put("TD_drop_tmp_table.sql",
                this.templateCreation.getTemplate("teradata/TD_drop_tmp_table.sql", model));

        destinationFiles.put("TD_create_tmp_table.sql",
                this.templateCreation.getTemplate("teradata/TD_create_tmp_table.sql", model));

        destinationFiles.put("TD_count_tmp_table.sql",
                this.templateCreation.getTemplate("teradata/TD_count_tmp_table.sql", model));

        destinationFiles.put("TD_split_tmp_table.sql",
                this.templateCreation.getTemplate("teradata/TD_split_tmp_table.sql", model));

        // Shell script to execute commands
        destinationFiles.put(workflow.getName() + "-dst.sh",
                this.templateCreation.getTemplate("teradata/workflow-dst.sh", model));

        return destinationFiles;
    }

    private void appendTDCHJars(Map<String, String> destinationFiles) {
        destinationFiles.put("JDBCShell.jar", "");
        // Teradata libraries
        String[] teradata_jars = tdLibJars.split(",");
        for (String j : teradata_jars) {
            if (j.isEmpty()) {
                throw new RuntimeException("expecting non-empty Teradata jar");
            }
            destinationFiles.put(j, "");
        }
        destinationFiles.put(tdchJar, "");
    }

    private int sizeOfType(String t) throws EdmHdpEfNotImplementedException {
        String type = t.toUpperCase();
        int size = -1;
        if ("BYTEINT".equals(type))
            size = 1;
        else if ("SMALLINT".equals(type))
            size = 2;
        else if ("INTEGER".equals(type) || "INT".equals(type))
            size = 4;
        else if ("BIGINT".equals(type))
            size = 8;
        else if ("FLOAT".equals(type) || "REAL".equals(type) || "DOUBLE PRECISION".equals(type))
            size = 8;
        else if (type.indexOf("DECIMAL") >= 0 || type.indexOf("NUMERIC") >= 0)
            size = 16;
        else if (type.indexOf("BYTE") >= 0)
            size = parseSingleValue(type);
        else if (type.indexOf("DATE") >= 0 || type.indexOf("TIME") >= 0)
            size = 12;
        else if (type.indexOf("INTERVAL") >= 0)
            size = 12;
        else if (type.indexOf("CHAR") >= 0)
            size = parseSingleValue(type);
        else {
            throw new EdmHdpEfNotImplementedException(NotImplementedExceptionCode.TYPE_NOT_RECOGNIZED, "Type '" + type
                    + "' not recognized");
        }
        return size;
    }

    private int parseSingleValue(String t) throws EdmHdpEfNotImplementedException {
        int start = t.indexOf("(");
        if (start < 0) {
            return 1;
        }
        int end = t.indexOf(")");
        if (end < 0) {
            throw new RuntimeException("didnt find trailing ')'");
        }
        String sub = t.substring(start + 1, end);
        int spec;
        try {
            spec = Integer.valueOf(sub).intValue();
        } catch (NumberFormatException nfe) {
            System.err.println("Expecting single integer value at '" + sub + "' in '" + t + "'; defaulting to 16");
            spec = 16;
        }
        return spec;
    }

    @Override
    public List<EdmhdpefProperty> getParameters() {
        List<EdmhdpefProperty> returnList = new ArrayList<EdmhdpefProperty>();

        returnList.add(new EdmhdpefProperty(DS_PARAM_TERADATA_JDBCSTRING, false, "jdbc:teradata://DatabaseServerName",
                "JDBC connection string (jdbc:teradata://DatabaseServerName)"));
        returnList.add(new EdmhdpefProperty(DS_PARAM_TERADATA_USERNAME, false, null, "User name"));
        returnList.add(new EdmhdpefProperty(DS_PARAM_TERADATA_PASSWORD, false, null, "Password"));

        return returnList;
    }

    @Override
    public void validateParameters(Map<String, String> parameters) throws EdmHdpEfAppException {
        //FIXME add startswith jdbc:teradata as prefix
        if (!parameters.get(DS_PARAM_TERADATA_JDBCSTRING).startsWith("jdbc:")) {
            throw new EdmHdpEfAppException(AppExceptionCode.PARAMETER_ERROR,
                    parameters.get(DS_PARAM_TERADATA_JDBCSTRING)
                            + " does not seems to be a valid Teradata JDBC connection string.");
        }
    }

    @Override
    public List<EdmhdpefProperty> getOptions() {
        List<EdmhdpefProperty> returnList = new ArrayList<EdmhdpefProperty>();

        returnList.add(new EdmhdpefProperty(DS_OPTION_TERADATA_COMMAND_ARGS, true, "",
                "Optional arguments to add to TDCH command."));
        returnList.add(new EdmhdpefProperty(DS_OPTION_TERADATA_INSERT_METHOD, true, tdInsertMethod,
                "Teradata Insert Method to use [ batch.insert | multiple.fastload | internal.fastload ]."));
        returnList.add(new EdmhdpefProperty(DS_OPTION_TERADATA_CLUSTER_JAVA_PATH, true, clusterJavaPath,
                "Java Path in the cluster."));
        returnList.add(new EdmhdpefProperty(DS_OPTION_TERADATA_CLUSTER_HIVE_LIB_JARS, true, clusterHiveLibJars,
                "Path of the Hive libraries in the cluster."));
        returnList.add(new EdmhdpefProperty(DS_OPTION_TERADATA_CLASSPATH_JARS, true,
                clusterHiveLibJars.replace(',', ':'), "List of jars to add to the classpath."));
        returnList.add(new EdmhdpefProperty(DS_OPTION_TERADATA_TDCH_JAR, true, tdchJar, "Path of the TDCH jar file."));

        return returnList;
    }

    @Override
    public void validateOptions(Map<String, String> sourceOptions)
            throws EdmHdpEfAppException, EdmHdpEfInternalException {

    }


}