package com.scb.edmhdpef.services.datasourcemng;

import org.w3c.dom.Element;

import com.scb.edmhdpef.services.model.OozieAction;

public interface OozieActionBuilder {

	public Element createOozieShellAction(OozieAction action);

	public Element createOozieHiveAction(OozieAction action);

	public Element createOozieJavaAction(OozieAction action);

	public Element createOozieFsAction(OozieAction action);
}
