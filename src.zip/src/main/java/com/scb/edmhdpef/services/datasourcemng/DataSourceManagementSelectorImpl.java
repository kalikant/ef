package com.scb.edmhdpef.services.datasourcemng;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.scb.edmhdpef.entity.EdmDataSource;
import com.scb.edmhdpef.exceptions.EdmHdpEfNotImplementedException;

@Service("dataSourceManagementSelector")
public class DataSourceManagementSelectorImpl implements DataSourceManagementSelector {

	@Resource
	private DataSourceManagement hiveManagement;

	@Resource(name = "hdfsManagement")
	private DataSourceManagement hdfsManagement;

	@Resource
	private DataSourceManagement teradataManagement;

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.scb.edmhdpef.services.datasourcemng.DataSourceManagementSelector#
	 * getDataSourceManagement(com.scb.edmhdpef.entity.EdmDataSource)
	 */
	@Override
	public DataSourceManagement getDataSourceManagement(EdmDataSource dataSource)
			throws EdmHdpEfNotImplementedException {
		switch (dataSource.getType()) {
		case HIVE:
			return hiveManagement;
		case HDFS:
			return hdfsManagement;
		case TERADATA:
			return teradataManagement;
		default:
			throw new EdmHdpEfNotImplementedException("Type " + dataSource.getType() + " not implemented.");
		}
	}
}
