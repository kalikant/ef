package com.scb.edmhdpef.services.execution;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.scb.edmhdpef.EdmhdpefCommon;
import com.scb.edmhdpef.EdmhdpefConstants;
import com.scb.edmhdpef.entity.DataProcessing;
import com.scb.edmhdpef.entity.DataTransferSpecification;
import com.scb.edmhdpef.entity.EdmColumns;
import com.scb.edmhdpef.entity.EdmWorkflow;
import com.scb.edmhdpef.enums.DataProcessingType;
import com.scb.edmhdpef.exceptions.EdmHdpEfAppException;
import com.scb.edmhdpef.exceptions.EdmHdpEfAppException.AppExceptionCode;
import com.scb.edmhdpef.exceptions.EdmHdpEfInternalException;
import com.scb.edmhdpef.exceptions.EdmHdpEfInternalException.InternalExceptionCode;
import com.scb.edmhdpef.exceptions.EdmHdpEfNotImplementedException;
import com.scb.edmhdpef.services.datasourcemng.OozieActionBuilder;
import com.scb.edmhdpef.services.model.EdmhdpefProperty;
import com.scb.edmhdpef.services.model.OozieAction;

@Service("dataProcessingService")
public class DataProcessingServiceImpl implements DataProcessingService {

	@Resource
	OozieActionBuilder oozieActionBuilder;

	@Value("${edmhdpef.data.processing.jar.file}")
	private String dataProcessingJar;

	@Value("${hive.tmp.database}")
	private String tmpDatabase;

	@Value("${hive.tmp.directory}")
	private String tmpDirectory;

	private static final String PROP_LINE_SEPARATOR = ",";

	@Override
	public List<EdmhdpefProperty> getOptions(DataProcessingType type) {
		List<EdmhdpefProperty> options = new ArrayList<EdmhdpefProperty>();
		switch (type) {
		case HEADER_AND_FOOTER:
			// options.add(new EdmhdpefProperty("checksumValidation", true,
			// "false",
			// "Validates that a checksum column is defined for every
			// destination table."));
			// options.add(new EdmhdpefProperty("checksumColumn", true, "",
			// "<destination database>.<destination table name>.checksumColumn -
			// Name of the column to use in the checksum calculation. If not
			// specified, the checksum will be 0."));
			break;
		case TRIMMED_SRI:
			// options.add(new EdmhdpefProperty("timestampValidation", true,
			// "false",
			// "Validates that a timestamp column is defined for every
			// destination table."));
			// options.add(new EdmhdpefProperty("functionalKeyValidation", true,
			// "false",
			// "Validates that a functionalKey column is defined for every
			// destination table."));
			// options.add(new EdmhdpefProperty("operationTypeValidation", true,
			// "false",
			// "Validates that a operationType column is defined for every
			// destination table."));
			// options.add(new EdmhdpefProperty("timestampColumn", false, "",
			// "<destination database>.<destination table name>.timestampColumn
			// - Name of the column that contains the timestamp value. If not
			// specified, the position of the row on the file or dataset will be
			// used."));
			// options.add(new EdmhdpefProperty("functionalKeyColumns", false,
			// "",
			// "<destination database>.<destination table name>.timestampColumn
			// - Comma separated list of the columns containing the functional
			// key. If not specified, the entire row will be used."));
			// options.add(new EdmhdpefProperty("operationTypeColumn", true, "",
			// "<destination database>.<destination table
			// name>.operationTypeColumn - Name of the column containing the
			// operation type value. This row should be one character of (I, A,
			// B, D). If not specified, all the operations will be considered as
			// inserts or updates."));
			break;
		}
		return options;
	}

	@Override
	public void validateOptions(EdmWorkflow workflow, DataProcessing dataProcessing)
			throws EdmHdpEfAppException, EdmHdpEfInternalException {

		if (dataProcessing.getOptions() == null) {
			dataProcessing.setOptions(new HashMap<String, String>());
		}

		for (EdmhdpefProperty property : getOptions(dataProcessing.getType())) {
			if (!property.isOptional() && !dataProcessing.getOptions().containsKey(property.getPropertyName())) {
				throw new EdmHdpEfAppException(AppExceptionCode.PARAMETER_NOT_SPECIFIED,
						"The parameter '" + property.getPropertyName() + "' is compulsory for processing type "
								+ dataProcessing.getType());
			}
		}

		switch (dataProcessing.getType()) {
		case HEADER_AND_FOOTER:
			// No more than 10 columns are defined as checksum for each
			// destination
			for (DataTransferSpecification spec : workflow.getDataTransferSpecification()) {
				List<String> checksumColumns = new ArrayList<>();
				for (EdmColumns col : spec.getColumns()) {
					if (col.getChecksum()) {
						checksumColumns.add(col.getDestination());
						if (checksumColumns.size() > 10) {
							throw new EdmHdpEfAppException(AppExceptionCode.PARAMETER_ERROR,
									"There is more than 10 checksum columns for destination "
											+ spec.getDestinationDatabase() + "." + spec.getDestinationTable());
						}
					}
				}
				// Add checksumColumns as option
				String chkColumns = checksumColumns.toString();
				chkColumns = chkColumns.substring(1, chkColumns.length() - 1);
				dataProcessing.getOptions().put(
						spec.getDestinationDatabase() + "." + spec.getDestinationTable() + ".checksumColumn",
						chkColumns);
			}
			break;
		case TRIMMED_SRI:
			// At least one functional key
			// No more than one timestamp column
			for (DataTransferSpecification spec : workflow.getDataTransferSpecification()) {
				List<String> functionalKeys = new ArrayList<>();
				List<String> timeStamps = new ArrayList<>();
				for (EdmColumns col : spec.getColumns()) {
					if (col.getFunctionalKey()) {
						functionalKeys.add(col.getDestination());
					}
					if (col.getTimestamp()) {
						timeStamps.add(col.getDestination());
					}
				}
				if (functionalKeys.size() == 0) {
					throw new EdmHdpEfAppException(AppExceptionCode.PARAMETER_ERROR,
							"No functional key columns defined for destination " + spec.getDestinationDatabase() + "."
									+ spec.getDestinationTable());
				}
				if (timeStamps.size() == 0) {
					throw new EdmHdpEfAppException(AppExceptionCode.PARAMETER_ERROR,
							"No time stamp column defined for destination " + spec.getDestinationDatabase() + "."
									+ spec.getDestinationTable());
				}
				if (timeStamps.size() > 1) {
					throw new EdmHdpEfAppException(AppExceptionCode.PARAMETER_ERROR,
							"More than one time stamp column defined for destination " + spec.getDestinationDatabase()
									+ "." + spec.getDestinationTable());
				}
				String fkeyColumns = functionalKeys.toString();
				fkeyColumns = fkeyColumns.substring(1, fkeyColumns.length() - 1);
				dataProcessing.getOptions().put(
						spec.getDestinationDatabase() + "." + spec.getDestinationTable() + ".functionalKeyColumns",
						fkeyColumns);
				dataProcessing.getOptions().put(
						spec.getDestinationDatabase() + "." + spec.getDestinationTable() + ".timestampColumn",
						timeStamps.get(0));
			}
		}
	}

	@Override
	public List<Element> getDeployProcessingActions(Document doc, EdmWorkflow workflow)
			throws EdmHdpEfAppException, EdmHdpEfInternalException, EdmHdpEfNotImplementedException {

		EdmhdpefCommon.validateWorkflowForDeployment(workflow);

		if (doc == null) {
			throw new EdmHdpEfInternalException(InternalExceptionCode.ERROR_CREATING_CONFIG_FILES);
		}

		List<Element> elementList = new ArrayList<Element>();

		Iterator<DataProcessing> it = workflow.getProcessing().iterator();

		int count = 0;

		while (it.hasNext()) {
			DataProcessing processing = it.next();

			OozieAction javaAction = new OozieAction();
			if (it.hasNext()) {
				javaAction.setActionDestination(EdmhdpefCommon.getDataProcessingActionName(workflow, count + 1));
			} else {
				javaAction.setActionDestination(EdmhdpefCommon.getDestinationActionName(workflow));
			}
			javaAction.setActionName(EdmhdpefCommon.getDataProcessingActionName(workflow, count));
			javaAction.setCaptureOutput(true);
			javaAction.setDocument(doc);

			switch (processing.getType()) {
			case HEADER_AND_FOOTER:
				javaAction.setFileName("com.scb.edmhdpef.dataprocessing.hf.HeaderAndFooter");
				break;
			case TRIMMED_SRI:
				javaAction.setFileName("com.scb.edmhdpef.dataprocessing.trimmedsri.TrimmedSRI");
				break;
			}

			Map<String, String> options = new HashMap<String, String>();
			// Default options
			for (EdmhdpefProperty property : getOptions(processing.getType())) {
				options.put(property.getPropertyName(), property.getDefaultValue());
			}
			// Processing options
			options.putAll(processing.getOptions());

			options.put("tmpDirectory", tmpDirectory);
			options.put("tmpDatabase", tmpDatabase);
			// Tmp table
			String tmpTable = "edmhdpef_" + workflow.getName() + "_${wf:actionData('"
					+ EdmhdpefCommon.getSourceActionName(workflow) + "')['"
					+ EdmhdpefConstants.SPEC_PARAM_MAX_PARTITION_BDAY + "']}";
			options.put("tmptable", tmpTable);
			// Schema
			for (DataTransferSpecification spec : workflow.getDataTransferSpecification()) {
				String key = spec.getDestinationDatabase() + '.' + spec.getDestinationTable() + ".schema";
				StringBuilder value = null;
				for (EdmColumns column : spec.getColumns()) {
					if (value == null) {
						value = new StringBuilder(column.getDestination());
					} else {
						value = value.append(PROP_LINE_SEPARATOR).append(column.getDestination());
					}
				}
				options.put(key, value.toString());
			}

			if (count == 0) {
				options.put("inputPath", tmpDirectory + "/" + tmpTable);
				options.put("outputPath", tmpDirectory + "/" + tmpTable + "_1");
			} else {
				options.put("inputPath", tmpDirectory + "/" + tmpTable + "_" + count);
				options.put("outputPath", tmpDirectory + "/" + tmpTable + "_" + (count + 1));
			}

			javaAction.setOptions(options);

			javaAction.setParameters(workflow.getParameters());

			HashSet<String> requiredFiles = new HashSet<String>();
			requiredFiles.add(dataProcessingJar);
			javaAction.setRequiredFiles(requiredFiles);

			javaAction.setWorkflow(workflow);

			elementList.add(this.oozieActionBuilder.createOozieJavaAction(javaAction));
			count++;
		}

		return elementList;
	}

}
