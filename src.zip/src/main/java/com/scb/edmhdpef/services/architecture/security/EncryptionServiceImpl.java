package com.scb.edmhdpef.services.architecture.security;

import java.io.UnsupportedEncodingException;
import java.security.GeneralSecurityException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.scb.edmhdpef.EdmhdpefConstants;
import com.scb.edmhdpef.entity.EncryptKey;
import com.scb.edmhdpef.exceptions.EdmHdpEfInternalException;
import com.scb.edmhdpef.exceptions.EdmHdpEfInternalException.InternalExceptionCode;
import com.scb.edmhdpef.services.database.DataAccessService;

@Service("encryptionService")
public class EncryptionServiceImpl implements EncryptionService {

    @Resource
    private DataAccessService dataAccessService;

    private Pattern encoded = Pattern.compile("ENC\\(.*\\)");

    private Cipher cipher;

    private Logger logger = LoggerFactory.getLogger(EncryptionServiceImpl.class);

    @PostConstruct
    public void initIt() throws NoSuchAlgorithmException, NoSuchPaddingException {
        cipher = Cipher.getInstance("AES/CBC/PKCS5PADDING");
    }

    @Override
    public Map<String, String> encryptParameters(Map<String, String> parameters) throws EdmHdpEfInternalException {
        try {
            if (parameters == null || parameters.isEmpty()) {
                return parameters;
            }
            EncryptKey key = (EncryptKey) this.dataAccessService.retrieveById(EncryptKey.class,
                    EdmhdpefConstants.ENCRYPT_KEY_NAME);
            if (key == null) {
                key = generateKey();
                this.dataAccessService.saveOrUpdateObject(key);
            }
            SecretKeySpec skeySpec = new SecretKeySpec(key.getKeyValue(), "AES");
            IvParameterSpec ivParameterSpec = new IvParameterSpec(key.getKeyValue());

            Map<String, String> retParameters = new HashMap<String, String>();
            for (Entry<String, String> param : parameters.entrySet()) {
                String value = param.getValue();
                if (param.getKey().contains("password")) {
                    Matcher matcher = encoded.matcher(value);
                    if (!matcher.matches()) {
                        // Encrypt property
                        try {
                            logger.info("Encoding parameter '" + param.getKey() + '\'');
                            value = "ENC(" + encrypt(value, skeySpec, ivParameterSpec) + ")";
                        } catch (GeneralSecurityException e) {
                            throw new EdmHdpEfInternalException(InternalExceptionCode.ENCRYPTION_ERROR, e.getMessage(),
                                    e);
                        }
                    }
                }
                retParameters.put(param.getKey(), value);
            }
            return retParameters;
        } catch (Exception e) {
            throw new EdmHdpEfInternalException(InternalExceptionCode.ENCRYPTION_ERROR, "Error encrypting password.", e);
        }

    }

    @Override
    public Map<String, String> decryptParameters(Map<String, String> parameters) throws EdmHdpEfInternalException {
        try {
            if (parameters == null || parameters.isEmpty()) {
                return parameters;
            }
            EncryptKey key = (EncryptKey) this.dataAccessService.retrieveById(EncryptKey.class,
                    EdmhdpefConstants.ENCRYPT_KEY_NAME);
            if (key == null) {
                key = generateKey();
                this.dataAccessService.saveOrUpdateObject(key);
            }
            SecretKeySpec skeySpec = new SecretKeySpec(key.getKeyValue(), "AES");
            IvParameterSpec ivParameterSpec = new IvParameterSpec(key.getKeyValue());

            Map<String, String> retParameters = new HashMap<String, String>();
            for (Entry<String, String> param : parameters.entrySet()) {
                String value = param.getValue();
                if (param.getKey().contains("password")) {
                    Matcher matcher = encoded.matcher(value);
                    if (matcher.matches()) {
                        logger.info("Decoding parameter '" + param.getKey() + '\'');
                        // Trim ENC( and )
                        value = value.substring(4, value.length() - 1);
                        // Decrypt
                        try {
                            value = decrypt(value, skeySpec, ivParameterSpec);
                        } catch (GeneralSecurityException e) {
                            throw new EdmHdpEfInternalException(InternalExceptionCode.ENCRYPTION_ERROR, e.getMessage(),
                                    e);
                        }
                    }
                }
                retParameters.put(param.getKey(), value);
            }
            return retParameters;
        } catch (Exception e) {
            throw new EdmHdpEfInternalException(InternalExceptionCode.ENCRYPTION_ERROR, "Error decrypting password: "
                    + e.getMessage(), e);
        }
    }

    private EncryptKey generateKey() throws EdmHdpEfInternalException {
        try {
            KeyGenerator keyGen = KeyGenerator.getInstance("AES");
            keyGen.init(new SecureRandom());
            SecretKey secretKey = keyGen.generateKey();

            EncryptKey key = new EncryptKey();
            key.setKeyName(EdmhdpefConstants.ENCRYPT_KEY_NAME);
            key.setKeyValue(secretKey.getEncoded());
            return key;
        } catch (Exception e) {
            throw new EdmHdpEfInternalException(InternalExceptionCode.ENCRYPTION_ERROR,
                    "Error generation encryption key.", e);
        }
    }

    private String encrypt(String input, SecretKeySpec skeySpec, IvParameterSpec ivParameterSpec)
            throws GeneralSecurityException, NoSuchPaddingException, UnsupportedEncodingException {
        cipher.init(Cipher.ENCRYPT_MODE, skeySpec, ivParameterSpec);
        byte[] encrypted = cipher.doFinal(input.getBytes());
        String encryptedString = Base64.encodeBase64String(encrypted);
        return encryptedString;
    }

    private String decrypt(String input, SecretKeySpec skeySpec, IvParameterSpec ivParameterSpec)
            throws GeneralSecurityException, NoSuchPaddingException, UnsupportedEncodingException {
        cipher.init(Cipher.DECRYPT_MODE, skeySpec, ivParameterSpec);
        byte[] encrypted = Base64.decodeBase64(input);
        return new String(cipher.doFinal(encrypted));
    }

}