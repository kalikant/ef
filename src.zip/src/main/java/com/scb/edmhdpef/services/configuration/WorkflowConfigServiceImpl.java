package com.scb.edmhdpef.services.configuration;

import com.scb.edmhdpef.EdmhdpefConstants;
import com.scb.edmhdpef.entity.*;
import com.scb.edmhdpef.enums.BusinessDayBehaviorEnum;
import com.scb.edmhdpef.enums.EdmWorkflowTypeEnum;
import com.scb.edmhdpef.exceptions.EdmHdpEfAppException;
import com.scb.edmhdpef.exceptions.EdmHdpEfAppException.AppExceptionCode;
import com.scb.edmhdpef.exceptions.EdmHdpEfInternalException;
import com.scb.edmhdpef.exceptions.EdmHdpEfNotImplementedException;
import com.scb.edmhdpef.services.database.DataAccessService;
import com.scb.edmhdpef.services.database.HiveDumpService;
import com.scb.edmhdpef.services.datasourcemng.DataSourceManagement;
import com.scb.edmhdpef.services.datasourcemng.DataSourceManagementSelector;
import com.scb.edmhdpef.services.execution.DataProcessingService;
import org.dozer.DozerBeanMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Service("workflowConfigService")
public class WorkflowConfigServiceImpl implements WorkflowConfigService {

    private static final Logger logger = LoggerFactory.getLogger(WorkflowConfigServiceImpl.class);

    // Regexp for variable substitution
    private final Pattern variablePattern = Pattern.compile("\\$(\\{[^\\}]*\\}|[^\\s]*)");

    @Resource(name = "dataAccessService")
    private DataAccessService dataAccess;

    @Resource
    private HiveDumpService hiveDumpService;

    @Resource
    private DozerBeanMapper mappingService;

    @Resource
    private DataSourceManagementSelector dataSourceManagementSelector;

    @Resource
    private DataProcessingService dataProcessingService;

    @SuppressWarnings("unchecked")
    @Override
    public List<EdmWorkflow> retrieveWorkflows(EdmWorkflow criteria) {
        if (criteria == null) {
            criteria = new EdmWorkflow();
        }
        if (criteria != null && criteria.getName() != null && !criteria.getName().trim().isEmpty()) {
            List<EdmWorkflow> list = new ArrayList<EdmWorkflow>();
            EdmWorkflow wf = (EdmWorkflow) this.dataAccess.retrieveById(EdmWorkflow.class, criteria.getName());
            if (wf != null) {
                list.add(wf);
            }
            return list;
        } else {
            return (List<EdmWorkflow>) dataAccess.retrieveByCriteria(criteria);
        }
    }

    @Override
    public EdmWorkflow createWorkflow(EdmWorkflow workflow) throws EdmHdpEfAppException, EdmHdpEfInternalException,
            EdmHdpEfNotImplementedException {

        validateWorkflow(workflow);

        EdmWorkflow existentWorkflow = (EdmWorkflow) this.dataAccess
                .retrieveById(EdmWorkflow.class, workflow.getName());

        if (existentWorkflow != null) {
            throw new EdmHdpEfAppException(AppExceptionCode.ENTITY_ALREADY_EXISTS, "Workflow " + workflow.getName()
                    + " already exists.");
        }

        return (EdmWorkflow) dataAccess.saveOrUpdateObject(workflow);
    }

    @Override
    public void deleteWorkflow(EdmWorkflow workflow) throws EdmHdpEfAppException, EdmHdpEfInternalException {
        if (workflow.getName() == null || workflow.getName().trim().isEmpty()) {
            throw new EdmHdpEfAppException(AppExceptionCode.PARAMETER_NOT_SPECIFIED, "Workflow name not specified.");
        }

        EdmWorkflow existentWorkflow = (EdmWorkflow) this.dataAccess
                .retrieveById(EdmWorkflow.class, workflow.getName());

        if (existentWorkflow == null) {
            throw new EdmHdpEfAppException(AppExceptionCode.PARAMETER_NOT_SPECIFIED, "Workflow " + workflow.getName()
                    + " does not exist.");
        }

        // Delete workflow executions
        List<WorkflowExecution> executions = this.dataAccess
                .retrieveWorkflowExecutionByWorkflowName(workflow.getName());
        logger.info("Deleting " + executions.size() + " executions related to this workflow.");
        for (WorkflowExecution exToDelete : executions) {
            dataAccess.deleteObject(exToDelete);
        }

        // Delete workflow
        dataAccess.deleteObject(existentWorkflow);
    }

    @Transactional
    @Override
    public EdmWorkflow updateWorkflow(EdmWorkflow workflow) throws EdmHdpEfAppException, EdmHdpEfInternalException,
            EdmHdpEfNotImplementedException {
        validateWorkflow(workflow);

        EdmWorkflow existentWorkflow = (EdmWorkflow) this.dataAccess
                .retrieveById(EdmWorkflow.class, workflow.getName());

        if (existentWorkflow == null) {
            throw new EdmHdpEfAppException(AppExceptionCode.ENTITY_NOT_EXISTS, "Workflow " + workflow.getName()
                    + " does not exist.");
        }

        this.mappingService.map(workflow, existentWorkflow);
        existentWorkflow.setDataTransferSpecification(workflow.getDataTransferSpecification());
        existentWorkflow.setDestinationOptions(workflow.getDestinationOptions());
        existentWorkflow.setSourceOptions(workflow.getSourceOptions());
        existentWorkflow.setParameters(workflow.getParameters());
        existentWorkflow.setProcessing(workflow.getProcessing());

        return (EdmWorkflow) dataAccess.saveOrUpdateObject(existentWorkflow);
    }

    private void validateWorkflow(EdmWorkflow workflow) throws EdmHdpEfAppException, EdmHdpEfNotImplementedException,
            EdmHdpEfInternalException {
        if (workflow.getName() == null || workflow.getName().trim().isEmpty()) {
            throw new EdmHdpEfAppException(AppExceptionCode.PARAMETER_NOT_SPECIFIED, "Workflow name not specified.");
        }

        if (workflow.getType() == null) {
            throw new EdmHdpEfAppException(AppExceptionCode.PARAMETER_NOT_SPECIFIED, "Workflow type not specified.");
        }

        if (workflow.getSource() == null || workflow.getSource().getName() == null
                || workflow.getSource().getName().trim().isEmpty()) {
            throw new EdmHdpEfAppException(AppExceptionCode.PARAMETER_NOT_SPECIFIED, "Data source not specified for "
                    + workflow);
        }
        if (workflow.getDestination() == null || workflow.getDestination().getName() == null
                || workflow.getDestination().getName().trim().isEmpty()) {
            throw new EdmHdpEfAppException(AppExceptionCode.PARAMETER_NOT_SPECIFIED,
                    "Data destination not specified for " + workflow);
        }

        if (workflow.getDataTransferSpecification() == null || workflow.getDataTransferSpecification().isEmpty()) {
            throw new EdmHdpEfAppException(AppExceptionCode.PARAMETER_NOT_SPECIFIED,
                    "No data transfer specifications provided.");
        }

        // Retrieve datasources
        EdmDataSource source = (EdmDataSource) this.dataAccess.retrieveById(EdmDataSource.class, workflow.getSource()
                .getName());
        if (source == null) {
            throw new EdmHdpEfAppException(AppExceptionCode.ENTITY_NOT_EXISTS, "Data source "
                    + workflow.getSource().getName() + " does not exists.");
        }
        EdmDataSource destination = (EdmDataSource) this.dataAccess.retrieveById(EdmDataSource.class, workflow
                .getDestination().getName());
        if (destination == null) {
            throw new EdmHdpEfAppException(AppExceptionCode.ENTITY_NOT_EXISTS, "Data destination "
                    + workflow.getDestination().getName() + " does not exists.");
        }
        workflow.setSource(source);
        workflow.setDestination(destination);

        for (DataTransferSpecification spec : workflow.getDataTransferSpecification()) {
            if (EdmWorkflowTypeEnum.GENERIC.equals(workflow.getType())) {
                // Only for GENERIC workflow
                if ((spec.getColumns() == null || spec.getColumns().isEmpty())
                        && (spec.getFilterCondition() == null || spec.getFilterCondition().trim().isEmpty())) {
                    throw new EdmHdpEfAppException(AppExceptionCode.PARAMETER_NOT_SPECIFIED,
                            "Neither columns or query specified for " + spec);
                }
            }
            if (spec.getFilterCondition() == null || spec.getFilterCondition().trim().isEmpty()) {
                continue;
            }
            // Check variables in filter condition
            Matcher matcher = variablePattern.matcher(spec.getFilterCondition());
            while (matcher.find()) {
                String group = matcher.group();
                String variableName = group.substring(1);
                if (variableName.startsWith("{") && variableName.endsWith("}")) {
                    variableName = variableName.substring(1, variableName.length() - 1);
                }
                if (workflow.getParameters() == null) {
                    workflow.setParameters(new HashSet<String>());
                }
                workflow.getParameters().add(variableName);
            }
            // Replace the variable $var for ${var} in the filter condition,
            // starting by the longest variable name
            if (workflow.getParameters() != null && !workflow.getParameters().isEmpty()) {
                List<String> parametersList = new ArrayList<String>(workflow.getParameters());
                Collections.sort(parametersList, new Comparator<String>() {
                    @Override
                    public int compare(String o1, String o2) {
                        return o2.length() - o1.length();
                    }
                });
                String filterCondition = spec.getFilterCondition();
                for (String param : parametersList) {
                    filterCondition = filterCondition.replaceAll("\\$" + param, "\\$\\{" + param + "\\}");
                }
                spec.setFilterCondition(filterCondition);
            }
        }

        // Validate processing options
        if (workflow.getProcessing() == null) {
            workflow.setProcessing(new ArrayList<DataProcessing>());
        }
        if (EdmWorkflowTypeEnum.GENERIC.equals(workflow.getType()) && !workflow.getProcessing().isEmpty()) {
            throw new EdmHdpEfAppException(AppExceptionCode.PARAMETER_ERROR,
                    "Data processing is not allowed for workflow type " + workflow.getType());
        }
        for (DataProcessing dataProcessing : workflow.getProcessing()) {
            this.dataProcessingService.validateOptions(workflow, dataProcessing);
        }

        // Validate source and destination options
        if (workflow.getSourceOptions() == null) {
            workflow.setSourceOptions(new HashMap<String, String>());
        }
        DataSourceManagement sourceManagement = this.dataSourceManagementSelector.getDataSourceManagement(workflow
                .getSource());
        sourceManagement.validateOptions(workflow.getSourceOptions());
        if (workflow.getDestinationOptions() == null) {
            workflow.setDestinationOptions(new HashMap<String, String>());
        }
        DataSourceManagement destinationManagement = this.dataSourceManagementSelector.getDataSourceManagement(workflow
                .getDestination());
        destinationManagement.validateOptions(workflow.getDestinationOptions());

        // Validate HIVE_TO_TERADATA_TABLE_GROUP special workflow
        if (EdmWorkflowTypeEnum.TABLE_GROUP.equals(workflow.getType())) {
            // boolean bdayRequired =
            validateWorkflowSRIToTeradata(workflow);

            getColumnsDataTypes(workflow);
        }

        for (Object key : workflow.getSourceOptions().keySet()) {
            if (workflow.getDestinationOptions().containsKey(key)) {
                throw new EdmHdpEfAppException(AppExceptionCode.PARAMETER_ERROR, "Same key has values in both source as well as destination options => " + key);
            }
        }
    }

    private boolean validateWorkflowSRIToTeradata(EdmWorkflow workflow) throws EdmHdpEfAppException {
        boolean bdayRequired = false;

        BusinessDayBehaviorEnum bdayBehavior = null;
        for (DataTransferSpecification spec : workflow.getDataTransferSpecification()) {

            if (spec.getSourceDatabase() == null || spec.getSourceDatabase().trim().isEmpty()) {
                throw new EdmHdpEfAppException(AppExceptionCode.PARAMETER_NOT_SPECIFIED,
                        "Source database not specified.");
            }

            if (spec.getSourceTable() == null || spec.getSourceTable().trim().isEmpty()) {
                throw new EdmHdpEfAppException(AppExceptionCode.PARAMETER_NOT_SPECIFIED,
                        "Source table not specified in " + spec);
            }

            if (spec.getDestinationDatabase() == null || spec.getDestinationDatabase().trim().isEmpty()) {
                throw new EdmHdpEfAppException(AppExceptionCode.PARAMETER_NOT_SPECIFIED,
                        "Destination database not specified.");
            }

            if (spec.getDestinationTable() == null || spec.getDestinationTable().trim().isEmpty()) {
                throw new EdmHdpEfAppException(AppExceptionCode.PARAMETER_NOT_SPECIFIED,
                        "Destination table not specified in " + spec);
            }
            if (spec.getBusinessDayBehavior() == null) {
                spec.setBusinessDayBehavior(BusinessDayBehaviorEnum.NO);
            }
            bdayRequired = !BusinessDayBehaviorEnum.NO.equals(spec.getBusinessDayBehavior());

            // Check business day behavior is the same for all the specs
            if (bdayBehavior == null) {
                bdayBehavior = spec.getBusinessDayBehavior();
            } else {
                if (!bdayBehavior.equals(spec.getBusinessDayBehavior())) {
                    throw new EdmHdpEfAppException(AppExceptionCode.PARAMETER_ERROR,
                            "Business day behavior must be the same for all the tables on the workflow. Table: "
                                    + spec.getSourceTable() + " Behavior detected: " + spec.getBusinessDayBehavior()
                                    + ", previous behavior: " + bdayBehavior);
                }
            }

        }
        if (bdayRequired) {
            if (workflow.getBatchToPartitionDatabase() == null
                    || workflow.getBatchToPartitionDatabase().trim().isEmpty()) {
                throw new EdmHdpEfAppException(AppExceptionCode.PARAMETER_NOT_SPECIFIED,
                        "Batch to partition database not specified.");
            }

            if (workflow.getParameters() == null) {
                workflow.setParameters(new HashSet<String>());
            }
            workflow.getParameters().add(EdmhdpefConstants.SPEC_PARAM_BUSINESSDAY);
            workflow.getParameters().add(EdmhdpefConstants.SPEC_PARAM_SOURCE);
            workflow.getParameters().add(EdmhdpefConstants.SPEC_PARAM_COUNTRY);
        }

        return bdayRequired;
    }

    private void getColumnsDataTypes(EdmWorkflow workflow) throws EdmHdpEfInternalException, EdmHdpEfAppException {
        // Get the column data types from Hive
        Map<String, StringBuilder> dataTypesByTable = new HashMap<String, StringBuilder>();
        Set<String> queriesByTable = new HashSet<String>();
        for (DataTransferSpecification spec : workflow.getDataTransferSpecification()) {
            if (spec.getColumns() == null || spec.getColumns().isEmpty()) {
                continue;
            }
            String sourceAndCountry = spec.getSourceTable().split("_")[0] + "_" + spec.getSourceTable().split("_")[1];
            StringBuilder dataTypeQuery = dataTypesByTable.get(sourceAndCountry);
            if (dataTypeQuery == null) {
                dataTypeQuery = new StringBuilder("SELECT tablename, colname, coltype FROM ")
                        .append(workflow.getBatchToPartitionDatabase()).append('.').append(sourceAndCountry)
                        .append("_data_dictionary WHERE 1=0 ");
            }
            dataTypeQuery.append(" OR UPPER(tablename)=UPPER('").append(spec.getSourceTable() + "')");
            StringBuilder query = new StringBuilder("SELECT 1");
            for (EdmColumns col : spec.getColumns()) {
                query.append(',').append(col.getSource());
            }
            query.append(" FROM ").append(spec.getSourceDatabase()).append('.').append(spec.getSourceTable())
                    .append(" LIMIT 0;");
            queriesByTable.add(query.toString());
            dataTypesByTable.put(sourceAndCountry, dataTypeQuery);
        }

        // Run queries on Hive
        for (StringBuilder query : dataTypesByTable.values()) {
            StringBuilder queryToRun = new StringBuilder().append('"');
            for (String q : queriesByTable) {
                queryToRun.append(q);
            }
            queryToRun.append('"');

            // Check column names
            this.hiveDumpService.runHiveQuery(queryToRun.toString());

            // Retrieve schema
            try {
                List<String> resultList = this.hiveDumpService.runHiveQuery('"' + query.toString() + '"');
                Map<String, Map<String, String>> tableColumnMap = new HashMap<>();
                for (String result : resultList) {
                    logger.info(result);

                    String table = result.split("\t")[0].toUpperCase();
                    String column = result.split("\t")[1].toUpperCase();
                    String value = result.split("\t")[2].toUpperCase();
                    if (!tableColumnMap.containsKey(table)) {
                        tableColumnMap.put(table, new HashMap<String, String>());
                    }
                    tableColumnMap.get(table).put(column, value);
                }
                for (DataTransferSpecification spec : workflow.getDataTransferSpecification()) {
                    if (!tableColumnMap.containsKey(spec.getSourceTable().toUpperCase())) {
                        continue;
                    }
                    Map<String, String> columnMap = tableColumnMap.get(spec.getSourceTable().toUpperCase());
                    for (EdmColumns col : spec.getColumns()) {
                        if (!columnMap.containsKey(col.getSource().toUpperCase())) {
                            continue;
                        }
                        col.setDatatype(columnMap.get(col.getSource().toUpperCase()));
                    }
                }
            } catch (EdmHdpEfInternalException e) {
                // Do not end on exception
                logger.warn(e.getMessage());
            }
        }
    }

    // private void getSourceTablePartitionName(EdmWorkflow workflow) throws
    // EdmHdpEfInternalException,
    // EdmHdpEfAppException {
    // logger.info("Retrieving partition names");
    // // Get the column data types from Hive
    // for (DataTransferSpecification spec :
    // workflow.getDataTransferSpecification()) {
    // String query = "\"DESCRIBE " + spec.getSourceDatabase() + "." +
    // spec.getSourceTable() + ";\"";
    //
    // List<String> resultList = this.hiveDumpService.runHiveQuery(query);
    //
    // boolean partitionInfoFound = false;
    // for (String rl : resultList) {
    // if (rl == null || rl.trim().isEmpty()) {
    // continue;
    // }
    // String line = rl.trim();
    // if ("# Partition Information".equals(line)) {
    // partitionInfoFound = true;
    // }
    // if (!partitionInfoFound || line.startsWith("#")) {
    // continue;
    // }
    // // Partition information: first column is the partition name
    // String partitionName = line.split(" ")[0];
    // logger.info("Partition name found for table " +
    // spec.getDestinationDatabase() + "."
    // + spec.getDestinationTable() + ": " + partitionName);
    // spec.setSourceTablePartitionName(partitionName);
    // }
    // }
    // }
}
