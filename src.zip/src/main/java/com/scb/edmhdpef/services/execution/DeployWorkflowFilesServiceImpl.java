package com.scb.edmhdpef.services.execution;

import com.scb.edmhdpef.EdmhdpefCommon;
import com.scb.edmhdpef.EdmhdpefConstants;
import com.scb.edmhdpef.entity.EdmWorkflow;
import com.scb.edmhdpef.enums.EdmDataSourceTypeEnum;
import com.scb.edmhdpef.exceptions.EdmHdpEfAppException;
import com.scb.edmhdpef.exceptions.EdmHdpEfInternalException;
import com.scb.edmhdpef.exceptions.EdmHdpEfInternalException.InternalExceptionCode;
import com.scb.edmhdpef.exceptions.EdmHdpEfNotImplementedException;
import com.scb.edmhdpef.services.datasourcemng.DataSourceManagement;
import com.scb.edmhdpef.services.datasourcemng.DataSourceManagementSelector;
import org.apache.commons.io.IOUtils;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.*;
import org.apache.hadoop.fs.permission.FsPermission;
import org.apache.hadoop.security.UserGroupInformation;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

import javax.annotation.Resource;
import javax.xml.bind.JAXBException;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.*;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.IOException;
import java.io.StringWriter;
import java.security.PrivilegedExceptionAction;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

@Service("deployWorkflowFilesService")
public class DeployWorkflowFilesServiceImpl implements DeployWorkflowFilesService {

    private static final Logger logger = Logger.getLogger(DeployWorkflowFilesServiceImpl.class);

    @Value("${oozie.workflow.path}")
    private String oozieWorkflowPath;

    @Value("${fs.defaultFS}")
    private String hadoopDefaultFS;

    @Value("${dfs.client.use.datanode.hostname}")
    private String dfsClientUseHostname;

    @Value("${edmhdpef.data.processing.jar.file}")
    private String dataProcessingJarFile;


    @Resource
    private DataSourceManagementSelector dataSourceManagementSelector;

    @Resource
    private DataProcessingService dataProcessingService;

    @Override
    public Map<String, String> getWorkFlowAndScripts(EdmWorkflow workflow)
            throws EdmHdpEfAppException, EdmHdpEfInternalException, EdmHdpEfNotImplementedException {

        EdmhdpefCommon.validateWorkflowForDeployment(workflow);

        HashMap<String, String> files = new HashMap<String, String>();
        // Create workflow.xml
        DocumentBuilder docBuilder = createWorkflow();

        // root elements
        logger.info("Creating workflow.xml");
        Document doc = docBuilder.newDocument();
        Element workflowapp = prepareWorkflowRoot(workflow, doc);
        doc.appendChild(workflowapp);

        /*
         * Global section
         */
        prepareGlobalConfig(doc, workflowapp);

        // Actions
        prepareActions(workflow, doc, workflowapp);

        // Source
        prepareSource(workflow, files, doc, workflowapp);

        // Data processing
        prepareDataProcessing(workflow, files, doc, workflowapp);

        // Destination
        prepareDestination(workflow, files, doc, workflowapp);

        // Add kill and end
        addKillAndEnd(doc, workflowapp);

        // get the workflow.xml content
        StringWriter writer = getWorkflowContents(doc);
        String workflowXml = writer.toString();
        files.put("workflow.xml", workflowXml);
        try {
            // Dump workflow definition in a file
            String workflow_definition = EdmhdpefCommon.toXML(workflow);
            files.put("workflow_definition.xml", workflow_definition);
        } catch (JAXBException e) {
            logger.error(e);
            throw new EdmHdpEfInternalException(InternalExceptionCode.ERROR_CREATING_CONFIG_FILES,
                    "Error generating workflow files. Error creating workflow dump XML document: " + e.getMessage(), e);
        }

        return files;
    }


    /**
     * Fetch workflow xml contents from DOM tree via xml transformer
     *
     * @param doc DOM doc tree
     * @return StringWriter as transformed xml
     * @throws EdmHdpEfInternalException
     */
    private StringWriter getWorkflowContents(Document doc) throws EdmHdpEfInternalException {
        TransformerFactory transformerFactory = TransformerFactory.newInstance();
        Transformer transformer;
        try {
            transformer = transformerFactory.newTransformer();
        } catch (TransformerConfigurationException e) {
            logger.error(e);
            throw new EdmHdpEfInternalException(InternalExceptionCode.ERROR_CREATING_CONFIG_FILES,
                    "Error generating workflow files. Error creating XML transformer: " + e.getMessage(), e);
        }
        transformer.setOutputProperty(OutputKeys.INDENT, "yes");

        DOMSource source = new DOMSource(doc);
        StringWriter writer = new StringWriter();
        StreamResult result = new StreamResult(writer);

        try {
            transformer.transform(source, result);
        } catch (TransformerException e) {
            logger.error(e);
            throw new EdmHdpEfInternalException(InternalExceptionCode.ERROR_CREATING_CONFIG_FILES,
                    "Error generating workflow files. Error creating XML document: " + e.getMessage(), e);
        }
        return writer;
    }

    /**
     * Appendd kill and end elements to workflow xml
     *
     * @param doc         Workflow XML DOM
     * @param workflowapp the app element to append to
     */
    private void addKillAndEnd(Document doc, Element workflowapp) {
        Element kill = doc.createElement("kill");
        kill.setAttribute("name", "fail");
        Element killMessage = doc.createElement("message");
        killMessage.setTextContent("Java failed, error message[${wf:errorMessage(wf:lastErrorNode())}]");
        kill.appendChild(killMessage);
        Element end = doc.createElement("end");
        end.setAttribute("name", "end");
        workflowapp.appendChild(kill);
        workflowapp.appendChild(end);
    }

    /**
     * Prepare destination
     *
     * @param workflow    workflow
     * @param files       files to append to the xml
     * @param doc         DOM tree of workflow
     * @param workflowapp the app element to append to
     * @throws EdmHdpEfNotImplementedException
     * @throws EdmHdpEfAppException
     * @throws EdmHdpEfInternalException
     */
    private void prepareDestination(EdmWorkflow workflow, HashMap<String, String> files, Document doc, Element workflowapp) throws EdmHdpEfNotImplementedException, EdmHdpEfAppException, EdmHdpEfInternalException {
        logger.info("Destination type is:" + workflow.getDestination().getType());
        DataSourceManagement destinationDeploy = this.dataSourceManagementSelector
                .getDataSourceManagement(workflow.getDestination());

        logger.info("Creating destination actions");
        List<Element> destinationTypeList = destinationDeploy.getDeployDstActions(doc, workflow);

        logger.info("Creating destination scripts");
        files.putAll(destinationDeploy.getDeployDstScripts(workflow));

        for (Element actionDestination : destinationTypeList) {
            workflowapp.appendChild(actionDestination);
        }
    }

    /**
     * Data processing phase of a workflow is appended
     *
     * @param workflow    the workflow
     * @param files       files to be appended to the workflow
     * @param doc         DOM tree of workflow
     * @param workflowapp Workflow app element to append to
     * @throws EdmHdpEfAppException
     * @throws EdmHdpEfInternalException
     * @throws EdmHdpEfNotImplementedException
     */
    private void prepareDataProcessing(EdmWorkflow workflow, HashMap<String, String> files, Document doc, Element workflowapp) throws EdmHdpEfAppException, EdmHdpEfInternalException, EdmHdpEfNotImplementedException {
        if (workflow.getProcessing() != null && !workflow.getProcessing().isEmpty()) {
            logger.info("Creating Data Processing actions");
            List<Element> actionProcessingList = this.dataProcessingService.getDeployProcessingActions(doc, workflow);
            for (Element actionProcessing : actionProcessingList) {
                workflowapp.appendChild(actionProcessing);
            }
            files.put(dataProcessingJarFile, "");
        }
    }

    /**
     * Source data configurations being dentionally translated to oozie xml semantics
     *
     * @param workflow    the workflow
     * @param files       files to be appended to xml config
     * @param doc         DOM tree of workflow
     * @param workflowapp workflow app element
     * @throws EdmHdpEfNotImplementedException
     * @throws EdmHdpEfAppException
     * @throws EdmHdpEfInternalException
     */
    private void prepareSource(EdmWorkflow workflow, HashMap<String, String> files, Document doc, Element workflowapp) throws EdmHdpEfNotImplementedException, EdmHdpEfAppException, EdmHdpEfInternalException {
        logger.info("Source type is:" + workflow.getSource().getType());
        DataSourceManagement sourceDeploy = this.dataSourceManagementSelector
                .getDataSourceManagement(workflow.getSource());

        logger.info("Creating source action");
        List<Element> actionTypeList = sourceDeploy.getDeploySrcActions(doc, workflow);
        for (Element actionSource : actionTypeList) {
            workflowapp.appendChild(actionSource);
        }

        logger.info("Creating source scripts");
        files.putAll(sourceDeploy.getDeploySrcScripts(workflow));
    }

    /**
     * Action element appended to the DOM
     *
     * @param workflow    workflow
     * @param doc         DOM
     * @param workflowapp app element to append to
     */
    private void prepareActions(EdmWorkflow workflow, Document doc, Element workflowapp) {
        Element start = doc.createElement("start");
        start.setAttribute("to", EdmhdpefCommon.getSourceActionName(workflow));
        workflowapp.appendChild(start);
    }

    /**
     * Global workflow confis is prepared here
     *
     * @param doc
     * @param workflowapp
     */
    private void prepareGlobalConfig(Document doc, Element workflowapp) {
        Element global = doc.createElement("global");
        Element jobTracker = doc.createElement("job-tracker");
        jobTracker.setTextContent("${jobTracker}");
        Element nameNode = doc.createElement("name-node");
        nameNode.setTextContent("${nameNode}");
        // Config
        Element globalConfig = doc.createElement("configuration");
        globalConfig.appendChild(createConfigProperty(doc, "mapred.job.queue.name", "${queueName}"));
        // Compression
        globalConfig.appendChild(createConfigProperty(doc, "mapreduce.compress.map.output", "true"));
        globalConfig.appendChild(createConfigProperty(doc, "mapreduce.map.output.compression.codec",
                "org.apache.hadoop.io.compress.GzipCodec"));
        globalConfig.appendChild(createConfigProperty(doc, "mapreduce.output.compress", "true"));
        globalConfig.appendChild(createConfigProperty(doc, "mapreduce.output.compression.codec",
                "org.apache.hadoop.io.compress.GzipCodec"));

        global.appendChild(jobTracker);
        global.appendChild(nameNode);
        global.appendChild(globalConfig);
        workflowapp.appendChild(global);
    }

    /**
     * Prepare workflow root
     *
     * @param workflow
     * @param doc
     * @return
     */
    private Element prepareWorkflowRoot(EdmWorkflow workflow, Document doc) {
        Element workflowapp = doc.createElement("workflow-app");
        workflowapp.setAttribute("xmlns", "uri:oozie:workflow:0.5");
        workflowapp.setAttribute("name", "EdmHdpEf-" + workflow.getName() + "-" + workflow.getType());
        return workflowapp;
    }

    /**
     * Prepare DOM
     *
     * @return
     * @throws EdmHdpEfInternalException
     */
    private DocumentBuilder createWorkflow() throws EdmHdpEfInternalException {
        DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder docBuilder;
        try {
            docBuilder = docFactory.newDocumentBuilder();
        } catch (ParserConfigurationException e) {
            logger.error(e);
            throw new EdmHdpEfInternalException(InternalExceptionCode.ERROR_CREATING_CONFIG_FILES,
                    "Error generating workflow files. Error creating document builder: " + e.getMessage(), e);
        }
        return docBuilder;
    }

    private Node createConfigProperty(Document doc, String name, String value) {
        Element configProperty = doc.createElement("property");
        Element configPropertyName = doc.createElement("name");
        configPropertyName.setTextContent(name);
        Element configPropertyValue = doc.createElement("value");
        configPropertyValue.setTextContent(value);
        configProperty.appendChild(configPropertyName);
        configProperty.appendChild(configPropertyValue);

        return configProperty;
    }

    @Override
    public void writeWorkFlowAndScripts(final EdmWorkflow workflow, final Map<String, String> files)
            throws EdmHdpEfAppException, EdmHdpEfInternalException, EdmHdpEfNotImplementedException {
        final Path workflowPath = new Path(oozieWorkflowPath + "/" + workflow.getName() + "/");
        if (hadoopDefaultFS == null) {
            throw new EdmHdpEfInternalException(InternalExceptionCode.HDFS_ERROR,
                    "fs.defaultFS parameter is not set in the configuration.");
        }
        try {
            final Configuration config = new Configuration();
            logger.info(config);
            config.set(CommonConfigurationKeys.FS_DEFAULT_NAME_KEY, hadoopDefaultFS);
            if (dfsClientUseHostname != null) {
                config.set("dfs.client.use.datanode.hostname", dfsClientUseHostname);
            }
            UserGroupInformation ugi = UserGroupInformation.createRemoteUser(EdmhdpefCommon.getUser());

            ugi.doAs(new PrepareConfigFiles(config, workflowPath, files, workflow));

        } catch (Exception e) {
            logger.error(e);
            throw new EdmHdpEfInternalException(InternalExceptionCode.ERROR_CREATING_CONFIG_FILES,
                    "Error writing workflow files: " + e.getMessage(), e);
        }

    }

    private void copyHDFSFile(FileSystem fs, String src, String dst, FsPermission permission) throws IOException {

        if (permission == null) {
            permission = FsPermission.getFileDefault();
        }
        // Read src file
        FSDataInputStream fin = fs.open(new Path(src));
        // Write to dst HDFS
        Path dstPath = new Path(dst);
        fs.mkdirs(dstPath.getParent());
        FSDataOutputStream fout = fs.create(dstPath, true);
        IOUtils.copy(fin, fout);
        fin.close();
        fout.close();
        fs.setPermission(dstPath, permission);

        logger.info("Copied file " + src + " to " + dst);
    }

    private class PrepareConfigFiles implements PrivilegedExceptionAction<Void> {
        private final Configuration config;
        private final Path workflowPath;
        private final Map<String, String> files;
        private final EdmWorkflow workflow;

        public PrepareConfigFiles(Configuration config, Path workflowPath, Map<String, String> files, EdmWorkflow workflow) {
            this.config = config;
            this.workflowPath = workflowPath;
            this.files = files;
            this.workflow = workflow;
        }

        public Void run() throws Exception {
            FileSystem fs = FileSystem.get(config);
            if (fs.exists(workflowPath)) {
                fs.delete(workflowPath, true);
            }
            FsPermission directoryPermission = FsPermission.valueOf("-rwx------");
            FsPermission filePermission = FsPermission.valueOf("-rw-------");
            for (Entry<String, String> entry : files.entrySet()) {
                Path filenamePath = new Path(workflowPath + "/" + entry.getKey());
                logger.info("Copying file " + entry.getKey() + " to " + filenamePath);

                fs.mkdirs(filenamePath.getParent(), directoryPermission);

                if (entry.getValue().trim().isEmpty()) {
                    // JDBCShell special file
                    fs.copyFromLocalFile(new Path(entry.getKey()), filenamePath);
                } else {
                    FSDataOutputStream fout = fs.create(filenamePath, true);
                    IOUtils.write(entry.getValue(), fout);
                    fout.close();
                }
                fs.setPermission(filenamePath, filePermission);
            }
            // Hive files
            if (EdmDataSourceTypeEnum.HIVE.equals(workflow.getSource().getType())
                    || EdmDataSourceTypeEnum.HIVE.equals(workflow.getDestination().getType())) {
                String sourceHiveSiteFile = workflow.getSource().getParameters()
                        .get(EdmhdpefConstants.DS_PARAM_HIVE_HIVESITEFILE);
                if (sourceHiveSiteFile != null) {

                    copyHDFSFile(fs, sourceHiveSiteFile, workflowPath + "/conf/hive-site.xml", filePermission);
                }
                String sourceTezSiteFile = workflow.getSource().getParameters()
                        .get(EdmhdpefConstants.DS_PARAM_HIVE_TEZSITEFILE);
                if (sourceTezSiteFile != null) {
                    copyHDFSFile(fs, sourceTezSiteFile, workflowPath + "/conf/tez-site.xml", filePermission);
                }
            }
            return null;
        }
    }
}
