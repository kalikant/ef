package com.scb.edmhdpef.services.execution;

import java.security.PrivilegedExceptionAction;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;

import javax.annotation.Resource;

import org.apache.hadoop.security.UserGroupInformation;
import org.apache.log4j.Logger;
import org.apache.oozie.client.OozieClient;
import org.apache.oozie.client.OozieClientException;
import org.apache.oozie.client.WorkflowJob;
import org.apache.oozie.client.WorkflowJob.Status;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.scb.edmhdpef.EdmhdpefCommon;
import com.scb.edmhdpef.entity.EdmWorkflow;
import com.scb.edmhdpef.entity.WorkflowExecution;
import com.scb.edmhdpef.exceptions.EdmHdpEfAppException;
import com.scb.edmhdpef.exceptions.EdmHdpEfAppException.AppExceptionCode;
import com.scb.edmhdpef.exceptions.EdmHdpEfInternalException;
import com.scb.edmhdpef.exceptions.EdmHdpEfInternalException.InternalExceptionCode;
import com.scb.edmhdpef.exceptions.EdmHdpEfNotImplementedException;
import com.scb.edmhdpef.services.architecture.security.EncryptionService;
import com.scb.edmhdpef.services.database.DataAccessService;
import com.scb.edmhdpef.vo.DeployWorkflowVO;

@Service("executionService")
public class ExecutionServiceImpl implements ExecutionService {

    private static final Logger logger = Logger.getLogger(ExecutionServiceImpl.class);

    @Value("${oozie.url}")
    private String oozieURL;

    @Value("${oozie.workflow.path}")
    private String oozieWorkflowPath;

    @Value("${oozie.user.name}")
    private String oozieUserName;

    @Value("${oozie.queueName}")
    private String oozieQueueName;

    @Value("${oozie.nameNode}")
    private String oozieNameNode;

    @Value("${oozie.jobTracker}")
    private String oozieJobTracker;

    @Value("${fs.defaultFS}")
    private String hadoopDefaultFS;

    @Resource
    private DataAccessService dataAccessService;

    @Resource
    private DeployWorkflowFilesService deployWorkflowFilesService;

    @Resource
    private EncryptionService encryptionService;

    private static final SimpleDateFormat hourDateFormat = new SimpleDateFormat("yyyyMMddHH");

    @Override
    public Map<String, String> deployWorkflow(DeployWorkflowVO deployWorkflowVO) throws EdmHdpEfAppException,
            EdmHdpEfInternalException, EdmHdpEfNotImplementedException {

        if (deployWorkflowVO.getWorkflowName() == null || deployWorkflowVO.getWorkflowName().trim().isEmpty()) {
            throw new EdmHdpEfAppException(AppExceptionCode.PARAMETER_NOT_SPECIFIED, "Workflow name not provided.");
        }

        // Retrieve workflow
        EdmWorkflow workflow = (EdmWorkflow) this.dataAccessService.retrieveById(EdmWorkflow.class,
                deployWorkflowVO.getWorkflowName());

        if (workflow == null) {
            throw new EdmHdpEfAppException(AppExceptionCode.ENTITY_NOT_EXISTS, "Workflow "
                    + deployWorkflowVO.getWorkflowName() + " does not exist.");
        }

        // Create workflow.xml and script files
        Map<String, String> files;
        if (Boolean.TRUE.equals(deployWorkflowVO.getCreateFilesInHDFS())) {
            files = this.deployWorkflowFilesService.getWorkFlowAndScripts(workflow);
            this.deployWorkflowFilesService.writeWorkFlowAndScripts(workflow, files);
        } else {
            files = this.deployWorkflowFilesService.getWorkFlowAndScripts(workflow);
        }

        return files;
    }

    @Override
    public WorkflowExecution runWorkflow(final WorkflowExecution runWorkflow) throws EdmHdpEfAppException,
            EdmHdpEfInternalException {
        if (runWorkflow == null || runWorkflow.getWorkflow() == null || runWorkflow.getWorkflow().getName() == null
                || runWorkflow.getWorkflow().getName().trim().isEmpty()) {
            throw new EdmHdpEfAppException(AppExceptionCode.PARAMETER_NOT_SPECIFIED, "Workflow name not provided.");
        }
        if (runWorkflow.getParameters() == null) {
            throw new EdmHdpEfAppException(AppExceptionCode.PARAMETER_NOT_SPECIFIED,
                    "Workflow run parameters not provided.");
        }
        final EdmWorkflow workflow = (EdmWorkflow) this.dataAccessService.retrieveById(runWorkflow.getWorkflow()
                .getClass(), runWorkflow.getWorkflow().getName());

        if (workflow == null) {
            throw new EdmHdpEfAppException(AppExceptionCode.ENTITY_NOT_EXISTS, "Workflow "
                    + runWorkflow.getWorkflow().getName() + " does not exist.");
        }

        runWorkflow.setWorkflow(workflow);

        // Add execution hour and timestamp parameters
        Calendar executionTime = Calendar.getInstance();
        runWorkflow.getParameters().put("exec_timestamp", String.valueOf(executionTime.getTimeInMillis()));
        runWorkflow.getParameters().put("exec_datehour", hourDateFormat.format(executionTime.getTime()));

        // Check required parameters
        if (workflow.getParameters() != null) {
            List<String> missingParameters = new ArrayList<String>();
            for (String parameter : workflow.getParameters()) {
                if (runWorkflow.getParameters() == null || runWorkflow.getParameters().get(parameter) == null) {
                    missingParameters.add(parameter);
                }
            }
            if (!missingParameters.isEmpty()) {
                StringBuilder message = new StringBuilder("Cannot run WorkFlow. Missing parameters:");
                for (String parameter : missingParameters) {
                    message.append('\n').append(parameter);
                }
                throw new EdmHdpEfAppException(AppExceptionCode.PARAMETER_NOT_SPECIFIED, message.toString());
            }
        }

        // Contact oozie to send workflow
        runWorkflow.setWorkflow(workflow);
        runWorkflow.setJobId(null);
        runWorkflow.setExecutionDate(new Date());
        UserGroupInformation ugi = UserGroupInformation.createRemoteUser(EdmhdpefCommon.getUser());

        String jobId = null;
        try {
            final OozieClient ozClient = new OozieClient(oozieURL);
            jobId = ugi.doAs(new PrivilegedExceptionAction<String>() {
                public String run() throws Exception {
                    return ozClient.run(getProperties(workflow, runWorkflow.getParameters()));
                }
            });
        } catch (Exception e) {
            logger.error(e);
            e.printStackTrace();
            throw new EdmHdpEfInternalException(InternalExceptionCode.OOZIE_ERROR, "Error running the Oozie job: "
                    + e.getMessage(), e);
        }
        runWorkflow.setJobId(jobId);
        // Encrypt parameters
        runWorkflow.setParameters(encryptionService.encryptParameters(runWorkflow.getParameters()));
        this.dataAccessService.saveOrUpdateObject(runWorkflow);

        return queryStatus(runWorkflow).get(0);
    }

    @Override
    public List<WorkflowExecution> queryStatus(WorkflowExecution status) throws EdmHdpEfAppException,
            EdmHdpEfInternalException {

        if (status == null
                || (status.getJobId() == null && (status.getWorkflow() == null || status.getWorkflow().getName() == null))) {
            throw new EdmHdpEfAppException(AppExceptionCode.PARAMETER_NOT_SPECIFIED,
                    "Job Id or Workflow Name not provided.");
        }
        List<WorkflowExecution> workflowExecutionList = new ArrayList<WorkflowExecution>();
        if (status.getJobId() != null) {
            WorkflowExecution workflow = (WorkflowExecution) this.dataAccessService.retrieveById(
                    WorkflowExecution.class, status.getJobId());
            workflowExecutionList.add(workflow);
        } else {
            workflowExecutionList = this.dataAccessService.retrieveWorkflowExecutionByWorkflowName(status.getWorkflow()
                    .getName());
        }

        for (WorkflowExecution workflow : workflowExecutionList) {
            if (workflow == null) {
                continue;
            }
            if (!isFinished(workflow.getStatus())) {
                // Contact Oozie to query status
                Status ooziestatus = null;
                try {
                    final OozieClient ozClient = new OozieClient(oozieURL);
                    WorkflowJob workflowjob = ozClient.getJobInfo(workflow.getJobId());
                    ooziestatus = workflowjob.getStatus();
                } catch (OozieClientException e) {
                    logger.error(e);
                    if (!"E0604".equals(e.getErrorCode())) {
                        // E0604 means jobid has been deleted
                        throw new EdmHdpEfInternalException(InternalExceptionCode.OOZIE_ERROR,
                                "Error retrieving data from Oozie: " + e.getMessage(), e);
                    }
                }
                if (ooziestatus != null && !ooziestatus.equals(workflow.getStatus())) {
                    workflow.setStatus(ooziestatus);
                    workflow = (WorkflowExecution) this.dataAccessService.saveOrUpdateObject(workflow);
                }
            }
        }

        return workflowExecutionList;
    }

    private Properties getProperties(EdmWorkflow workflow, Map<String, String> parameters) throws EdmHdpEfAppException {
        Properties properties = new Properties();
        properties.put(OozieClient.APP_PATH, oozieWorkflowPath + "/" + workflow.getName());
        properties.put(OozieClient.USER_NAME, oozieUserName);
        properties.put(OozieClient.USE_SYSTEM_LIBPATH, "true");
        properties.put("queueName", oozieQueueName);
        properties.put("nameNode", oozieNameNode);
        properties.put("jobTracker", oozieJobTracker);

        // Set user to logged in user
        properties.put(OozieClient.USER_NAME, EdmhdpefCommon.getUser());

        // Runtime properties
        for (Entry<String, String> param : parameters.entrySet()) {
            properties.put(param.getKey(), param.getValue());
        }

        return properties;
    }

    private boolean isFinished(Status status) {
        return status != null && (status == Status.FAILED || status == Status.KILLED || status == Status.SUCCEEDED);
    }
}