package com.scb.edmhdpef.services.database;

import java.util.List;

import org.springframework.util.concurrent.ListenableFuture;

import com.scb.edmhdpef.exceptions.EdmHdpEfInternalException;

public interface HiveDumpService {

	ListenableFuture<Boolean> writeToHive(String type, Object obj) throws EdmHdpEfInternalException;

	List<String> runHiveQuery(String query) throws EdmHdpEfInternalException;
}
