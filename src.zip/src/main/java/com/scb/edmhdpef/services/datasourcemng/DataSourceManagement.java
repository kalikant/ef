package com.scb.edmhdpef.services.datasourcemng;

import java.util.List;
import java.util.Map;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.scb.edmhdpef.entity.EdmWorkflow;
import com.scb.edmhdpef.exceptions.EdmHdpEfAppException;
import com.scb.edmhdpef.exceptions.EdmHdpEfInternalException;
import com.scb.edmhdpef.exceptions.EdmHdpEfNotImplementedException;
import com.scb.edmhdpef.services.model.EdmhdpefProperty;

public interface DataSourceManagement {

	List<Element> getDeploySrcActions(Document doc, EdmWorkflow workflow)
			throws EdmHdpEfAppException, EdmHdpEfInternalException, EdmHdpEfNotImplementedException;

	List<Element> getDeployDstActions(Document doc, EdmWorkflow workflow)
			throws EdmHdpEfAppException, EdmHdpEfInternalException, EdmHdpEfNotImplementedException;

	Map<String, String> getDeploySrcScripts(EdmWorkflow workflow)
			throws EdmHdpEfInternalException, EdmHdpEfNotImplementedException;

	Map<String, String> getDeployDstScripts(EdmWorkflow workflow)
			throws EdmHdpEfAppException, EdmHdpEfInternalException, EdmHdpEfNotImplementedException;

	/**
	 * The parameters are the static values provided to the datasource, usually
	 * providing details about where to find and how to access to the
	 * datasource: host, port, username, password, etc
	 * 
	 * @return The list of parameters depending on the datasource type.
	 */
	List<EdmhdpefProperty> getParameters();

	void validateParameters(Map<String, String> parameters) throws EdmHdpEfAppException, EdmHdpEfInternalException;

	/**
	 * The options are defined in the workflow level, for the workflow source
	 * and destination. They usually indicates the behavior of the datasource
	 * for a particular
	 * 
	 * @return The list of options depending on the datasource type.
	 */
	List<EdmhdpefProperty> getOptions();

	void validateOptions(Map<String, String> sourceOptions) throws EdmHdpEfAppException, EdmHdpEfInternalException;
}
