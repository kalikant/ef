package com.scb.edmhdpef.services.architecture;

import java.util.HashMap;

import com.scb.edmhdpef.exceptions.EdmHdpEfInternalException;

public interface TemplateCreation {

	public String getTemplate(String templateName, HashMap<String, Object> dataModel) throws EdmHdpEfInternalException;
}
