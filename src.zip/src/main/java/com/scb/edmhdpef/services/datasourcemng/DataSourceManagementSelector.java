package com.scb.edmhdpef.services.datasourcemng;

import com.scb.edmhdpef.entity.EdmDataSource;
import com.scb.edmhdpef.exceptions.EdmHdpEfNotImplementedException;

public interface DataSourceManagementSelector {

	DataSourceManagement getDataSourceManagement(EdmDataSource dataSource) throws EdmHdpEfNotImplementedException;

}