package com.scb.edmhdpef.services.database;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.stereotype.Service;
import org.springframework.util.concurrent.ListenableFuture;

import com.google.common.io.Files;
import com.scb.edmhdpef.EdmhdpefCommon;
import com.scb.edmhdpef.entity.EdmDataSource;
import com.scb.edmhdpef.entity.EdmWorkflow;
import com.scb.edmhdpef.entity.WorkflowExecution;
import com.scb.edmhdpef.exceptions.EdmHdpEfInternalException;
import com.scb.edmhdpef.exceptions.EdmHdpEfInternalException.InternalExceptionCode;

@Service("hiveDumpService")
public class HiveDumpServiceImpl implements HiveDumpService {

    private Logger logger = LoggerFactory.getLogger(HiveDumpServiceImpl.class);

    @Value("${edmhdpef.hive.database}")
    private String edmhdpefDatabase;

    @Value("${hive.column.separator}")
    private String hiveColumnSeparator;

    @Async
    @Override
    public ListenableFuture<Boolean> writeToHive(String type, Object obj) throws EdmHdpEfInternalException {

        if (!obj.getClass().isAssignableFrom(EdmDataSource.class)
                && !obj.getClass().isAssignableFrom(EdmWorkflow.class)
                && !obj.getClass().isAssignableFrom(WorkflowExecution.class)) {
            return new AsyncResult<Boolean>(true);
        }

        try {
            String stringToWrite = type + hiveColumnSeparator + new Date() + hiveColumnSeparator
                    + EdmhdpefCommon.getUser() + hiveColumnSeparator + EdmhdpefCommon.toXML(obj, false);

            File tmpFile = File.createTempFile("hive", ".tmp");
            Files.write(stringToWrite.getBytes(), tmpFile);

            String command = "USE " + edmhdpefDatabase + ";LOAD DATA LOCAL INPATH '" + tmpFile
                    + "' INTO TABLE EntitiesLog;";

            this.runHiveQuery(command);
            tmpFile.delete();

            return new AsyncResult<Boolean>(true);
        } catch (Exception e) {
            logger.error("Error saving object to Hive: " + e.getMessage(), e);
            throw new EdmHdpEfInternalException(InternalExceptionCode.HIVE_ERROR, "Error saving object to Hive: "
                    + e.getMessage(), e);
        }
    }

    // @Override
    // public List<String> runHiveQuery(String query) throws
    // EdmHdpEfInternalException {
    // try {
    // Class.forName("org.apache.hive.jdbc.HiveDriver");
    // Connection con =
    // DriverManager.getConnection("jdbc:hive2://dg1355:10000/default");
    // Statement stmt = con.createStatement();
    //
    // ResultSet rs = stmt.executeQuery(query);
    //
    // int colCount = rs.getMetaData().getColumnCount();
    // List<String> resultList = new ArrayList<>();
    // while (rs.next()) {
    // StringBuilder line = new StringBuilder();
    // for (int i = 0; i < colCount; i++) {
    // if (i > 0) {
    // line.append('\t');
    // }
    // line.append(rs.getObject(i));
    // }
    // resultList.add(line.toString());
    // }
    //
    // return resultList;
    // } catch (SQLException | ClassNotFoundException e) {
    // logger.error("Error running query: " + query + ". Error: " +
    // e.toString(), e);
    // throw new EdmHdpEfInternalException(InternalExceptionCode.HIVE_ERROR,
    // e.toString());
    // }
    // }

    @Override
    public List<String> runHiveQuery(String query) throws EdmHdpEfInternalException {
        final List<String> command = new ArrayList<String>();
        command.add("hive");
        command.add("-S");
        command.add("-e");
        command.add(query);
        logger.info("Running query: " + query);
        try {
            final ProcessBuilder builder = new ProcessBuilder(command);
            builder.redirectOutput();
            builder.redirectError();

            // Start process and capture output
            final Process process = builder.start();

            StreamGetter errorStream = new StreamGetter(process.getErrorStream());
            StreamGetter outputStream = new StreamGetter(process.getInputStream());
            errorStream.start();
            outputStream.start();

            process.waitFor();

            List<String> errorList = errorStream.getResultList();
            if (errorList != null && errorList.size() != 0) {
                StringBuilder errorMsg = new StringBuilder();
                for (String e : errorList) {
                    errorMsg.append(e).append('\n');
                }
                logger.error("Error running query: " + errorMsg.toString());
                throw new EdmHdpEfInternalException(InternalExceptionCode.HIVE_ERROR, errorMsg.toString());
            }
            List<String> resultList = outputStream.getResultList();
            if (resultList == null) {
                resultList = new ArrayList<>();
            }
            return resultList;
        } catch (IOException | InterruptedException e1) {
            logger.error("Error running query: " + e1.toString(), e1);
            throw new EdmHdpEfInternalException(InternalExceptionCode.HIVE_ERROR, e1.toString());
        }
    }

    class StreamGetter extends Thread {
        InputStream is;
        List<String> resultList = null;

        StreamGetter(InputStream is) {
            this.is = is;
        }

        public void run() {
            try {
                resultList = IOUtils.readLines(is);
            } catch (IOException e) {
            }
        }

        public List<String> getResultList() {
            return resultList;
        }
    }
}
