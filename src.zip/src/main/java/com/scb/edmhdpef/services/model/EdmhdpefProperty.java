package com.scb.edmhdpef.services.model;

public final class EdmhdpefProperty {

	private String propertyName;
	private Boolean optional;
	private String defaultValue;
	private String comment;

	public EdmhdpefProperty(String propertyName, Boolean optional, String defaultValue, String comment) {
		super();
		this.propertyName = propertyName;
		this.optional = optional;
		this.defaultValue = defaultValue;
		this.comment = comment;
	}

	public String getPropertyName() {
		return propertyName;
	}

	public Boolean isOptional() {
		return optional;
	}

	public String getDefaultValue() {
		return defaultValue;
	}

	public String getComment() {
		return comment;
	}
}
