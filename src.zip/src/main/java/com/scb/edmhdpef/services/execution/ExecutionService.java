package com.scb.edmhdpef.services.execution;

import java.util.List;
import java.util.Map;

import com.scb.edmhdpef.entity.WorkflowExecution;
import com.scb.edmhdpef.exceptions.EdmHdpEfAppException;
import com.scb.edmhdpef.exceptions.EdmHdpEfInternalException;
import com.scb.edmhdpef.exceptions.EdmHdpEfNotImplementedException;
import com.scb.edmhdpef.vo.DeployWorkflowVO;

public interface ExecutionService {

	public Map<String, String> deployWorkflow(DeployWorkflowVO scheduleScriptVO)
			throws EdmHdpEfAppException, EdmHdpEfInternalException,
			EdmHdpEfNotImplementedException;

	public WorkflowExecution runWorkflow(WorkflowExecution runWorkflow)
			throws EdmHdpEfAppException, EdmHdpEfInternalException;

	public List<WorkflowExecution> queryStatus(WorkflowExecution status)
			throws EdmHdpEfAppException, EdmHdpEfInternalException;

}
