package com.scb.edmhdpef.services.configuration;

import java.util.List;

import com.scb.edmhdpef.entity.EdmWorkflow;
import com.scb.edmhdpef.exceptions.EdmHdpEfAppException;
import com.scb.edmhdpef.exceptions.EdmHdpEfInternalException;
import com.scb.edmhdpef.exceptions.EdmHdpEfNotImplementedException;

public interface WorkflowConfigService {

	public List<EdmWorkflow> retrieveWorkflows(EdmWorkflow criteria);

	public EdmWorkflow createWorkflow(EdmWorkflow workflow)
			throws EdmHdpEfAppException, EdmHdpEfInternalException,
			EdmHdpEfNotImplementedException;

	public void deleteWorkflow(EdmWorkflow workflow)
			throws EdmHdpEfAppException, EdmHdpEfInternalException;

	public EdmWorkflow updateWorkflow(EdmWorkflow workflow)
			throws EdmHdpEfAppException, EdmHdpEfInternalException,
			EdmHdpEfNotImplementedException;

}
