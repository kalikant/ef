package com.scb.edmhdpef.services.architecture.security;

import javax.annotation.Resource;

import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;

public class EFAuthenticationProvider implements AuthenticationProvider {

	@Resource
	private UserDetailsService userDetailsService;

	@Override
	public Authentication authenticate(Authentication authentication)
			throws AuthenticationException {
		UserDetails userDetails = this.userDetailsService
				.loadUserByUsername(authentication.getName());
		if (userDetails != null) {
			return new UsernamePasswordAuthenticationToken(userDetails, null,
					userDetails.getAuthorities());
		}

		throw new BadCredentialsException("Bad credentials");
	}

	@Override
	public boolean supports(Class<?> authentication) {
		return true;
	}

}
