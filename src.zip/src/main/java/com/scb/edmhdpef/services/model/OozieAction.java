package com.scb.edmhdpef.services.model;

import java.util.Map;
import java.util.Set;

import org.w3c.dom.Document;

import com.scb.edmhdpef.entity.EdmWorkflow;

public class OozieAction {

	private Document document;
	private EdmWorkflow workflow;
	private String actionName;
	private String actionDestination;
	private String fileName;
	private Boolean captureOutput;
	private Set<String> requiredFiles;
	private Set<String> jobXMLFiles;
	private Set<String> parameters;
	private Map<String, String> options;

	public EdmWorkflow getWorkflow() {
		return workflow;
	}

	public void setWorkflow(EdmWorkflow workflow) {
		this.workflow = workflow;
	}

	public String getActionName() {
		return actionName;
	}

	public void setActionName(String actionName) {
		this.actionName = actionName;
	}

	public String getActionDestination() {
		return actionDestination;
	}

	public void setActionDestination(String actionDestination) {
		this.actionDestination = actionDestination;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public Set<String> getRequiredFiles() {
		return requiredFiles;
	}

	public void setRequiredFiles(Set<String> requiredFiles) {
		this.requiredFiles = requiredFiles;
	}

	public Set<String> getJobXMLFiles() {
		return jobXMLFiles;
	}

	public void setJobXMLFiles(Set<String> jobXMLFiles) {
		this.jobXMLFiles = jobXMLFiles;
	}

	public Set<String> getParameters() {
		return parameters;
	}

	public void setParameters(Set<String> parameters) {
		this.parameters = parameters;
	}

	public Map<String, String> getOptions() {
		return options;
	}

	public void setOptions(Map<String, String> options) {
		this.options = options;
	}

	public Boolean getCaptureOutput() {
		return captureOutput;
	}

	public void setCaptureOutput(Boolean captureOutput) {
		this.captureOutput = captureOutput;
	}

	public Document getDocument() {
		return document;
	}

	public void setDocument(Document document) {
		this.document = document;
	}
}
