package com.scb.edmhdpef.services.database;

import java.io.Serializable;
import java.util.List;

import com.scb.edmhdpef.entity.WorkflowExecution;
import com.scb.edmhdpef.exceptions.EdmHdpEfInternalException;

public interface DataAccessService {

	public List<?> retrieveByCriteria(Object example);

	Object saveOrUpdateObject(Object obj) throws EdmHdpEfInternalException;

	void deleteObject(Object obj) throws EdmHdpEfInternalException;

	public Object retrieveById(Class<?> cls, Serializable id);

	public List<WorkflowExecution> retrieveWorkflowExecutionByWorkflowName(String name);
}
