package com.scb.edmhdpef.services.datasourcemng;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.scb.edmhdpef.EdmhdpefCommon;
import com.scb.edmhdpef.EdmhdpefConstants;
import com.scb.edmhdpef.entity.DataTransferSpecification;
import com.scb.edmhdpef.entity.EdmWorkflow;
import com.scb.edmhdpef.enums.EdmWorkflowTypeEnum;
import com.scb.edmhdpef.exceptions.EdmHdpEfAppException;
import com.scb.edmhdpef.exceptions.EdmHdpEfInternalException;
import com.scb.edmhdpef.exceptions.EdmHdpEfInternalException.InternalExceptionCode;
import com.scb.edmhdpef.exceptions.EdmHdpEfNotImplementedException;
import com.scb.edmhdpef.exceptions.EdmHdpEfNotImplementedException.NotImplementedExceptionCode;
import com.scb.edmhdpef.services.architecture.TemplateCreation;
import com.scb.edmhdpef.services.architecture.security.EncryptionService;
import com.scb.edmhdpef.services.model.EdmhdpefProperty;
import com.scb.edmhdpef.services.model.OozieAction;

@Service("hdfsManagement")
public class HDFSManagement implements DataSourceManagement {

    private static final String DS_OPTION_HDFS_NAMENODE = "namenode";

    @Resource
    private EncryptionService encryptionService;

    @Resource
    private TemplateCreation templateCreation;

    @Resource
    private OozieActionBuilder oozieActionBuilder;

    @Value("${edmhdpef.data.processing.jar.file}")
    private String dataProcessingJar;

    @Value("${edmhdpef.hive.database}")
    private String hiveDatabase;

    @Value("${hive.tmp.database}")
    private String tmpDatabase;

    @Value("${hive.tmp.directory}")
    private String tmpDirectory;

    @Value("${fs.defaultFS}")
    private String defaultFS;

    @Override
    public List<Element> getDeploySrcActions(Document doc, EdmWorkflow workflow) throws EdmHdpEfAppException,
            EdmHdpEfInternalException, EdmHdpEfNotImplementedException {
        throw new EdmHdpEfNotImplementedException(NotImplementedExceptionCode.NOT_IMPLEMENTED, "Not implemented");
    }

    @Override
    public List<Element> getDeployDstActions(Document doc, EdmWorkflow workflow) throws EdmHdpEfAppException,
            EdmHdpEfInternalException, EdmHdpEfNotImplementedException {

        EdmhdpefCommon.validateWorkflowForDeployment(workflow);

        if (doc == null) {
            throw new EdmHdpEfInternalException(InternalExceptionCode.ERROR_CREATING_CONFIG_FILES);
        }

        HashMap<String, String> options = new HashMap<String, String>();
        // Default options
        for (EdmhdpefProperty property : getOptions()) {
            options.put(property.getPropertyName(), property.getDefaultValue());
        }
        // Workflow options
        if (workflow.getDestinationOptions() != null) {
            options.putAll(workflow.getDestinationOptions());
        }
        options.put("tmpDirectory", tmpDirectory);
        options.put("tmpDatabase", tmpDatabase);
        options.put("exec_timestamp", "${exec_timestamp}");
        options.put("exec_datehour", "${exec_datehour}");

        // Tmp table
        String tmpTable = "edmhdpef_" + workflow.getName() + "_${wf:actionData('"
                + EdmhdpefCommon.getSourceActionName(workflow) + "')['"
                + EdmhdpefConstants.SPEC_PARAM_MAX_PARTITION_BDAY + "']}";
        if (workflow.getProcessing() != null && !workflow.getProcessing().isEmpty()) {
            tmpTable = tmpTable + "_" + workflow.getProcessing().size();
        }
        options.put("tmptable", tmpTable);

        // Parameters to get business day
        if (EdmhdpefCommon.isBusinessDayRequired(workflow)) {
            // Add max business day
            options.put("MAX_BUSINESS_DAY", "${wf:actionData('" + EdmhdpefCommon.getSourceActionName(workflow) + "')['"
                    + EdmhdpefConstants.SPEC_PARAM_MAX_PARTITION_BDAY + "']}");
        }

        // Action FS
        OozieAction hdfsAction = new OozieAction();
        hdfsAction.setActionDestination("end");
        hdfsAction.setActionName(EdmhdpefCommon.getDestinationActionName(workflow));
        hdfsAction.setCaptureOutput(true);
        hdfsAction.setDocument(doc);
        hdfsAction.setOptions(options);
        hdfsAction.setParameters(workflow.getParameters());
        hdfsAction.setRequiredFiles(this.getDeployDstScripts(workflow).keySet());
        hdfsAction.setWorkflow(workflow);

        List<Element> elementList = new ArrayList<Element>();

        switch (workflow.getType()) {
        case GENERIC:
            elementList.add(this.oozieActionBuilder.createOozieFsAction(hdfsAction));
            break;
        case TABLE_GROUP:
            options.put("inputPath", tmpDirectory + "/" + tmpTable);
            options.put("outputPath", tmpDirectory + "/" + tmpTable + ".out");

            // Output from previous steps
            if (workflow.getProcessing() != null) {
                for (int count = 0; count < workflow.getProcessing().size(); count++) {
                    options.put("proctable_" + (count + 1), EdmhdpefCommon.getDataProcessingActionName(workflow, count));
                    options.put("proccount_" + (count + 1),
                            "${wf:actionData('" + EdmhdpefCommon.getDataProcessingActionName(workflow, count)
                                    + "')['OutputRecords']}");
                }
            }

            // Tables output
            int count = 1;
            for (DataTransferSpecification spec : workflow.getDataTransferSpecification()) {
                String output = spec.getDestinationDatabase() + "/" + spec.getDestinationTable();
                options.put("outputtable_" + count, output);
                options.put(
                        "outputcount_" + count,
                        "${wf:actionData('" + EdmhdpefCommon.getDestinationActionName(workflow) + "')['"
                                + output.replaceAll("\\/", "") + "']}");
                count++;
            }

            hdfsAction.setFileName("com.scb.edmhdpef.hdfs.HDFSOutputSplit");
            elementList.add(this.oozieActionBuilder.createOozieJavaAction(hdfsAction));
            break;
        }
        return elementList;

    }

    @Override
    public Map<String, String> getDeploySrcScripts(EdmWorkflow workflow) throws EdmHdpEfInternalException,
            EdmHdpEfNotImplementedException {
        throw new EdmHdpEfNotImplementedException(NotImplementedExceptionCode.NOT_IMPLEMENTED, "Not implemented");
    }

    @Override
    public Map<String, String> getDeployDstScripts(EdmWorkflow workflow) throws EdmHdpEfAppException,
            EdmHdpEfInternalException, EdmHdpEfNotImplementedException {
        EdmhdpefCommon.validateWorkflowForDeployment(workflow);

        Map<String, String> destinationFiles = new HashMap<String, String>();

        if (EdmWorkflowTypeEnum.TABLE_GROUP.equals(workflow.getType())) {
            destinationFiles.put(dataProcessingJar, "");

            // Rowcounts destination
            HashMap<String, Object> model = new HashMap<>();
            model.put("workflowName", workflow.getName());
            model.put("sourceType", workflow.getDestination().getType());
            model.put("dataTransferSpecs", workflow.getDataTransferSpecification());
            model.put("wfparams", workflow.getParameters());
            model.put("MAX_BUSINESS_DAY", "MAX_BUSINESS_DAY");
            model.put("tmpDatabase", tmpDatabase);
            model.put("tmpDirectory", tmpDirectory);
            model.put("hiveDatabase", hiveDatabase);
            model.put("shell_username", EdmhdpefCommon.getUser());

            model.put("numprocessing", workflow.getProcessing() == null ? 0 : workflow.getProcessing().size());
            model.put("numoutput", workflow.getDataTransferSpecification().size());
            model.put("bdayRequired", EdmhdpefCommon.isBusinessDayRequired(workflow));

            destinationFiles.put(workflow.getName() + "-dst.sh",
                    this.templateCreation.getTemplate("hdfs/workflow-dst.sh", model));

        }

        return destinationFiles;
    }

    @Override
    public List<EdmhdpefProperty> getParameters() {
        List<EdmhdpefProperty> returnList = new ArrayList<EdmhdpefProperty>();

        return returnList;
    }

    @Override
    public void validateParameters(Map<String, String> parameters) throws EdmHdpEfAppException,
            EdmHdpEfInternalException {
        // Nothing to validate
    }

    @Override
    public List<EdmhdpefProperty> getOptions() {
        List<EdmhdpefProperty> returnList = new ArrayList<EdmhdpefProperty>();

        returnList.add(new EdmhdpefProperty(DS_OPTION_HDFS_NAMENODE, true, defaultFS, "Name node to use"));

        return returnList;
    }

    @Override
    public void validateOptions(Map<String, String> sourceOptions) throws EdmHdpEfAppException,
            EdmHdpEfInternalException {

    }

}
