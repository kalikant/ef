package com.scb.edmhdpef.services.datasourcemng;

import java.util.Map.Entry;

import org.springframework.stereotype.Service;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.scb.edmhdpef.EdmhdpefCommon;
import com.scb.edmhdpef.EdmhdpefConstants;
import com.scb.edmhdpef.entity.DataTransferSpecification;
import com.scb.edmhdpef.services.model.OozieAction;

@Service("oozieActionBuilder")
public class OozieActionBuilderImpl implements OozieActionBuilder {

	@Override
	public Element createOozieShellAction(OozieAction action) {

		Document doc = action.getDocument();

		Element oozieShellAction = doc.createElement("action");
		oozieShellAction.setAttribute("name", action.getActionName());

		Element shellAction = doc.createElement("shell");
		shellAction.setAttribute("xmlns", "uri:oozie:shell-action:0.3");

		Element exec = doc.createElement("exec");
		exec.setTextContent(action.getFileName());
		shellAction.appendChild(exec);

		/*
		 * Parameters
		 */
		Element oozieid = doc.createElement("env-var");
		oozieid.setTextContent("jobId=${wf:id()}");
		shellAction.appendChild(oozieid);
		if (action.getParameters() != null) {
			for (String parameter : action.getParameters()) {
				Element envvar = doc.createElement("env-var");
				envvar.setTextContent(parameter + "=${wf:conf(\"" + parameter + "\")}");
				shellAction.appendChild(envvar);
			}
		}
		// Options
		if (action.getOptions() != null) {
			for (Entry<String, String> option : action.getOptions().entrySet()) {
				Element envvar = doc.createElement("env-var");
				envvar.setTextContent(option.getKey() + "=" + option.getValue());
				shellAction.appendChild(envvar);
			}
		}

		// Required files
		for (String fname : action.getRequiredFiles()) {
			Element scfile = doc.createElement("file");
			scfile.setTextContent(fname);
			shellAction.appendChild(scfile);
		}

		if (Boolean.TRUE.equals(action.getCaptureOutput())) {
			Element captureOutput = doc.createElement("capture-output");
			shellAction.appendChild(captureOutput);
		}

		oozieShellAction.appendChild(shellAction);
		appendOkAndError(oozieShellAction, action.getActionDestination());

		return oozieShellAction;
	}

	@Override
	public Element createOozieHiveAction(OozieAction action) {

		Document doc = action.getDocument();

		Element oozieHiveAction = doc.createElement("action");
		oozieHiveAction.setAttribute("name", action.getActionName());

		Element hiveAction = doc.createElement("hive");
		hiveAction.setAttribute("xmlns", "uri:oozie:hive-action:0.5");

		// job-xml for configuration
		if (action.getJobXMLFiles() != null) {
			for (String file : action.getJobXMLFiles()) {
				Element jobxml1 = doc.createElement("job-xml");
				jobxml1.setTextContent(file);
				hiveAction.appendChild(jobxml1);
			}

		}

		Element script = doc.createElement("script");
		script.setTextContent(action.getFileName());
		hiveAction.appendChild(script);

		/*
		 * Parameters
		 */
		Element oozieid = doc.createElement("param");
		oozieid.setTextContent("jobId=${wf:id()}");
		hiveAction.appendChild(oozieid);

		// Workflow parameters
		if (action.getParameters() != null) {
			for (String parameter : action.getParameters()) {
				Element param = doc.createElement("param");
				param.setTextContent(parameter + "=${wf:conf(\"" + parameter + "\")}");
				hiveAction.appendChild(param);
			}
		}
		// Workflow options
		for (Entry<String, String> option : action.getOptions().entrySet()) {
			Element param = doc.createElement("param");
			param.setTextContent(option.getKey() + "=" + option.getValue());
			hiveAction.appendChild(param);
		}

		oozieHiveAction.appendChild(hiveAction);

		appendOkAndError(oozieHiveAction, action.getActionDestination());

		return oozieHiveAction;
	}

	@Override
	public Element createOozieJavaAction(OozieAction action) {

		Document doc = action.getDocument();

		// Action shell
		Element oozieAction = doc.createElement("action");
		oozieAction.setAttribute("name", action.getActionName());

		Element javaAction = doc.createElement("java");

		/*
		 * Parameters
		 */
		Element configuration = doc.createElement("configuration");

		Element oozieid = doc.createElement("property");
		Element oozieidName = doc.createElement("name");
		oozieidName.setTextContent("jobId");
		Element oozieidValue = doc.createElement("value");
		oozieidValue.setTextContent("${wf:id()}");
		oozieid.appendChild(oozieidName);
		oozieid.appendChild(oozieidValue);
		configuration.appendChild(oozieid);

		if (action.getParameters() != null) {
			for (String parameter : action.getParameters()) {
				Element prop = doc.createElement("property");
				Element propName = doc.createElement("name");
				propName.setTextContent(parameter);
				Element propValue = doc.createElement("value");
				propValue.setTextContent("${wf:conf(\"" + parameter + "\")}");
				prop.appendChild(propName);
				prop.appendChild(propValue);
				configuration.appendChild(prop);
			}
		}

		// Workflow options
		for (Entry<String, String> option : action.getOptions().entrySet()) {
			Element prop = doc.createElement("property");
			Element propName = doc.createElement("name");
			propName.setTextContent(option.getKey());
			Element propValue = doc.createElement("value");
			propValue.setTextContent(option.getValue());
			prop.appendChild(propName);
			prop.appendChild(propValue);
			configuration.appendChild(prop);
		}
		javaAction.appendChild(configuration);

		// Main-class
		Element script = doc.createElement("main-class");
		script.setTextContent(action.getFileName());
		javaAction.appendChild(script);

		if (action.getRequiredFiles() != null) {
			for (String requiredFile : action.getRequiredFiles()) {
				Element file = doc.createElement("file");
				file.setTextContent(requiredFile);
				javaAction.appendChild(file);
			}
		}

		// job-xml for configuration
		if (action.getJobXMLFiles() != null) {
			for (String file : action.getJobXMLFiles()) {
				Element jobxml1 = doc.createElement("job-xml");
				jobxml1.setTextContent(file);
				javaAction.appendChild(jobxml1);
			}

		}

		oozieAction.appendChild(javaAction);

		appendOkAndError(oozieAction, action.getActionDestination());

		return oozieAction;
	}

	@Override
	public Element createOozieFsAction(OozieAction action) {

		Document doc = action.getDocument();

		// Action shell
		Element oozieAction = doc.createElement("action");
		oozieAction.setAttribute("name", action.getActionName());

		Element hdfsAction = doc.createElement("fs");

		/*
		 * Parameters
		 */
		Element configuration = doc.createElement("configuration");

		Element oozieid = doc.createElement("property");
		Element oozieidName = doc.createElement("name");
		oozieidName.setTextContent("jobId");
		Element oozieidValue = doc.createElement("value");
		oozieidValue.setTextContent("${wf:id()}");
		oozieid.appendChild(oozieidName);
		oozieid.appendChild(oozieidValue);
		configuration.appendChild(oozieid);

		if (action.getParameters() != null) {
			for (String parameter : action.getParameters()) {
				Element prop = doc.createElement("property");
				Element propName = doc.createElement("name");
				propName.setTextContent(parameter);
				Element propValue = doc.createElement("value");
				propValue.setTextContent("${wf:conf(\"" + parameter + "\")}");
				prop.appendChild(propName);
				prop.appendChild(propValue);
				configuration.appendChild(prop);
			}
		}

		// Workflow options
		for (Entry<String, String> option : action.getOptions().entrySet()) {
			Element prop = doc.createElement("property");
			Element propName = doc.createElement("name");
			propName.setTextContent(option.getKey());
			Element propValue = doc.createElement("value");
			propValue.setTextContent(option.getValue());
			prop.appendChild(propName);
			prop.appendChild(propValue);
			configuration.appendChild(prop);
		}
		hdfsAction.appendChild(configuration);

		for (DataTransferSpecification spec : action.getWorkflow().getDataTransferSpecification()) {
			Element delete = doc.createElement("delete");
			delete.setAttribute("path", spec.getDestinationDatabase() + "/" + spec.getDestinationTable());
			hdfsAction.appendChild(delete);

			Element mkdir = doc.createElement("mkdir");
			mkdir.setAttribute("path", spec.getDestinationDatabase());
			hdfsAction.appendChild(mkdir);

			Element move = doc.createElement("move");
			move.setAttribute("source",
					action.getOptions().get("tmpDirectory") + "/edmhdpef_" + action.getWorkflow().getName()
							+ "_${wf:actionData('" + EdmhdpefCommon.getSourceActionName(action.getWorkflow()) + "')['"
							+ EdmhdpefConstants.SPEC_PARAM_MAX_PARTITION_BDAY + "']}_" + spec.getDestinationDatabase()
							+ "_" + spec.getDestinationTable());
			move.setAttribute("target", spec.getDestinationDatabase() + "/" + spec.getDestinationTable());
			hdfsAction.appendChild(move);
		}

		oozieAction.appendChild(hdfsAction);

		appendOkAndError(oozieAction, action.getActionDestination());

		return oozieAction;
	}

	private void appendOkAndError(Element oozieAction, String actionDestination) {
		Element destinationOk = oozieAction.getOwnerDocument().createElement("ok");
		destinationOk.setAttribute("to", actionDestination);
		Element destinationError = oozieAction.getOwnerDocument().createElement("error");
		destinationError.setAttribute("to", "fail");
		oozieAction.appendChild(destinationOk);
		oozieAction.appendChild(destinationError);
	}

}
