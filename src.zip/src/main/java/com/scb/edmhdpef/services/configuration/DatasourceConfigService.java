package com.scb.edmhdpef.services.configuration;

import java.util.List;

import com.scb.edmhdpef.entity.EdmDataSource;
import com.scb.edmhdpef.exceptions.EdmHdpEfAppException;
import com.scb.edmhdpef.exceptions.EdmHdpEfInternalException;
import com.scb.edmhdpef.exceptions.EdmHdpEfNotImplementedException;

public interface DatasourceConfigService {

	public List<EdmDataSource> retrieveDataSources(EdmDataSource criteria);

	public EdmDataSource createDataSource(EdmDataSource dataSource)
			throws EdmHdpEfAppException, EdmHdpEfNotImplementedException, EdmHdpEfInternalException;

	public void deleteDataSource(EdmDataSource dataSource) throws EdmHdpEfAppException, EdmHdpEfInternalException;

	public EdmDataSource updateDataSource(EdmDataSource dataSource)
			throws EdmHdpEfAppException, EdmHdpEfNotImplementedException, EdmHdpEfInternalException;

}
