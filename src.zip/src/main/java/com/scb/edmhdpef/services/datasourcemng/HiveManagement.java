package com.scb.edmhdpef.services.datasourcemng;

import java.io.IOException;
import java.security.PrivilegedExceptionAction;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.annotation.Resource;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.CommonConfigurationKeys;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.security.UserGroupInformation;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.scb.edmhdpef.EdmhdpefCommon;
import com.scb.edmhdpef.EdmhdpefConstants;
import com.scb.edmhdpef.entity.DataTransferSpecification;
import com.scb.edmhdpef.entity.EdmWorkflow;
import com.scb.edmhdpef.enums.BusinessDayBehaviorEnum;
import com.scb.edmhdpef.exceptions.EdmHdpEfAppException;
import com.scb.edmhdpef.exceptions.EdmHdpEfAppException.AppExceptionCode;
import com.scb.edmhdpef.exceptions.EdmHdpEfInternalException;
import com.scb.edmhdpef.exceptions.EdmHdpEfInternalException.InternalExceptionCode;
import com.scb.edmhdpef.exceptions.EdmHdpEfNotImplementedException;
import com.scb.edmhdpef.exceptions.EdmHdpEfNotImplementedException.NotImplementedExceptionCode;
import com.scb.edmhdpef.services.architecture.TemplateCreation;
import com.scb.edmhdpef.services.model.EdmhdpefProperty;
import com.scb.edmhdpef.services.model.OozieAction;

@Service
public class HiveManagement implements DataSourceManagement {

    private static final String DS_PARAM_HIVE_HIVESITEFILE = "hive.site.file";
    private static final String DS_PARAM_HIVE_TEZSITEFILE = "tez.site.file";

    @Value("${hive.tmp.database}")
    private String tmpDatabase;

    @Value("${hive.tmp.directory}")
    private String tmpDirectory;

    @Value("${edmhdpef.hive.database}")
    private String hiveDatabase;

    @Value("${hive.site.file}")
    private String configHiveSiteFile;

    @Value("${tez.site.file}")
    private String configTezSiteFile;

    @Value("${fs.defaultFS}")
    private String hadoopDefaultFS;

    @Value("${dfs.client.use.datanode.hostname}")
    private String dfsClientUseHostname;

    @Resource
    private TemplateCreation templateCreation;

    @Resource
    private OozieActionBuilder oozieActionBuilder;

    /**
     * This method is used when this datasource type is used as a source.
     * 
     * Returns the XML tree for the source actions of the Oozie configuration.
     * 
     * If the businessday behavior is activated for this workflow, it will
     * return 2 elements: a shell action to extract the businessday partitions,
     * and a hive action to dump the data into a temporary table and write the
     * rowcounts table.
     * 
     * If the businessday behavior is not activated, only the second action is
     * returned.
     * 
     * @param doc
     *            The document representing the Oozie XML configuration.
     * @param workflow
     *            The workflow.
     * 
     * @return The list of source actions to be appended to the Oozie
     *         configuration, in order.
     */
    @Override
    public List<Element> getDeploySrcActions(Document doc, EdmWorkflow workflow) throws EdmHdpEfAppException,
            EdmHdpEfInternalException {

        EdmhdpefCommon.validateWorkflowForDeployment(workflow);

        if (doc == null) {
            throw new EdmHdpEfInternalException(InternalExceptionCode.ERROR_CREATING_CONFIG_FILES);
        }

        HashMap<String, String> options = new HashMap<String, String>();
        // Default options
        for (EdmhdpefProperty property : getOptions()) {
            options.put(property.getPropertyName(), property.getDefaultValue());
        }
        // Workflow options
        if (workflow.getSourceOptions() != null) {
            options.putAll(workflow.getSourceOptions());
        }
        options.put("tmpDirectory", tmpDirectory);
        options.put("tmpDatabase", tmpDatabase);
        // Tmp table
        options.put("tmptable",
                "edmhdpef_" + workflow.getName() + "_${wf:actionData('" + EdmhdpefCommon.getSourceActionName(workflow)
                        + "')['" + EdmhdpefConstants.SPEC_PARAM_MAX_PARTITION_BDAY + "']}");
        // Storage database
        options.put("storage=", workflow.getBatchToPartitionDatabase());

        List<Element> elementList = new ArrayList<Element>();

        String hiveActionName = EdmhdpefCommon.getSourceActionName(workflow);
        OozieAction action = new OozieAction();
        action.setDocument(doc);
        action.setOptions(options);
        action.setParameters(workflow.getParameters());
        action.setRequiredFiles(this.getDeploySrcScripts(workflow).keySet());
        action.setWorkflow(workflow);

        if (EdmhdpefCommon.isBusinessDayRequired(workflow)) {
            /*
             * Shell script action
             */
            hiveActionName = EdmhdpefCommon.getSourceActionName(workflow) + "-Step2";

            options.put("STORAGE", workflow.getBatchToPartitionDatabase());
            options.put("SOURCE", "${" + EdmhdpefConstants.SPEC_PARAM_SOURCE + "}");
            options.put("COUNTRY", "${" + EdmhdpefConstants.SPEC_PARAM_COUNTRY + "}");
            options.put("BUSINESS_DAY", "${" + EdmhdpefConstants.SPEC_PARAM_BUSINESSDAY + "}");
            options.put("exec_timestamp", "${exec_timestamp}");
            options.put("exec_datehour", "${exec_datehour}");

            // Action shell
            action.setActionDestination(hiveActionName);
            action.setActionName(EdmhdpefCommon.getSourceActionName(workflow));
            action.setCaptureOutput(true);
            action.setFileName("getPartitionInfoForBusinessDay.sh");

            elementList.add(this.oozieActionBuilder.createOozieShellAction(action));

            // Parameters to get business day
            if (EdmhdpefCommon.isBusinessDayRequired(workflow)) {
                // Add max business day
                options.put("MAX_BUSINESS_DAY", "${wf:actionData('" + EdmhdpefCommon.getSourceActionName(workflow)
                        + "')['" + EdmhdpefConstants.SPEC_PARAM_MAX_PARTITION_BDAY + "']}");

                // Data retrieved from previous action
                for (String parameter : new String[] { EdmhdpefConstants.SPEC_PARAM_MAX_PARTITION_BDAY,
                        EdmhdpefConstants.SPEC_PARAM_ALL_PARTITION_BDAY }) {
                    options.put(parameter, "${wf:actionData('" + EdmhdpefCommon.getSourceActionName(workflow) + "')['"
                            + parameter + "']}");
                }
            }
        }

        /*
         * Hive action
         */
        HashSet<String> jobXMLFiles = new HashSet<String>();
        if (workflow.getSource() != null && workflow.getSource().getParameters() != null) {
            String hiveSiteFile = workflow.getSource().getParameters().get(DS_PARAM_HIVE_HIVESITEFILE);
            if (hiveSiteFile != null) {
                jobXMLFiles.add(hiveSiteFile);
            } else {
                jobXMLFiles.add("${wf:appPath()}/conf/hive-site.xml");
            }

            String tezSiteFile = workflow.getSource().getParameters().get(DS_PARAM_HIVE_TEZSITEFILE);
            if (tezSiteFile != null) {
                jobXMLFiles.add(tezSiteFile);
            } else {
                jobXMLFiles.add("${wf:appPath()}/conf/tez-site.xml");
            }
        }

        if (workflow.getProcessing() != null && !workflow.getProcessing().isEmpty()) {
            action.setActionDestination(EdmhdpefCommon.getDataProcessingActionName(workflow, 0));
        } else {
            action.setActionDestination(EdmhdpefCommon.getDestinationActionName(workflow));
        }
        action.setActionName(hiveActionName);
        action.setCaptureOutput(false);
        action.setFileName(workflow.getName() + "-src.hql");
        action.setJobXMLFiles(jobXMLFiles);

        elementList.add(this.oozieActionBuilder.createOozieHiveAction(action));
        return elementList;
    }

    @Override
    public List<Element> getDeployDstActions(Document doc, EdmWorkflow workflow) throws EdmHdpEfNotImplementedException {
        throw new EdmHdpEfNotImplementedException(NotImplementedExceptionCode.NOT_IMPLEMENTED, "Not implemented");
    }

    @Override
    public Map<String, String> getDeploySrcScripts(EdmWorkflow workflow) throws EdmHdpEfInternalException {
        Map<String, String> destinationFiles = new HashMap<String, String>();

        EdmhdpefCommon.validateWorkflowForDeployment(workflow);

        HashMap<String, Object> model = new HashMap<String, Object>();
        model.put("tmpDatabase", tmpDatabase);
        model.put("tmpDirectory", tmpDirectory);
        model.put("dataTransferSpecs", workflow.getDataTransferSpecification());
        model.put("SPEC_PARAM_ALL_PARTITION_BDAY", EdmhdpefConstants.SPEC_PARAM_ALL_PARTITION_BDAY);
        model.put("SPEC_PARAM_MAX_PARTITION_BDAY", EdmhdpefConstants.SPEC_PARAM_MAX_PARTITION_BDAY);
        model.put("BDAYALL", BusinessDayBehaviorEnum.ALL);
        model.put("BDAYLATEST", BusinessDayBehaviorEnum.LATEST);
        model.put("hiveDatabase", hiveDatabase);
        model.put("workflowName", workflow.getName());
        model.put("sourceType", workflow.getSource().getType());
        model.put("shell_username", EdmhdpefCommon.getUser());
        // Default values for parameters
        for (EdmhdpefProperty param : getParameters()) {
            model.put(param.getPropertyName(), param.getDefaultValue());
        }
        // Datasource parameters
        if (workflow.getSource().getParameters() != null) {
            for (Entry<String, String> entry : workflow.getSource().getParameters().entrySet()) {
                model.put(entry.getKey(), entry.getValue());
            }
        }
        // Default values for options
        for (EdmhdpefProperty option : getOptions()) {
            model.put(option.getPropertyName(), option.getDefaultValue());
        }
        // Setted Values for options
        if (workflow.getDestinationOptions() != null) {
            for (Entry<String, String> entry : workflow.getDestinationOptions().entrySet()) {
                model.put(entry.getKey(), entry.getValue());
            }
        }

        // Shell script for getting partitions from business day
        if (EdmhdpefCommon.isBusinessDayRequired(workflow)) {
            model.put("bdayRequired", true);
            destinationFiles.put("getPartitionInfoForBusinessDay.sh",
                    this.templateCreation.getTemplate("hive/getPartitionInfoForBusinessDay.sh", model));
        } else {
            model.put("bdayRequired", false);
        }
        // Identify max no. of columns
        int maxCols = 0;
        for (DataTransferSpecification spec : workflow.getDataTransferSpecification()) {
            if (spec.getColumns() != null) {
                maxCols = Math.max(maxCols, spec.getColumns().size());
            }
        }
        model.put("maxCols", maxCols);

        // Hive script
        switch (workflow.getType()) {
        case TABLE_GROUP:
            destinationFiles.put(workflow.getName() + "-src.hql",
                    this.templateCreation.getTemplate("hive/workflow-src-toTeradata.hql", model));
            break;
        case GENERIC:
        default:
            destinationFiles.put(workflow.getName() + "-src.hql",
                    this.templateCreation.getTemplate("hive/workflow-src.hql", model));
            break;
        }

        return destinationFiles;
    }

    @Override
    public Map<String, String> getDeployDstScripts(EdmWorkflow workflow) throws EdmHdpEfNotImplementedException {
        throw new EdmHdpEfNotImplementedException(NotImplementedExceptionCode.NOT_IMPLEMENTED, "Not implemented");
    }

    @Override
    public List<EdmhdpefProperty> getParameters() {
        List<EdmhdpefProperty> returnList = new ArrayList<EdmhdpefProperty>();
        returnList.add(new EdmhdpefProperty(DS_PARAM_HIVE_HIVESITEFILE, true, configHiveSiteFile,
                "HDFS path of the hive-site.xml file"));
        returnList.add(new EdmhdpefProperty(DS_PARAM_HIVE_TEZSITEFILE, true, configTezSiteFile,
                "HDFS path of the tez-site.xml file"));
        return returnList;
    }

    @Override
    public void validateParameters(Map<String, String> parameters) throws EdmHdpEfAppException,
            EdmHdpEfInternalException {

        // Check if hive and tez files exist
        final Configuration config = new Configuration();
        final String finalHiveSiteFile = parameters.get(DS_PARAM_HIVE_HIVESITEFILE);
        final String finalTezSiteFile = parameters.get(DS_PARAM_HIVE_TEZSITEFILE);
        if (finalHiveSiteFile == null && finalTezSiteFile == null) {
            return;
        }
        config.set(CommonConfigurationKeys.FS_DEFAULT_NAME_KEY, hadoopDefaultFS);
        if (dfsClientUseHostname != null) {
            config.set("dfs.client.use.datanode.hostname", dfsClientUseHostname);
        }
        UserGroupInformation ugi = UserGroupInformation.createRemoteUser(EdmhdpefCommon.getUser());
        try {
            ugi.doAs(new PrivilegedExceptionAction<Void>() {
                public Void run() throws IllegalArgumentException, IOException, EdmHdpEfAppException {
                    FileSystem fs = FileSystem.get(config);

                    if (finalHiveSiteFile != null && !fs.exists(new Path(finalHiveSiteFile))) {
                        throw new EdmHdpEfAppException(AppExceptionCode.PARAMETER_ERROR, "File " + finalHiveSiteFile
                                + " does not exist.");
                    }
                    if (finalTezSiteFile != null && !fs.exists(new Path(finalTezSiteFile))) {
                        throw new EdmHdpEfAppException(AppExceptionCode.PARAMETER_ERROR, "File " + finalTezSiteFile
                                + " does not exist.");
                    }
                    return null;
                }
            });
        } catch (IOException | InterruptedException e) {
            throw new EdmHdpEfInternalException(InternalExceptionCode.HDFS_ERROR, "Error on HDFS filesystem", e);
        }
    }

    @Override
    public List<EdmhdpefProperty> getOptions() {
        return new ArrayList<EdmhdpefProperty>();
    }

    @Override
    public void validateOptions(Map<String, String> sourceOptions) throws EdmHdpEfAppException,
            EdmHdpEfInternalException {

    }
}