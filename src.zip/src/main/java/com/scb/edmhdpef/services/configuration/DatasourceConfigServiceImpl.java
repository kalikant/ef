package com.scb.edmhdpef.services.configuration;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.dozer.DozerBeanMapper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.scb.edmhdpef.entity.EdmDataSource;
import com.scb.edmhdpef.exceptions.EdmHdpEfAppException;
import com.scb.edmhdpef.exceptions.EdmHdpEfAppException.AppExceptionCode;
import com.scb.edmhdpef.exceptions.EdmHdpEfInternalException;
import com.scb.edmhdpef.exceptions.EdmHdpEfNotImplementedException;
import com.scb.edmhdpef.services.architecture.security.EncryptionService;
import com.scb.edmhdpef.services.database.DataAccessService;
import com.scb.edmhdpef.services.datasourcemng.DataSourceManagement;
import com.scb.edmhdpef.services.datasourcemng.DataSourceManagementSelector;
import com.scb.edmhdpef.services.model.EdmhdpefProperty;

@Service("datasourceConfigService")
public class DatasourceConfigServiceImpl implements DatasourceConfigService {

	@Resource(name = "dataAccessService")
	private DataAccessService dataAccess;

	@Resource
	private EncryptionService encryptionService;

	@Resource
	private DataSourceManagementSelector dataSourceManagementSelector;

	@Resource
	private DozerBeanMapper mappingService;

	@SuppressWarnings("unchecked")
	@Override
	public List<EdmDataSource> retrieveDataSources(EdmDataSource criteria) {
		if (criteria == null) {
			criteria = new EdmDataSource();
		}
		if (criteria.getName() != null && !criteria.getName().trim().isEmpty()) {
			List<EdmDataSource> list = new ArrayList<EdmDataSource>();
			list.add((EdmDataSource) this.dataAccess.retrieveById(EdmDataSource.class, criteria.getName()));
			return list;
		} else {
			return (List<EdmDataSource>) this.dataAccess.retrieveByCriteria(criteria);
		}
	}

	@Override
	public EdmDataSource createDataSource(EdmDataSource dataSource)
			throws EdmHdpEfAppException, EdmHdpEfNotImplementedException, EdmHdpEfInternalException {
		validateDataSource(dataSource);

		EdmDataSource existentDatasource = (EdmDataSource) this.dataAccess.retrieveById(EdmDataSource.class,
				dataSource.getName());

		if (existentDatasource != null) {
			throw new EdmHdpEfAppException(AppExceptionCode.ENTITY_ALREADY_EXISTS,
					"DataSource " + dataSource.getName() + " already exists.");
		}

		dataSource.setParameters(this.encryptionService.encryptParameters(dataSource.getParameters()));

		return (EdmDataSource) this.dataAccess.saveOrUpdateObject(dataSource);
	}

	@Override
	public void deleteDataSource(EdmDataSource dataSource) throws EdmHdpEfAppException, EdmHdpEfInternalException {
		if (dataSource.getName() == null || dataSource.getName().trim().isEmpty()) {
			throw new EdmHdpEfAppException(AppExceptionCode.PARAMETER_NOT_SPECIFIED, "DataSource name not specified.");
		}

		EdmDataSource existentDatasource = (EdmDataSource) this.dataAccess.retrieveById(EdmDataSource.class,
				dataSource.getName());

		if (existentDatasource == null) {
			throw new EdmHdpEfAppException(AppExceptionCode.ENTITY_NOT_EXISTS,
					"DataSource " + dataSource.getName() + " does not exist.");
		}

		this.dataAccess.deleteObject(existentDatasource);
	}

	@Transactional
	@Override
	public EdmDataSource updateDataSource(EdmDataSource dataSource)
			throws EdmHdpEfAppException, EdmHdpEfNotImplementedException, EdmHdpEfInternalException {

		validateDataSource(dataSource);

		EdmDataSource existentDatasource = (EdmDataSource) this.dataAccess.retrieveById(EdmDataSource.class,
				dataSource.getName());

		if (existentDatasource == null) {
			throw new EdmHdpEfAppException(AppExceptionCode.ENTITY_NOT_EXISTS,
					"DataSource " + dataSource.getName() + " does not exist.");
		}

		this.mappingService.map(dataSource, existentDatasource);

		existentDatasource.setParameters(this.encryptionService.encryptParameters(dataSource.getParameters()));

		return (EdmDataSource) this.dataAccess.saveOrUpdateObject(existentDatasource);
	}

	private void validateDataSource(EdmDataSource dataSource)
			throws EdmHdpEfAppException, EdmHdpEfNotImplementedException, EdmHdpEfInternalException {
		if (dataSource == null || dataSource.getName() == null || dataSource.getName().trim().isEmpty()) {
			throw new EdmHdpEfAppException(AppExceptionCode.PARAMETER_NOT_SPECIFIED, "DataSource name not specified.");
		}

		if (dataSource.getType() == null) {
			throw new EdmHdpEfAppException(AppExceptionCode.PARAMETER_NOT_SPECIFIED, "DataSource type not specified.");
		}

		// Validate parameters
		Map<String, String> parameters = dataSource.getParameters();
		if (parameters == null) {
			parameters = new HashMap<String, String>();
		}
		DataSourceManagement dataSourceManagement = this.dataSourceManagementSelector
				.getDataSourceManagement(dataSource);
		List<EdmhdpefProperty> dsparameters = dataSourceManagement.getParameters();
		for (EdmhdpefProperty dsp : dsparameters) {
			if (!parameters.containsKey(dsp.getPropertyName())) {
				if (!dsp.isOptional()) {
					throw new EdmHdpEfAppException(AppExceptionCode.PARAMETER_ERROR,
							"Parameter " + dsp.getPropertyName() + " is compulsory.");

				}
			}
		}
		// Validate parameters (will throw exception if not valid)
		dataSourceManagement.validateParameters(parameters);
		// Set the validated parameters, plus added optional parameters
		dataSource.setParameters(parameters);
	}

}
