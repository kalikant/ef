package com.scb.edmhdpef.services.architecture;

import java.io.IOException;
import java.io.StringWriter;
import java.util.HashMap;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.web.servlet.view.freemarker.FreeMarkerConfigurer;

import com.scb.edmhdpef.exceptions.EdmHdpEfInternalException;
import com.scb.edmhdpef.exceptions.EdmHdpEfInternalException.InternalExceptionCode;

import freemarker.template.Template;
import freemarker.template.TemplateException;

@Service("templateCreation")
public class TemplateCreationImpl implements TemplateCreation {

	@Resource
	private FreeMarkerConfigurer freeMarkerConfig;

	@Override
	public String getTemplate(String templateName, HashMap<String, Object> dataModel) throws EdmHdpEfInternalException {
		try {
			Template getPartitionInfo = this.freeMarkerConfig.getConfiguration().getTemplate(templateName);
			StringWriter out = new StringWriter();
			getPartitionInfo.process(dataModel, out);
			return out.toString().replaceAll("\r\n", "\n");
		} catch (IOException | TemplateException e) {
			throw new EdmHdpEfInternalException(InternalExceptionCode.ERROR_CREATING_CONFIG_FILES,
					"Error creating script: " + templateName + "\n" + e.getMessage(), e);
		}
	}

}
