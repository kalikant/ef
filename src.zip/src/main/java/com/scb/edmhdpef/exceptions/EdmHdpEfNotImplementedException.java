package com.scb.edmhdpef.exceptions;

public class EdmHdpEfNotImplementedException extends Exception {

	public enum NotImplementedExceptionCode {
		TYPE_NOT_RECOGNIZED(9001), NOT_IMPLEMENTED(9002);

		private final Integer value;

		private NotImplementedExceptionCode(Integer value) {
			this.value = value;
		}

		public Integer getType() {
			return value;
		}
	}

	private static final long serialVersionUID = 1L;

	private final NotImplementedExceptionCode code;

	public EdmHdpEfNotImplementedException(NotImplementedExceptionCode code) {
		this.code = code;
	}

	public EdmHdpEfNotImplementedException(String message) {
		super(message);
		this.code = NotImplementedExceptionCode.NOT_IMPLEMENTED;
	}

	public EdmHdpEfNotImplementedException(NotImplementedExceptionCode code, String message) {
		super(message);
		this.code = code;
	}

	public NotImplementedExceptionCode getCode() {
		return code;
	}
}