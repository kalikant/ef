package com.scb.edmhdpef.exceptions;

public class EdmHdpEfAppException extends Exception {

	public enum AppExceptionCode {
		PARAMETER_NOT_SPECIFIED(1001), PARAMETER_ERROR(1002), ENTITY_ALREADY_EXISTS(
				2001), ENTITY_NOT_EXISTS(2002);

		private final Integer value;

		private AppExceptionCode(Integer value) {
			this.value = value;
		}

		public Integer getType() {
			return value;
		}
	}

	private static final long serialVersionUID = 1L;

	private final AppExceptionCode code;

	public EdmHdpEfAppException(AppExceptionCode code) {
		this.code = code;
	}

	public EdmHdpEfAppException(AppExceptionCode code, String message) {
		super(message);
		this.code = code;
	}

	public EdmHdpEfAppException(AppExceptionCode code, String message,
			Throwable e) {
		super(message, e);
		this.code = code;
	}

	public AppExceptionCode getCode() {
		return code;
	}
}
