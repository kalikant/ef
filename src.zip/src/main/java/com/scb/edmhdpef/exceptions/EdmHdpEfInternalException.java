package com.scb.edmhdpef.exceptions;

public class EdmHdpEfInternalException extends Exception {

	public enum InternalExceptionCode {
		ERROR_CREATING_CONFIG_FILES(4001), OOZIE_ERROR(4002), DATA_STORAGE_ERROR(4003), HDFS_ERROR(
				4004), ENCRYPTION_ERROR(4005), HIVE_ERROR(4006),DEBUG_ERROR(4007);

		private final Integer value;

		private InternalExceptionCode(Integer value) {
			this.value = value;
		}

		public Integer getType() {
			return value;
		}
	}

	private static final long serialVersionUID = 1L;

	private final InternalExceptionCode code;

	public EdmHdpEfInternalException(InternalExceptionCode code) {
		this.code = code;
	}

	public EdmHdpEfInternalException(InternalExceptionCode code, String message) {
		super(message);
		this.code = code;
	}

	public EdmHdpEfInternalException(InternalExceptionCode code, String message, Throwable e) {
		super(message, e);
		this.code = code;
	}

	public InternalExceptionCode getCode() {
		return code;
	}
}
