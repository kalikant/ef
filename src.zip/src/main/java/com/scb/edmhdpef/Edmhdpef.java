package com.scb.edmhdpef;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.eclipse.jetty.server.Handler;
import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.webapp.WebAppContext;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.web.context.ContextLoaderListener;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.AnnotationConfigWebApplicationContext;

@Configuration
public class Edmhdpef {

	private static final String CONFIG_LOCATION = "com.scb.edmhdpef.config.*";

	private static final Logger logger = Logger.getLogger(Edmhdpef.class);

	public static void main(String[] args) throws IOException {
		System.out.println("Starting Emdhdpef HTTPServer...\n");
		new Edmhdpef().startJetty();
		System.out.println("Started Emdhdpef Embedded HTTPServer Successfully !!!");
		logger.info("Started Emdhdpef Embedded HTTPServer Successfully !!!");
	}

	private void startJetty() throws IOException {

		InputStream propertiesStream = getClass().getResourceAsStream("/application.properties");
		Properties properties = new Properties();
		properties.load(propertiesStream);

		int port = Integer.parseInt(properties.getProperty("edmhdpef.server.port", "12001"));

		Server server = new Server(port);
		try {
			server.setHandler(getServletContextHandler(getContext()));
			server.start();
			System.out.println("Started Emdhdpef Embedded HTTPServer Successfully !!!");
			logger.info("Started Emdhdpef Embedded HTTPServer Successfully !!!");
			server.join();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private Handler getServletContextHandler(WebApplicationContext context) throws IOException {

		WebAppContext webAppContext = new WebAppContext();
		webAppContext.setErrorHandler(null);
		webAppContext.setContextPath("/Edmhdpef");
		webAppContext.addEventListener(new ContextLoaderListener(context));
		ClassPathResource pathResource = new ClassPathResource(".");
		webAppContext.setResourceBase(pathResource.getURI().toString());

		return webAppContext;
	}

	private static WebApplicationContext getContext() {
		AnnotationConfigWebApplicationContext context = new AnnotationConfigWebApplicationContext();
		context.setConfigLocation(CONFIG_LOCATION);
		return context;
	}
}
