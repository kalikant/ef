package com.scb.edmhdpef.converters;

import java.util.HashMap;
import java.util.Map;

import org.dozer.CustomConverter;

public class PersistentMapToHashMap implements CustomConverter {

	@SuppressWarnings("unchecked")
	@Override
	public Object convert(Object existingDestinationFieldValue, Object sourceFieldValue, Class<?> destinationClass,
			Class<?> sourceClass) {
		if (sourceFieldValue == null) {
			return null;
		}
		if (existingDestinationFieldValue == null) {
			existingDestinationFieldValue = new HashMap<String, String>();
		}
		Map<String, String> dst = (Map<String, String>) existingDestinationFieldValue;
		Map<String, String> src = (Map<String, String>) sourceFieldValue;
		dst.putAll(src);
		return dst;
	}
}
