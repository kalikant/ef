package com.scb.edmhdpef;

public class EdmhdpefConstants {

	public static final String DS_PARAM_HIVE_HIVESITEFILE = "hive.site.file";
	public static final String DS_PARAM_HIVE_TEZSITEFILE = "tez.site.file";

	public static final String SPEC_PARAM_BUSINESSDAY = "businessday";
	public static final String SPEC_PARAM_SOURCE = "source";
	public static final String SPEC_PARAM_COUNTRY = "country";
	public static final String SPEC_PARAM_MAX_PARTITION_BDAY = "edmhdpef.ebbs_to_teradata.max_partition_for_business_day";
	public static final String SPEC_PARAM_ALL_PARTITION_BDAY = "edmhdpef.ebbs_to_teradata.all_partitions_for_business_day";

	public static final String ENCRYPT_KEY_NAME = "EdmHdpEf";
}
