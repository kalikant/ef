package com.scb.edmhdpef.entity;

import java.util.Map;

import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Version;
import javax.xml.bind.annotation.XmlRootElement;

import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;
import org.hibernate.envers.Audited;

import com.scb.edmhdpef.enums.EdmDataSourceTypeEnum;

@XmlRootElement
@Entity
@Audited
public class EdmDataSource {

	@Id
	private String name;

	private String description;

	private EdmDataSourceTypeEnum type;

	@ElementCollection
	@LazyCollection(LazyCollectionOption.FALSE)
	private Map<String, String> parameters;

	@Version
	private Integer version;

	public Integer getVersion() {
		return version;
	}

	public void setVersion(Integer version) {
		this.version = version;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public EdmDataSourceTypeEnum getType() {
		return type;
	}

	public void setType(EdmDataSourceTypeEnum type) {
		this.type = type;
	}

	public Map<String, String> getParameters() {
		return parameters;
	}

	public void setParameters(Map<String, String> parameters) {
		this.parameters = parameters;
	}

	@Override
	public String toString() {
		return "EdmDataSource [name=" + name + ", description=" + description + ", type=" + type + ", parameters="
				+ parameters + ", version=" + version + "]";
	}
}
