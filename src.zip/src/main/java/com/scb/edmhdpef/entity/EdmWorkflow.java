package com.scb.edmhdpef.entity;

import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Version;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSeeAlso;

import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;
import org.hibernate.envers.Audited;

import com.scb.edmhdpef.enums.EdmWorkflowTypeEnum;

@XmlRootElement
@XmlSeeAlso(DataTransferSpecification.class)
@Entity
@Audited
public class EdmWorkflow {

	@Id
	private String name;

	private String batchToPartitionDatabase;

	@ManyToOne
	@LazyCollection(LazyCollectionOption.FALSE)
	private EdmDataSource source;

	@ManyToOne
	@LazyCollection(LazyCollectionOption.FALSE)
	private EdmDataSource destination;

	private String description;

	private EdmWorkflowTypeEnum type;

	@OneToMany(cascade = CascadeType.ALL)
	@LazyCollection(LazyCollectionOption.FALSE)
	private List<DataTransferSpecification> dataTransferSpecification;

	@OneToMany(cascade = CascadeType.ALL)
	@LazyCollection(LazyCollectionOption.FALSE)
	private List<DataProcessing> processing;

	@ElementCollection
	@LazyCollection(LazyCollectionOption.FALSE)
	private Set<String> parameters;

	@ElementCollection
	@LazyCollection(LazyCollectionOption.FALSE)
	private Map<String, String> sourceOptions;

	@ElementCollection
	@LazyCollection(LazyCollectionOption.FALSE)
	private Map<String, String> destinationOptions;

	@Version
	private Integer version;

	public Integer getVersion() {
		return version;
	}

	public void setVersion(Integer version) {
		this.version = version;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public EdmWorkflowTypeEnum getType() {
		return type;
	}

	public void setType(EdmWorkflowTypeEnum type) {
		this.type = type;
	}

	public List<DataProcessing> getProcessing() {
		return processing;
	}

	public void setProcessing(List<DataProcessing> processing) {
		this.processing = processing;
	}

	public Set<String> getParameters() {
		return parameters;
	}

	public void setParameters(Set<String> parameters) {
		this.parameters = parameters;
	}

	public List<DataTransferSpecification> getDataTransferSpecification() {
		return dataTransferSpecification;
	}

	public void setDataTransferSpecification(List<DataTransferSpecification> dataTransferSpecification) {
		this.dataTransferSpecification = dataTransferSpecification;
	}

	public EdmDataSource getSource() {
		return source;
	}

	public void setSource(EdmDataSource source) {
		this.source = source;
	}

	public EdmDataSource getDestination() {
		return destination;
	}

	public void setDestination(EdmDataSource destination) {
		this.destination = destination;
	}

	public String getBatchToPartitionDatabase() {
		return batchToPartitionDatabase;
	}

	public void setBatchToPartitionDatabase(String batchToPartitionDB) {
		this.batchToPartitionDatabase = batchToPartitionDB;
	}

	public Map<String, String> getSourceOptions() {
		return sourceOptions;
	}

	public void setSourceOptions(Map<String, String> sourceOptions) {
		this.sourceOptions = sourceOptions;
	}

	public Map<String, String> getDestinationOptions() {
		return destinationOptions;
	}

	public void setDestinationOptions(Map<String, String> destinationOptions) {
		this.destinationOptions = destinationOptions;
	}

	@Override
	public String toString() {
		return "EdmWorkflow [name=" + name + ", batchToPartitionDatabase=" + batchToPartitionDatabase + ", source="
				+ source + ", destination=" + destination + ", description=" + description + ", type=" + type
				+ ", dataTransferSpecification=" + dataTransferSpecification + ", processing=" + processing
				+ ", parameters=" + parameters + ", sourceOptions=" + sourceOptions + ", destinationOptions="
				+ destinationOptions + ", version=" + version + "]";
	}
}
