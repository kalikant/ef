package com.scb.edmhdpef.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Version;

import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;
import org.hibernate.envers.Audited;

import com.scb.edmhdpef.enums.BusinessDayBehaviorEnum;

@Entity
@Audited
public class DataTransferSpecification {

    @Id
    @GeneratedValue
    private Integer id;

    private String sourceDatabase;

    private String sourceTable;

    private String sourceTablePartitionName;

    private String destinationDatabase;

    private String destinationTable;

    private String filterCondition;

    private BusinessDayBehaviorEnum businessDayBehavior;

    @OneToMany(cascade = CascadeType.ALL)
    @LazyCollection(LazyCollectionOption.FALSE)
    private List<EdmColumns> columns;

    @Version
    private Integer version;

    public String getFilterCondition() {
        return filterCondition;
    }

    public void setFilterCondition(String filterCondition) {
        this.filterCondition = filterCondition;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getSourceTable() {
        return sourceTable;
    }

    public void setSourceTable(String sourceTable) {
        this.sourceTable = sourceTable;
    }

    public String getSourceTablePartitionName() {
        return sourceTablePartitionName;
    }

    public void setSourceTablePartitionName(String sourceTablePartitionName) {
        this.sourceTablePartitionName = sourceTablePartitionName;
    }

    public String getDestinationTable() {
        return destinationTable;
    }

    public void setDestinationTable(String destinationTable) {
        this.destinationTable = destinationTable;
    }

    public BusinessDayBehaviorEnum getBusinessDayBehavior() {
        return businessDayBehavior;
    }

    public void setBusinessDayBehavior(BusinessDayBehaviorEnum businessDayBehavior) {
        this.businessDayBehavior = businessDayBehavior;
    }

    public List<EdmColumns> getColumns() {
        return columns;
    }

    public void setColumns(List<EdmColumns> columns) {
        this.columns = columns;
    }

    public String getSourceDatabase() {
        return sourceDatabase;
    }

    public void setSourceDatabase(String sourceDatabase) {
        this.sourceDatabase = sourceDatabase;
    }

    public String getDestinationDatabase() {
        return destinationDatabase;
    }

    public void setDestinationDatabase(String destinationDatabase) {
        this.destinationDatabase = destinationDatabase;
    }

    @Override
    public String toString() {
        return "DataTransferSpecification [id=" + id + ", sourceDatabase=" + sourceDatabase + ", sourceTable="
                + sourceTable + ", sourceTablePartitionName=" + sourceTablePartitionName + ", destinationDatabase="
                + destinationDatabase + ", destinationTable=" + destinationTable + ", filterCondition="
                + filterCondition + ", businessDayBehavior=" + businessDayBehavior + ", columns=" + columns
                + ", version=" + version + "]";
    }
}
