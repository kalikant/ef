package com.scb.edmhdpef.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import org.hibernate.envers.Audited;

@Entity
@Audited
public class EdmColumns {

	@Id
	@GeneratedValue
	private Integer id;

	private String source;

	private String destination;

	private String datatype = "VARCHAR(1000)";

	private Boolean checksum = false;

	private Boolean timestamp = false;

	private Boolean functionalKey = false;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String sourceColumnName) {
		this.source = sourceColumnName;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destinationColumnName) {
		this.destination = destinationColumnName;
	}

	public String getDatatype() {
		return datatype;
	}

	public void setDatatype(String datatype) {
		this.datatype = datatype;
	}

	public Boolean getChecksum() {
		return checksum;
	}

	public void setChecksum(Boolean checksum) {
		this.checksum = checksum;
	}

	public Boolean getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(Boolean timestamp) {
		this.timestamp = timestamp;
	}

	public Boolean getFunctionalKey() {
		return functionalKey;
	}

	public void setFunctionalKey(Boolean functionalKey) {
		this.functionalKey = functionalKey;
	}

	@Override
	public String toString() {
		return "EdmColumns [" + (id != null ? "id=" + id + ", " : "")
				+ (source != null ? "source=" + source + ", " : "")
				+ (destination != null ? "destination=" + destination + ", " : "")
				+ (datatype != null ? "datatype=" + datatype + ", " : "")
				+ (checksum != null && checksum != false ? "checksum=" + checksum + ", " : "")
				+ (timestamp != null && timestamp != false ? "timestamp=" + timestamp + ", " : "")
				+ (functionalKey != null && functionalKey != false ? "functionalKey=" + functionalKey : "") + "]";
	}
}
