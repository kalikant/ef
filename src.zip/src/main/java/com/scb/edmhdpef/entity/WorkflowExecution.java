package com.scb.edmhdpef.entity;

import java.util.Date;
import java.util.Map;

import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Version;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSeeAlso;

import org.apache.oozie.client.WorkflowJob;
import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;
import org.hibernate.envers.Audited;

@XmlRootElement
@XmlSeeAlso({ EdmWorkflow.class })
@Audited
@Entity
public class WorkflowExecution implements Comparable<WorkflowExecution> {

	@Id
	private String jobId;

	@Version
	private Integer version;

	@ManyToOne
	@LazyCollection(LazyCollectionOption.FALSE)
	private EdmWorkflow workflow;

	@ElementCollection
	@LazyCollection(LazyCollectionOption.FALSE)
	private Map<String, String> parameters;

	private Date executionDate;

	private WorkflowJob.Status status;

	public String getJobId() {
		return jobId;
	}

	public void setJobId(String jobId) {
		this.jobId = jobId;
	}

	public Integer getVersion() {
		return version;
	}

	public void setVersion(Integer version) {
		this.version = version;
	}

	public EdmWorkflow getWorkflow() {
		return workflow;
	}

	public void setWorkflow(EdmWorkflow workflow) {
		this.workflow = workflow;
	}

	public Map<String, String> getParameters() {
		return parameters;
	}

	public void setParameters(Map<String, String> parameters) {
		this.parameters = parameters;
	}

	public Date getExecutionDate() {
		return executionDate;
	}

	public void setExecutionDate(Date executionDate) {
		this.executionDate = executionDate;
	}

	public WorkflowJob.Status getStatus() {
		return status;
	}

	public void setStatus(WorkflowJob.Status status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "WorkflowExecution [jobId=" + jobId + ", version=" + version + ", workflow=" + workflow + ", parameters="
				+ parameters + ", executionDate=" + executionDate + ", status=" + status + "]";
	}

	@Override
	public int compareTo(WorkflowExecution o) {
		int dateComp = this.getExecutionDate().compareTo(o.getExecutionDate());
		if (dateComp != 0) {
			return dateComp;
		}
		return this.getJobId().compareTo(o.getJobId());
	}
}
