package com.scb.edmhdpef.vo;

import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSeeAlso;

import com.scb.edmhdpef.entity.EdmDataSource;

@XmlRootElement
@XmlSeeAlso({ EdmDataSource.class })
public class DataSourceListVO {

	private List<EdmDataSource> datasources;

	public List<EdmDataSource> getDatasources() {
		return datasources;
	}

	public void setDatasources(List<EdmDataSource> datasources) {
		this.datasources = datasources;
	}
}
