package com.scb.edmhdpef.vo;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class EdmColumnsVO {
	private String source;
	private String destination;

	private Boolean checksum = false;

	private Boolean timestamp = false;

	private Boolean functionalKey = false;

	public String getSource() {
		return source;
	}

	public void setSource(String sourceColumnName) {
		this.source = sourceColumnName;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destinationColumnName) {
		this.destination = destinationColumnName;
	}

	public Boolean getChecksum() {
		return checksum;
	}

	public void setChecksum(Boolean checksum) {
		this.checksum = checksum;
	}

	public Boolean getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(Boolean timestamp) {
		this.timestamp = timestamp;
	}

	public Boolean getFunctionalKey() {
		return functionalKey;
	}

	public void setFunctionalKey(Boolean functionalKey) {
		this.functionalKey = functionalKey;
	}
}
