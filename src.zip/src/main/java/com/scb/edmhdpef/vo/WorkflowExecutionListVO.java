package com.scb.edmhdpef.vo;

import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSeeAlso;

import com.scb.edmhdpef.entity.WorkflowExecution;

@XmlRootElement
@XmlSeeAlso({ WorkflowExecution.class })
public class WorkflowExecutionListVO {

	private List<WorkflowExecution> executionList;

	public List<WorkflowExecution> getExecutionList() {
		return executionList;
	}

	public void setExecutionList(List<WorkflowExecution> executionList) {
		this.executionList = executionList;
	}

}
