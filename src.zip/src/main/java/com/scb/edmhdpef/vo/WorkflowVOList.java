package com.scb.edmhdpef.vo;

import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSeeAlso;

@XmlRootElement
@XmlSeeAlso({ WorkflowDefinitionVO.class })
public class WorkflowVOList {

	private List<WorkflowDefinitionVO> workflowList;

	public List<WorkflowDefinitionVO> getWorkflowList() {
		return workflowList;
	}

	public void setWorkflowList(List<WorkflowDefinitionVO> workflowList) {
		this.workflowList = workflowList;
	}

}
