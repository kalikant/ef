package com.scb.edmhdpef.vo;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSeeAlso;

@XmlRootElement
@XmlSeeAlso(DeploymentFileVO.class)
public class DeploymentFileListVO {
	List<DeploymentFileVO> files = new ArrayList<DeploymentFileVO>();

	public List<DeploymentFileVO> getFiles() {
		return files;
	}

	public void setFiles(List<DeploymentFileVO> files) {
		this.files = files;
	}
}
