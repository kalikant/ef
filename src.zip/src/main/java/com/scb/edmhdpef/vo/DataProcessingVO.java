package com.scb.edmhdpef.vo;

import java.util.Map;

import javax.xml.bind.annotation.XmlRootElement;

import com.scb.edmhdpef.enums.DataProcessingType;

@XmlRootElement
public class DataProcessingVO {

	private DataProcessingType type;

	private Map<String, String> options;

	public DataProcessingType getType() {
		return type;
	}

	public void setType(DataProcessingType type) {
		this.type = type;
	}

	public Map<String, String> getOptions() {
		return options;
	}

	public void setOptions(Map<String, String> options) {
		this.options = options;
	}
}
