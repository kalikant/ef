package com.scb.edmhdpef.vo;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class WorkflowStatusVO {

	private String workflowName;
	private String jobId;

	public String getWorkflowName() {
		return workflowName;
	}

	public void setWorkflowName(String workflowName) {
		this.workflowName = workflowName;
	}

	public String getJobId() {
		return jobId;
	}

	public void setJobId(String jobId) {
		this.jobId = jobId;
	}

	@Override
	public String toString() {
		return "WorkflowStatusVO [workflowName=" + workflowName + ", jobId="
				+ jobId + "]";
	}

}
