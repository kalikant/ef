package com.scb.edmhdpef.vo;

import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSeeAlso;

import com.scb.edmhdpef.enums.EdmWorkflowTypeEnum;

@XmlRootElement
@XmlSeeAlso({ DataTransferSpecificationVO.class, DataProcessingVO.class })
public class WorkflowDefinitionVO {

	private String name;
	private String description;
	private EdmWorkflowTypeEnum type;
	private String sourceName;
	private String destinationName;
	private String batchToPartitionDatabase;
	private List<DataTransferSpecificationVO> dataTransferSpecification;
	private List<DataProcessingVO> processing;
	private Set<String> parameters;
	private Map<String, String> sourceOptions;
	private Map<String, String> destinationOptions;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getSourceName() {
		return sourceName;
	}

	public void setSourceName(String sourceName) {
		this.sourceName = sourceName;
	}

	public String getDestinationName() {
		return destinationName;
	}

	public void setDestinationName(String destinationName) {
		this.destinationName = destinationName;
	}

	public List<DataTransferSpecificationVO> getDataTransferSpecification() {
		return dataTransferSpecification;
	}

	public void setDataTransferSpecification(List<DataTransferSpecificationVO> dataTransferSpecs) {
		this.dataTransferSpecification = dataTransferSpecs;
	}

	public EdmWorkflowTypeEnum getType() {
		return type;
	}

	public void setType(EdmWorkflowTypeEnum type) {
		this.type = type;
	}

	public Set<String> getParameters() {
		return parameters;
	}

	public void setParameters(Set<String> parameters) {
		this.parameters = parameters;
	}

	public String getBatchToPartitionDatabase() {
		return batchToPartitionDatabase;
	}

	public void setBatchToPartitionDatabase(String batchToPartitionDatabase) {
		this.batchToPartitionDatabase = batchToPartitionDatabase;
	}

	public Map<String, String> getSourceOptions() {
		return sourceOptions;
	}

	public void setSourceOptions(Map<String, String> sourceOptions) {
		this.sourceOptions = sourceOptions;
	}

	public Map<String, String> getDestinationOptions() {
		return destinationOptions;
	}

	public void setDestinationOptions(Map<String, String> destinationOptions) {
		this.destinationOptions = destinationOptions;
	}

	public List<DataProcessingVO> getProcessing() {
		return processing;
	}

	public void setProcessing(List<DataProcessingVO> processing) {
		this.processing = processing;
	}

}
