package com.scb.edmhdpef.vo;

import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSeeAlso;

import com.scb.edmhdpef.enums.BusinessDayBehaviorEnum;

@XmlRootElement
@XmlSeeAlso({ EdmColumnsVO.class })
public class DataTransferSpecificationVO {
    private String sourceDatabase;
    private String destinationDatabase;
    private String sourceTable;
    private String sourceTablePartitionName;
    private String destinationTable;
    private List<EdmColumnsVO> columns;
    private String filterCondition;
    private BusinessDayBehaviorEnum businessDayBehavior;

    public String getSourceDatabase() {
        return sourceDatabase;
    }

    public void setSourceDatabase(String sourceDatabase) {
        this.sourceDatabase = sourceDatabase;
    }

    public String getDestinationDatabase() {
        return destinationDatabase;
    }

    public void setDestinationDatabase(String destinationDatabase) {
        this.destinationDatabase = destinationDatabase;
    }

    public String getSourceTable() {
        return sourceTable;
    }

    public void setSourceTable(String sourceTable) {
        this.sourceTable = sourceTable;
    }

    public String getSourceTablePartitionName() {
        return sourceTablePartitionName;
    }

    public void setSourceTablePartitionName(String sourceTablePartitionName) {
        this.sourceTablePartitionName = sourceTablePartitionName;
    }

    public String getDestinationTable() {
        return destinationTable;
    }

    public void setDestinationTable(String destinationTable) {
        this.destinationTable = destinationTable;
    }

    public List<EdmColumnsVO> getColumns() {
        return columns;
    }

    public void setColumns(List<EdmColumnsVO> columns) {
        this.columns = columns;
    }

    public String getFilterCondition() {
        return filterCondition;
    }

    public void setFilterCondition(String filterCondition) {
        this.filterCondition = filterCondition;
    }

    public BusinessDayBehaviorEnum getBusinessDayBehavior() {
        return businessDayBehavior;
    }

    public void setBusinessDayBehavior(BusinessDayBehaviorEnum businessDayBehavior) {
        this.businessDayBehavior = businessDayBehavior;
    }

    @Override
    public String toString() {
        return "DataTransferSpecificationVO [sourceDatabase=" + sourceDatabase + ", destinationDatabase="
                + destinationDatabase + ", sourceTable=" + sourceTable + ", sourceTablePartitionName="
                + sourceTablePartitionName + ", destinationTable=" + destinationTable + ", columns=" + columns
                + ", filterCondition=" + filterCondition + ", businessDayBehavior=" + businessDayBehavior + "]";
    }
}
