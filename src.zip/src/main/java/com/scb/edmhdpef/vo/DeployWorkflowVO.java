package com.scb.edmhdpef.vo;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class DeployWorkflowVO {

	private String workflowName;
	private Boolean createFilesInHDFS;

	public String getWorkflowName() {
		return workflowName;
	}

	public void setWorkflowName(String workflowName) {
		this.workflowName = workflowName;
	}

	public Boolean getCreateFilesInHDFS() {
		return createFilesInHDFS;
	}

	public void setCreateFilesInHDFS(Boolean createScripts) {
		this.createFilesInHDFS = createScripts;
	}

	@Override
	public String toString() {
		return "DeployWorkflowVO [workflowName=" + workflowName
				+ ", createFilesInHDFS=" + createFilesInHDFS + "]";
	}

}
