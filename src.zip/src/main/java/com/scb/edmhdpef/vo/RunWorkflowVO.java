package com.scb.edmhdpef.vo;

import java.util.Map;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class RunWorkflowVO {

	private String workflow;

	private Map<String, String> params;

	public String getWorkflow() {
		return workflow;
	}

	public void setWorkflow(String workflow) {
		this.workflow = workflow;
	}

	public Map<String, String> getParams() {
		return params;
	}

	public void setParams(Map<String, String> params) {
		this.params = params;
	}

	@Override
	public String toString() {
		return "RunWorkflowVO [workflow=" + workflow + ", params=" + params
				+ "]";
	}
}
