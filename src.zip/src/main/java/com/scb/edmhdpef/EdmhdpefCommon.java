package com.scb.edmhdpef;

import java.io.StringWriter;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import org.springframework.security.core.context.SecurityContextHolder;

import com.scb.edmhdpef.entity.DataTransferSpecification;
import com.scb.edmhdpef.entity.EdmWorkflow;
import com.scb.edmhdpef.enums.BusinessDayBehaviorEnum;
import com.scb.edmhdpef.enums.EdmWorkflowTypeEnum;
import com.scb.edmhdpef.exceptions.EdmHdpEfInternalException;
import com.scb.edmhdpef.exceptions.EdmHdpEfInternalException.InternalExceptionCode;

public class EdmhdpefCommon {

    private static final String ACTION_SOURCE_NAME = "Source-";
    private static final String ACTION_DATA_PROCESSING_NAME = "DataProcessing-";
    private static final String ACTION_DESTINATION_NAME = "Destination-";

    public static String toXML(Object obj) throws JAXBException {
        return toXML(obj, true);
    }

    public static String toXML(Object obj, boolean formatted) throws JAXBException {
        JAXBContext context = JAXBContext.newInstance(obj.getClass());
        Marshaller m = context.createMarshaller();
        m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, formatted);

        StringWriter writer = new StringWriter();
        m.marshal(obj, writer);
        return writer.toString();
    }

    public static void validateWorkflowForDeployment(EdmWorkflow workflow) throws EdmHdpEfInternalException {

        if (workflow == null) {
            throw new EdmHdpEfInternalException(InternalExceptionCode.ERROR_CREATING_CONFIG_FILES,
                    "Workflow not specified.");
        }

        if (workflow.getName() == null || workflow.getName().isEmpty()) {
            throw new EdmHdpEfInternalException(InternalExceptionCode.ERROR_CREATING_CONFIG_FILES,
                    "Workflow name not specified.");
        }
        if (workflow.getType() == null) {
            throw new EdmHdpEfInternalException(InternalExceptionCode.ERROR_CREATING_CONFIG_FILES,
                    "Workflow type not specified.");
        }
        if (workflow.getSource() == null) {
            throw new EdmHdpEfInternalException(InternalExceptionCode.ERROR_CREATING_CONFIG_FILES,
                    "Workflow source not specified.");
        }
        if (workflow.getSource().getType() == null) {
            throw new EdmHdpEfInternalException(InternalExceptionCode.ERROR_CREATING_CONFIG_FILES,
                    "Workflow source type not specified.");
        }

        if (workflow.getDestination() == null) {
            throw new EdmHdpEfInternalException(InternalExceptionCode.ERROR_CREATING_CONFIG_FILES,
                    "Workflow destination not specified.");
        }
        if (workflow.getDestination().getType() == null) {
            throw new EdmHdpEfInternalException(InternalExceptionCode.ERROR_CREATING_CONFIG_FILES,
                    "Workflow destination type not specified.");
        }

        if (workflow.getDataTransferSpecification() == null || workflow.getDataTransferSpecification().isEmpty()) {
            throw new EdmHdpEfInternalException(InternalExceptionCode.ERROR_CREATING_CONFIG_FILES,
                    "Workflow data transfer specification not specified.");
        }
    }

    public static String getUser() {
        if (SecurityContextHolder.getContext() == null
                || SecurityContextHolder.getContext().getAuthentication() == null
                || SecurityContextHolder.getContext().getAuthentication().getName() == null) {
            return System.getProperty("user.name");
        }
        return SecurityContextHolder.getContext().getAuthentication().getName();
    }

    public static String getSourceActionName(EdmWorkflow workflow) {
        return ACTION_SOURCE_NAME + workflow.getSource().getType();
    }

    public static String getDataProcessingActionName(EdmWorkflow workflow, int count) {
        if (count == 0) {
            return ACTION_DATA_PROCESSING_NAME + workflow.getProcessing().get(0).getType();
        }
        return ACTION_DATA_PROCESSING_NAME + workflow.getProcessing().get(count).getType() + "-" + count;
    }

    public static String getDestinationActionName(EdmWorkflow workflow) {
        return ACTION_DESTINATION_NAME + workflow.getDestination().getType();
    }

    public static boolean isBusinessDayRequired(EdmWorkflow workflow) {
        if (workflow == null || workflow.getDataTransferSpecification() == null
                || workflow.getDataTransferSpecification().isEmpty()) {
            return false;
        }
        if (!EdmWorkflowTypeEnum.TABLE_GROUP.equals(workflow.getType())) {
            return false;
        }
        for (DataTransferSpecification spec : workflow.getDataTransferSpecification()) {
            if (spec.getBusinessDayBehavior() != null
                    && !BusinessDayBehaviorEnum.NO.equals(spec.getBusinessDayBehavior())) {
                return true;
            }
        }
        return false;
    }
}
