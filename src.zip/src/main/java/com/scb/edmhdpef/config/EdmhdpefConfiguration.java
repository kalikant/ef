package com.scb.edmhdpef.config;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;

import javax.sql.DataSource;

import org.dozer.DozerBeanMapper;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.config.PropertiesFactoryBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.DependsOn;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.orm.hibernate4.HibernateTransactionManager;
import org.springframework.orm.hibernate4.LocalSessionFactoryBean;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.view.freemarker.FreeMarkerConfigurer;

import com.mchange.v2.c3p0.ComboPooledDataSource;

@Configuration
@ComponentScan(basePackages = { "com.scb.edmhdpef.*" })
@EnableWebMvc
@EnableTransactionManagement
@EnableAsync
@EnableScheduling
public class EdmhdpefConfiguration {

	@Value("${db.connection.url}")
	private String dbConnectionURL;

	@Value("${db.driver.name}")
	private String dbDriverName;

	@Bean
	public static PropertySourcesPlaceholderConfigurer getPropertySourcesPlaceholderConfigurer() throws IOException {
		PropertySourcesPlaceholderConfigurer ppc = new PropertySourcesPlaceholderConfigurer();
		ppc.setLocations(getResources());
		ppc.setIgnoreUnresolvablePlaceholders(true);
		return ppc;
	}

	@Bean
	@DependsOn
	public DataSource dataSource() throws Exception {
		ComboPooledDataSource dataSource = new ComboPooledDataSource();
		dataSource.setDriverClass(dbDriverName);
		dataSource.setJdbcUrl(dbConnectionURL);

		return dataSource;
	}

	@Bean
	public PlatformTransactionManager txManager() throws Exception {
		return new HibernateTransactionManager(sessionFactory());
	}

	@Bean
	public SessionFactory sessionFactory() throws Exception {
		LocalSessionFactoryBean sessionFactory = new org.springframework.orm.hibernate4.LocalSessionFactoryBean();
		sessionFactory.setDataSource(dataSource());
		sessionFactory.setHibernateProperties(hibernateProperties());
		sessionFactory.setPackagesToScan(new String[] { "com.scb.edmhdpef.entity" });

		sessionFactory.afterPropertiesSet();
		return sessionFactory.getObject();
	}

	@Bean
	public static Properties hibernateProperties() throws Exception {
		PropertiesFactoryBean propertiesBean = new PropertiesFactoryBean();
		propertiesBean.setLocations(getResources());
		propertiesBean.setIgnoreResourceNotFound(true);
		propertiesBean.afterPropertiesSet();

		return propertiesBean.getObject();
	}

	@Bean
	public DozerBeanMapper mappingService() {
		DozerBeanMapper mappingService = new DozerBeanMapper();
		List<String> mappingFileUrls = new ArrayList<String>();
		mappingFileUrls.add("dozer-bean-mappings.xml");
		mappingService.setMappingFiles(mappingFileUrls);
		return mappingService;
	}

	@Bean
	public FreeMarkerConfigurer freeMarkerConfig() {
		FreeMarkerConfigurer freeMarkerConfig = new FreeMarkerConfigurer();
		freeMarkerConfig.setTemplateLoaderPath("classpath:templates");
		return freeMarkerConfig;
	}

	private static Resource[] getResources() throws IOException {
		List<Resource> resources = new ArrayList<Resource>();
		resources.addAll(
				Arrays.asList(new PathMatchingResourcePatternResolver().getResources("classpath:*.properties")));
		resources.addAll(Arrays
				.asList(new PathMatchingResourcePatternResolver().getResources("file:/etc/edmhdpef/*.properties")));
		return resources.toArray(new Resource[resources.size()]);
	}
}
