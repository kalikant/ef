package com.scb.edmhdpef.filters;

import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.filter.DelegatingFilterProxy;

import javax.servlet.*;
import java.io.IOException;

/**
 * ganesh@thedatateam.in on 23-11-2015.
 * <p/>
 * This proxy filter ensures all except crypto requests succeed only for authorized principals
 */
public class DelegatingFilterProxyImpl extends DelegatingFilterProxy {
    /**
     * used to fetch the REST port we are listening on from the very first request.
     */
    public static int port = 0;
    public static String host = "";

    public DelegatingFilterProxyImpl() {
    }

    public DelegatingFilterProxyImpl(Filter delegate) {
        super(delegate);
    }

    public DelegatingFilterProxyImpl(String targetBeanName) {
        super(targetBeanName);
    }

    public DelegatingFilterProxyImpl(String targetBeanName, WebApplicationContext wac) {
        super(targetBeanName, wac);
    }

    /**
     * Send through all requests except crypto ones!
     *
     * @param request
     * @param response
     * @param filterChain
     * @throws ServletException
     * @throws IOException
     */
    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain filterChain)
            throws ServletException, IOException {
        if (port == 0) port = request.getServerPort();
        super.doFilter(request, response, filterChain);

    }

}
