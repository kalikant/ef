package com.scb.edmhdpef.controller;

import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.scb.edmhdpef.entity.EdmWorkflow;
import com.scb.edmhdpef.entity.WorkflowExecution;
import com.scb.edmhdpef.exceptions.EdmHdpEfAppException;
import com.scb.edmhdpef.exceptions.EdmHdpEfInternalException;
import com.scb.edmhdpef.exceptions.EdmHdpEfNotImplementedException;
import com.scb.edmhdpef.services.execution.ExecutionService;
import com.scb.edmhdpef.vo.DeployWorkflowVO;
import com.scb.edmhdpef.vo.DeploymentFileListVO;
import com.scb.edmhdpef.vo.DeploymentFileVO;
import com.scb.edmhdpef.vo.RunWorkflowVO;
import com.scb.edmhdpef.vo.WorkflowExecutionListVO;
import com.scb.edmhdpef.vo.WorkflowStatusVO;

@RestController
public class ExecutionController {

	@Resource(name = "executionService")
	private ExecutionService executionService;

	private static final Logger logger = Logger.getLogger(ExecutionController.class);

	@RequestMapping(value = "/execution/deploy", method = { RequestMethod.POST })
	public DeploymentFileListVO deployWorkFlow(@RequestBody DeployWorkflowVO deployWorkflowVO)
			throws EdmHdpEfAppException, EdmHdpEfInternalException, EdmHdpEfNotImplementedException {
		logger.info("ExecutionSchedule:" + deployWorkflowVO);
		Map<String, String> files = executionService.deployWorkflow(deployWorkflowVO);
		// return files;
		DeploymentFileListVO scriptFileList = new DeploymentFileListVO();
		for (Entry<String, String> entry : files.entrySet()) {
			DeploymentFileVO file = new DeploymentFileVO();
			file.setFileName(entry.getKey());
			for (String line : entry.getValue().split("\n")) {
				file.getFileContent().add(line);
			}
			scriptFileList.getFiles().add(file);
		}
		logger.info("Finished ExecutionSchedule:" + scriptFileList);
		return cleanPassword(scriptFileList);
	}

	@RequestMapping(value = "/execution/run", method = { RequestMethod.POST })
	public WorkflowExecution runWorkflow(@RequestBody RunWorkflowVO runWorkflow)
			throws EdmHdpEfAppException, EdmHdpEfInternalException {
		logger.info("RunWorkflow:" + runWorkflow);
		WorkflowExecution execution = new WorkflowExecution();
		execution.setWorkflow(new EdmWorkflow());
		execution.getWorkflow().setName(runWorkflow.getWorkflow());
		execution.setParameters(runWorkflow.getParams());
		WorkflowExecution ex = this.executionService.runWorkflow(execution);
		logger.info("Finished RunWorkflow:" + ex.getWorkflow().getName() + ". Job Id: " + ex.getJobId());
		return ex;
	}

	@RequestMapping(value = "/execution/status", method = { RequestMethod.POST })
	public WorkflowExecutionListVO queryStatus(@RequestBody WorkflowStatusVO status)
			throws EdmHdpEfAppException, EdmHdpEfInternalException {
		logger.info("QueryStatus:" + status);
		WorkflowExecution execution = new WorkflowExecution();
		execution.setJobId(status.getJobId());
		if (status.getWorkflowName() != null) {
			execution.setWorkflow(new EdmWorkflow());
			execution.getWorkflow().setName(status.getWorkflowName());
		}
		List<WorkflowExecution> executionList = this.executionService.queryStatus(execution);
		WorkflowExecutionListVO listVO = new WorkflowExecutionListVO();
		listVO.setExecutionList(executionList);
		logger.info("Finished QueryStatus:" + listVO);
		return listVO;
	}

	private DeploymentFileListVO cleanPassword(DeploymentFileListVO scriptFileList) {
		if (scriptFileList == null || scriptFileList.getFiles() == null) {
			return scriptFileList;
		}

		for (DeploymentFileVO file : scriptFileList.getFiles()) {
			List<String> content = file.getFileContent();
			if (content == null) {
				continue;
			}
			for (int i = 0; i < content.size(); i++) {
				content.set(i, content.get(i).replaceAll("ENC\\([^\\)]*\\)", "[ENCODED]"));
			}
		}
		return scriptFileList;
	}
}
