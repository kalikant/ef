package com.scb.edmhdpef.controller;

import java.io.IOException;
import java.util.Properties;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class AdminController {

    @RequestMapping(value = "/admin/version", method = { RequestMethod.GET })
    public String getVersion() {
        String version = getClass().getPackage().getImplementationVersion();
        if (version == null) {
            Properties prop = new Properties();
            try {
                prop.load(this.getClass().getResourceAsStream("/META-INF/maven/com.scb/edmhdpef/pom.properties"));
                version = prop.getProperty("version");
            } catch (IOException e) {
            }
        }
        return "Edmhdpef server version " + version;
    }
}
