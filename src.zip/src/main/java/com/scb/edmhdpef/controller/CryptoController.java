package com.scb.edmhdpef.controller;

import com.scb.edmhdpef.exceptions.EdmHdpEfInternalException;
import com.scb.edmhdpef.services.architecture.security.EncryptionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;

@RestController
public class CryptoController {

	public static final String PASSWORD = "password";
	@Autowired
	private EncryptionService encryptionService;

	@RequestMapping(value = "/crypto/encrypt", method = { RequestMethod.GET })
	public @ResponseBody
	String encrypt(@RequestParam("data") String plain) throws EdmHdpEfInternalException {
		HashMap<String, String> parameters = new HashMap<>();
		parameters.put(PASSWORD,plain);
		return encryptionService.encryptParameters(parameters).get(PASSWORD);
	}


	@RequestMapping(value = "/crypto/decrypt", method = { RequestMethod.GET })
	public @ResponseBody
	String decrypt(@RequestParam("data") String decoded) throws EdmHdpEfInternalException {
		HashMap<String, String> parameters = new HashMap<>();
		parameters.put(PASSWORD,decoded);
		return encryptionService.decryptParameters(parameters).get(PASSWORD);
	}

	public EncryptionService getEncryptionService() {
		return encryptionService;
	}

	public void setEncryptionService(EncryptionService encryptionService) {
		this.encryptionService = encryptionService;
	}
}
