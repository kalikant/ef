package com.scb.edmhdpef.controller;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.dozer.DozerBeanMapper;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.scb.edmhdpef.entity.EdmWorkflow;
import com.scb.edmhdpef.exceptions.EdmHdpEfAppException;
import com.scb.edmhdpef.exceptions.EdmHdpEfInternalException;
import com.scb.edmhdpef.exceptions.EdmHdpEfNotImplementedException;
import com.scb.edmhdpef.services.configuration.WorkflowConfigService;
import com.scb.edmhdpef.vo.WorkflowDefinitionVO;
import com.scb.edmhdpef.vo.WorkflowVOList;

@RestController
public class WorkflowController {

	@Resource(name = "workflowConfigService")
	private WorkflowConfigService workflowConfigService;

	@Resource
	private DozerBeanMapper mappingService;

	private static final Logger logger = Logger.getLogger(WorkflowController.class);

	@RequestMapping(value = "/workflow", method = { RequestMethod.PUT })
	public WorkflowDefinitionVO createWorkflow(@RequestBody WorkflowDefinitionVO workflow)
			throws EdmHdpEfAppException, EdmHdpEfInternalException, EdmHdpEfNotImplementedException {
		logger.info("WorkflowCreate:" + workflow.getName());
		WorkflowDefinitionVO wf = this.mappingService.map(
				this.workflowConfigService.createWorkflow(this.mappingService.map(workflow, EdmWorkflow.class)),
				WorkflowDefinitionVO.class);
		logger.info("Finished WorkflowCreate:" + (wf == null ? null : wf.getName()));
		return wf;
	}

	@RequestMapping(value = "/workflow/{name}", method = { RequestMethod.DELETE })
	public String deleteWorkflow(@PathVariable String name) throws EdmHdpEfAppException, EdmHdpEfInternalException {
		logger.info("WorkflowDelete:" + name);
		EdmWorkflow wf = new EdmWorkflow();
		wf.setName(name);
		this.workflowConfigService.deleteWorkflow(wf);
		logger.info("Finished WorkflowDelete " + name);
		return Boolean.TRUE.toString();
	}

	@RequestMapping(value = "/workflow", method = { RequestMethod.POST })
	public WorkflowDefinitionVO updateWorkflow(@RequestBody WorkflowDefinitionVO workflow)
			throws EdmHdpEfAppException, EdmHdpEfInternalException, EdmHdpEfNotImplementedException {
		logger.info("WorkflowUpdate:" + workflow.getName());
		EdmWorkflow updatedWorkflow = this.workflowConfigService
				.updateWorkflow(this.mappingService.map(workflow, EdmWorkflow.class));
		WorkflowDefinitionVO wf = this.mappingService.map(updatedWorkflow, WorkflowDefinitionVO.class);
		logger.info("Finished WorkflowUpdate:" + (wf == null ? null : wf.getName()));
		return wf;
	}

	@RequestMapping(value = "/workflow", method = { RequestMethod.GET })
	public WorkflowVOList listWorkflow() {
		logger.info("WorkflowList all");
		EdmWorkflow workflow = new EdmWorkflow();
		List<WorkflowDefinitionVO> wfDefList = new ArrayList<WorkflowDefinitionVO>();
		List<EdmWorkflow> workflowList = this.workflowConfigService.retrieveWorkflows(workflow);
		for (EdmWorkflow wf : workflowList) {
			if (wf != null) {
				wfDefList.add(this.mappingService.map(wf, WorkflowDefinitionVO.class));
			}
		}
		logger.info("Finished WorkflowList:" + wfDefList.size() + " results.");
		if (wfDefList.isEmpty()) {
			return null;
		}
		WorkflowVOList returnWOList = new WorkflowVOList();
		returnWOList.setWorkflowList(wfDefList);
		return returnWOList;
	}

	@RequestMapping(value = "/workflow/{name}", method = { RequestMethod.GET })
	public WorkflowVOList listWorkflow(@PathVariable String name) {
		logger.info("WorkflowList:" + name);
		EdmWorkflow workflow = new EdmWorkflow();
		workflow.setName(name);
		List<WorkflowDefinitionVO> wfDefList = new ArrayList<WorkflowDefinitionVO>();
		List<EdmWorkflow> workflowList = this.workflowConfigService.retrieveWorkflows(workflow);
		for (EdmWorkflow wf : workflowList) {
			if (wf != null) {
				wfDefList.add(this.mappingService.map(wf, WorkflowDefinitionVO.class));
			}
		}
		logger.info("Finished WorkflowList:" + wfDefList.size() + " results.");
		if (wfDefList.isEmpty()) {
			return null;
		}
		WorkflowVOList returnWOList = new WorkflowVOList();
		returnWOList.setWorkflowList(wfDefList);
		return returnWOList;
	}
}
