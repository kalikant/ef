package com.scb.edmhdpef.controller;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.scb.edmhdpef.entity.EdmDataSource;
import com.scb.edmhdpef.exceptions.EdmHdpEfAppException;
import com.scb.edmhdpef.exceptions.EdmHdpEfInternalException;
import com.scb.edmhdpef.exceptions.EdmHdpEfNotImplementedException;
import com.scb.edmhdpef.services.configuration.DatasourceConfigService;
import com.scb.edmhdpef.vo.DataSourceListVO;

@RestController
public class DataSourceController {

	@Resource
	private DatasourceConfigService datasourceConfigService;

	private static final Logger logger = Logger.getLogger(DataSourceController.class);

	@RequestMapping(value = "/datasource", method = { RequestMethod.PUT })
	public EdmDataSource createDataSource(@RequestBody EdmDataSource datasource)
			throws EdmHdpEfAppException, EdmHdpEfNotImplementedException, EdmHdpEfInternalException {
		logger.info("CreateDataSource:" + datasource.getName());
		EdmDataSource ds = cleanPassword(this.datasourceConfigService.createDataSource(datasource));
		logger.info("Finished CreateDataSource:" + (ds == null ? null : ds.getName()));
		return ds;
	}

	@RequestMapping(value = "/datasource/{name}", method = { RequestMethod.DELETE })
	public String deleteDataSource(@PathVariable String name) throws EdmHdpEfAppException, EdmHdpEfInternalException {
		logger.info("DeleteDataSource:" + name);
		EdmDataSource datasource = new EdmDataSource();
		datasource.setName(name);
		this.datasourceConfigService.deleteDataSource(datasource);
		logger.info("Finished DeleteDataSource " + name);
		return Boolean.TRUE.toString();
	}

	@RequestMapping(value = "/datasource", method = { RequestMethod.POST })
	public EdmDataSource updateDataSource(@RequestBody EdmDataSource datasource)
			throws EdmHdpEfAppException, EdmHdpEfNotImplementedException, EdmHdpEfInternalException {
		logger.info("UpdateDataSource:" + datasource.getName());
		EdmDataSource ds = cleanPassword(this.datasourceConfigService.updateDataSource(datasource));
		logger.info("Finished UpdateDataSource:" + (ds == null ? null : ds.getName()));
		return ds;
	}

	@RequestMapping(value = "/datasource", method = { RequestMethod.GET })
	public DataSourceListVO listDataSource() {
		logger.info("List all DataSources");
		List<EdmDataSource> ds = cleanPassword(this.datasourceConfigService.retrieveDataSources(null));
		logger.info("Finished ListDataSource:" + ds.size() + " results.");
		if (ds.isEmpty()) {
			return null;
		}
		DataSourceListVO returnList = new DataSourceListVO();
		returnList.setDatasources(ds);
		return returnList;
	}

	@RequestMapping(value = "/datasource/{name}", method = { RequestMethod.GET })
	public DataSourceListVO listDataSource(@PathVariable String name) {
		logger.info("ListDataSource:" + name);
		EdmDataSource datasource = new EdmDataSource();
		datasource.setName(name);
		List<EdmDataSource> ds = cleanPassword(this.datasourceConfigService.retrieveDataSources(datasource));
		logger.info("Finished ListDataSource:" + ds.size() + " results.");
		if (ds.isEmpty()) {
			return null;
		}
		DataSourceListVO returnList = new DataSourceListVO();
		returnList.setDatasources(ds);
		return returnList;
	}

	private List<EdmDataSource> cleanPassword(List<EdmDataSource> dataSourceList) {
		List<EdmDataSource> returnList = new ArrayList<EdmDataSource>(dataSourceList.size());
		for (EdmDataSource ds : dataSourceList) {
			returnList.add(cleanPassword(ds));
		}
		return returnList;
	}

	private EdmDataSource cleanPassword(EdmDataSource dataSource) {
		if (dataSource == null || dataSource.getParameters() == null) {
			return dataSource;
		}
		Set<String> passwords = new HashSet<String>();
		for (Entry<String, String> param : dataSource.getParameters().entrySet()) {
			if (param.getKey().contains("password") && param.getValue().startsWith("ENC(")
					&& param.getValue().endsWith(")")) {
				passwords.add(param.getKey());
			}
		}
		for (String param : passwords) {
			dataSource.getParameters().put(param, "[ENCODED]");
		}
		return dataSource;
	}
}
