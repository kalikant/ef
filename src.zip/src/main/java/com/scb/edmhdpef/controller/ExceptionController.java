package com.scb.edmhdpef.controller;

import javax.servlet.http.HttpServletResponse;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.scb.edmhdpef.exceptions.EdmHdpEfAppException;
import com.scb.edmhdpef.exceptions.EdmHdpEfInternalException;
import com.scb.edmhdpef.exceptions.EdmHdpEfNotImplementedException;

@ControllerAdvice
public class ExceptionController {

	@ExceptionHandler(EdmHdpEfAppException.class)
	@ResponseStatus(value = HttpStatus.BAD_REQUEST)
	@ResponseBody
	public String handleAPIException(EdmHdpEfAppException e,
			HttpServletResponse response) {
		return "Message: " + e.getMessage() + "\nError code: " + e.getCode()
				+ " (" + e.getCode().getType() + ')';
	}

	@ExceptionHandler(EdmHdpEfInternalException.class)
	@ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR)
	@ResponseBody
	public String handleAPIException(EdmHdpEfInternalException e,
			HttpServletResponse response) {
		return "Message: " + e.getMessage() + "\nError code: " + e.getCode()
				+ " (" + e.getCode().getType() + ')';
	}

	@ExceptionHandler(EdmHdpEfNotImplementedException.class)
	@ResponseStatus(value = HttpStatus.NOT_IMPLEMENTED)
	@ResponseBody
	public String handleAPIException(EdmHdpEfNotImplementedException e,
			HttpServletResponse response) {
		return "Message: " + e.getMessage();
	}

}
