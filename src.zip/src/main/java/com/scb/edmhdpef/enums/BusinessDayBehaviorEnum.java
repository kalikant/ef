package com.scb.edmhdpef.enums;

public enum BusinessDayBehaviorEnum {
	NO, LATEST, ALL
}
