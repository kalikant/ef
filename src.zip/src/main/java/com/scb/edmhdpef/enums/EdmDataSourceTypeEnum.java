package com.scb.edmhdpef.enums;

public enum EdmDataSourceTypeEnum {
	HIVE, TERADATA, HDFS
}
