package com.scb.edmhdpef.enums;

public enum DataProcessingType {
	TRIMMED_SRI, HEADER_AND_FOOTER
}
