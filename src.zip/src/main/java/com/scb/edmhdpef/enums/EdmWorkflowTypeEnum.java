package com.scb.edmhdpef.enums;

public enum EdmWorkflowTypeEnum {
	GENERIC, TABLE_GROUP
}
