#!/usr/bin/env bash
pushd .
cd ../../../../EdmhdpefCLI/
mvn -Dmaven.test.skip=true clean install
cp -Rf ../lib target/
export CLASSPATH='../../../../EdmhdpefCLI/target/*'
popd
bash -x edmhdpef-cli $*

