#!/bin/bash
pushd .
cd ../../../../
mvn -Dmaven.test.skip=true clean install
cp -Rf lib/ target/
#cp target/*.jar target/lib/
mvn -Dmaven.test.skip=true war:war
popd
