AMBARISERVER=http://localhost:8080
CLUSTERNAME=sandbox
SERVICENAME=EDMHDPEF
COMPONENT=EDMHDPEF_SERVER
HOST=sandbox.hortonworks.com
PROPERTIES=edmhdpef.properties
PROPERTIESVERSION=version3

# Delete service and config
curl -u admin:admin -i -H "X-Requested-By:ambari" -X DELETE $AMBARISERVER/api/v1/clusters/$CLUSTERNAME/services/$SERVICENAME

# Create service
curl -u admin:admin -i -H "X-Requested-By:ambari" -X POST -d '{"ServiceInfo":{"service_name":"'$SERVICENAME'"}}' $AMBARISERVER/api/v1/clusters/$CLUSTERNAME/services/
# Do for all components
curl -u admin:admin -i -H "X-Requested-By:ambari" -X POST $AMBARISERVER/api/v1/clusters/$CLUSTERNAME/services/$SERVICENAME/components/$COMPONENT

# Do for all hosts and components
#curl -u admin:admin -i -H "X-Requested-By:ambari" -X POST $AMBARISERVER/api/v1/clusters/$CLUSTERNAME/hosts/$HOST/host_components/$COMPONENT
curl -u admin:admin -i -H "X-Requested-By:ambari" -X POST -d '{"host_components" : [{"HostRoles":{"component_name":"'$COMPONENT'", "stale_configs" : "true"}}] }' $AMBARISERVER/api/v1/clusters/$CLUSTERNAME/hosts?Hosts/host_name=$HOST

# Configuration parameters
QUERY='{"Clusters" : {"desired_configs": {"type": "'$PROPERTIES'", "tag" : "'$PROPERTIESVERSION'", "properties" : '`cat /var/lib/ambari-server/resources/stacks/HDP/2.1/services/EDMHDPEF/configuration/edmhdpef.properties.json`' }}}'
curl -u admin:admin -i -H "X-Requested-By:ambari" -X PUT -d "$QUERY" $AMBARISERVER/api/v1/clusters/$CLUSTERNAME

# Install
curl -u admin:admin -i -H "X-Requested-By:ambari" -X PUT -d '{ "RequestInfo": {"context": "Install EDM Hadoop Extraction Framework"}, "Body": {"ServiceInfo": {"state": "INSTALLED"}}}' $AMBARISERVER/api/v1/clusters/$CLUSTERNAME/services/$SERVICENAME

# Configure
curl -u admin:admin -i -H "X-Requested-By:ambari" -X POST -d '{ "RequestInfo" : {"command" : "CONFIGURE", "context" : "Config EDM Hadoop Extraction Framework"}, "Requests/resource_filters": [{"service_name" : "'${SERVICENAME}'", "component_name" : "'${COMPONENT}'", "hosts" : "'${HOST}'"}]}' $AMBARISERVER/api/v1/clusters/$CLUSTERNAME/requests

# Start
curl -u admin:admin -i -H "X-Requested-By:ambari" -X PUT -d '{ "RequestInfo": {"context": "Starting EDM Hadoop Extraction Framework"}, "Body": {"ServiceInfo": {"state": "STARTED"}}}' $AMBARISERVER/api/v1/clusters/$CLUSTERNAME/services/$SERVICENAME

# Check things
# curl -u admin:admin -i -H "X-Requested-By:ambari" -X GET $AMBARISERVER/api/v1/clusters/$CLUSTERNAME/configurations
# curl -u admin:admin -i -H "X-Requested-By:ambari" -X GET $AMBARISERVER/api/v1/clusters/$CLUSTERNAME/services/$SERVICENAME
# curl -u admin:admin -i -H "X-Requested-By:ambari" -X GET $AMBARISERVER/api/v1/clusters/$CLUSTERNAME/services/$SERVICENAME/components/$COMPONENT
# curl -u admin:admin -i -H "X-Requested-By:ambari" -X GET $AMBARISERVER/api/v1/clusters/$CLUSTERNAME/hosts/$HOST/host_components/$COMPONENT