from resource_management import *

def edmhdpef(action = None):
  import params
  env.set_params(params)
  
  if action == 'config':
    Directory(params.edmhdpef_pid_dir,
              owner=params.edmhdpef_user
    )
    Directory(params.edmhdpef_log_dir,
              owner=params.edmhdpef_user
    )
    Directory(params.edmhdpef_home,
              owner=params.edmhdpef_user
    )
    PropertiesFile(params.edmhdpef_conf_dir + '/edmhdpef.properties',
                   properties=params.global_properties,
                   mode=0644
    )
  if action == 'start':
    Execute(format('{edmhdpef_home}/bin/edmhdpef-start {edmhdpef_home}/bin {edmhdpef_port}'),
            user=params.edmhdpef_user
    )
  if action == 'stop':
    Execute(format('{edmhdpef_home}/bin/edmhdpef-stop'),
            user=params.edmhdpef_user
    )
    File(params.server_pid_file,
         action='delete'
    )
