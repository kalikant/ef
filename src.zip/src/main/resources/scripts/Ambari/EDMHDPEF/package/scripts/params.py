from resource_management import *

config = Script.get_config()

edmhdpef_user = config['configurations']['edmhdpef.properties']['edmhdpef_user']
user_group = config['configurations']['edmhdpef.properties']['user_group']
proxyuser_group =  config['configurations']['edmhdpef.properties']['proxyuser_group']

java_home = config['hostLevelParams']['java_home']
edmhdpef_cluster_java_path = java_home

edmhdpef_home = '/usr/lib/edmhdpef'
edmhdpef_pid_dir = '/var/run/edmhdpef'
edmhdpef_conf_dir = '/etc/edmhdpef'
edmhdpef_log_dir = '/var/log/edmhdpef'
store_uri = config['configurations']['edmhdpef-startup.properties']['*.config.store.uri']
server_pid_file = 'edmhdpef.pid'

edmhdpef_host = config['clusterHostInfo']['edmhdpef_server_hosts'][0]
edmhdpef_port = config['configurations']['edmhdpef.properties']['edmhdpef_port']
global_properties = config['configurations']['edmhdpef.properties']

