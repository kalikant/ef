from resource_management import *


class EdmhdpefServiceCheck(Script):

  def service_check(self, env):
    import params

    env.set_params(params)
    Execute(format("{edmhdpef_home}/bin/edmhdpef-cli version"),
            user=params.edmhdpef_user,
            logoutput=True,
            tries = 3,
            try_sleep = 20
    )

if __name__ == "__main__":
  EdmhdpefServiceCheck().execute()
