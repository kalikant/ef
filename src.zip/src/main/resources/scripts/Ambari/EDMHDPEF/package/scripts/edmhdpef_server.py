from resource_management import *
from edmhdpef import edmhdpef

class EdmhdpefServer(Script):
	def install(self, env):
		import params

	def start(self, env):
		import params

		env.set_params(params)
		self.configure(env)

		edmhdpef(action='start')

	def stop(self, env):
		import params

		env.set_params(params)

		edmhdpef(action='stop')

	def configure(self, env):
		import params

		env.set_params(params)

		edmhdpef(action='config')

	def status(self, env):
		import params

		env.set_params(params)
		check_process_status(params.server_pid_file)


if __name__ == "__main__":
	EdmhdpefServer().execute()
