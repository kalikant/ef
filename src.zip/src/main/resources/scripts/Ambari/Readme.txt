1) Copy the folder EDMHDPEF into /var/lib/ambari-server/resources/stacks/HDP/2.1/services on the server running Ambari and Edmhdpef
2) Restart Ambari
3) Modify the variables at the start of install.sh and run the script
