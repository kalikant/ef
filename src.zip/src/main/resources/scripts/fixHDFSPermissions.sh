# All Hive tables created by edmhdpef need to be provided permissions at both Hive and HDFS level. The createHiveTables.sql takes care of the Hive permissions for the same.

#from hive-site.xml
HIVE_WAREHOUSE=${hive.metastore.warehouse.dir}

#from /etc/edmhdpef/application.properties
EDMHDPEF_HIVE_DB=${edmhdpef.hive.database}

hadoop fs -chmod -R a+w ${HIVE_WAREHOUSE}/${EDMHDPEF_HIVE_DB}.db/rowcounts
hadoop fs -chmod -R a+w ${HIVE_WAREHOUSE}/${EDMHDPEF_HIVE_DB}.db/workflowexecutions
hadoop fs -chmod -R a+w ${HIVE_WAREHOUSE}/${EDMHDPEF_HIVE_DB}.db/entitieslog
