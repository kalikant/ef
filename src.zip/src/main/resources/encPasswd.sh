curl --user ' ':' ' http://localhost:12001/crypto/encrypt/?data=$1
