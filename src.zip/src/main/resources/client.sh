java -cp "edmhdpef-cli-0.0.1.jar:lib/*:$CLASSPATH:/usr/lib/oozie/lib/*:/usr/lib/hadoop/*:/usr/lib/hadoop/lib/*" com.scb.edmhdpef.client.EdmhdpefClient "$@" --server http://localhost:12200
