#!/bin/bash -e

export HADOOP_USER_NAME=${shell_username}

MAX_PARTITION=`hive -S -e "select if(isnull(max(partition_name)),'',max(partition_name)) from ${r"${STORAGE}"}.${r"${SOURCE}"}_${r"${COUNTRY}"}_batch_to_partition where batch_date='${r"${BUSINESS_DAY}"}'"`

if [[ ! -z ${r"${MAX_PARTITION}"} ]]
then
    echo "edmhdpef.ebbs_to_teradata.max_partition_for_business_day=${r"${MAX_PARTITION}"}"
fi

ALL_PARTITIONS_ARRAY=`hive -S -e "select collect_list(partition_name) from ${r"${STORAGE}"}.${r"${SOURCE}"}_${r"${COUNTRY}"}_batch_to_partition where batch_date='${r"${BUSINESS_DAY}"}' group by batch_date"`

ALL_PARTITIONS=`echo ${r"${ALL_PARTITIONS_ARRAY}"} | sed -e "s/\[\(.*\)\]/\1/" | sed -e "s/\"/'/g"` 
if [[ ! -z ${r"${ALL_PARTITIONS}"} ]]
then
    echo "edmhdpef.ebbs_to_teradata.all_partitions_for_business_day=${r"${ALL_PARTITIONS}"}"
fi
