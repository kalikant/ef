-- Step 1: Create temp table on TD with unique name (e.g. by affixing a random number like a job ID)
create table tmp_19822809(tablename varchar(100), rawdata varchar(64000)) primary index(tablename);

-- Step 2: TDCH Load to tmp_19822809 table
-- Doesnt happen here

-- Step 3: Load to destination tables one at a time by doing an index lookup on table name
-- and also string tokenixing each column. There would be as many INSERT/SELECTs as there
-- are tables in that group
insert into decimal_test_table(jt,txid,optype,userid,systemid,currency,checkdt)
select 
	raw,
	cast(strtok(rawdata,'01'XC,1) as CHAR(100)) as c_journaltime
	,cast(strtok(rawdata,'01'XC,2) as CHAR(100)) as c_transactionid
	,cast(strtok(rawdata,'01'XC,3) as CHAR(100)) as c_operationtype
	,cast(strtok(rawdata,'01'XC,4) as CHAR(100)) as c_userid
	,cast(strtok(rawdata,'01'XC,5) as CHAR(100)) as systemid
	,cast(strtok(rawdata,'01'XC,6) as CHAR(100)) as currencyval
	,cast(strtok(rawdata,'01'XC,7) as CHAR(100)) as checkdate
from tmp_19822809
where tablename='ebbs_bh_decimal_test';

-- Step 4: Drop temp table on TD. Note that temp is logical, and not a keyword.
drop table tmp_19822809;