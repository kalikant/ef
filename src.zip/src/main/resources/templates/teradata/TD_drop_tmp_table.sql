drop table tmp_${workflowName}_${r"${MAX_BUSINESS_DAY}"};
