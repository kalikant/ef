#!/bin/bash

export HADOOP_USER_NAME=${shell_username}
export PATH=$PATH:${clusterJavaPath}
export HIVE_LIB_JARS=${clusterHiveLibJars}
export HADOOP_CLASSPATH=${r"${HADOOP_CLASSPATH}"}:/usr/lib/hive/conf:${cpJars}

echo "Decoding Teradata password"
TDPASS=`curl --user ' : ' -G http://${edmhdpefServerHostname}:${edmhdpefServerPort}/crypto/decrypt/ --data-urlencode 'data=${password!"''"}'`

echo "Dropping temporary table in Teradata"
java -classpath '$CLASSPATH:JDBCShell.jar:./*:/usr/lib/hadoop-hdfs/*:/usr/lib/hadoop/*:/usr/lib/hadoop/lib/*' com.scb.edmhdpef.jdbcshell.JDBCShell ${jdbcstring} ${username!"''"} $TDPASS com.teradata.jdbc.TeraDriver TD_drop_tmp_table.sql -quiet <#list wfparams as param>${param}=${r"${"}${param}} </#list><#if MAX_BUSINESS_DAY?? > MAX_BUSINESS_DAY=${r"${MAX_BUSINESS_DAY}"}</#if>
status=$?
if [[ $status -ne 0 ]]
	then echo "WARNING: TD tmp table drop exited with return code $status; continuing"
fi

echo "Creating temporary table in Teradata"
java -classpath '$CLASSPATH:JDBCShell.jar:./*:/usr/lib/hadoop-hdfs/*:/usr/lib/hadoop/*:/usr/lib/hadoop/lib/*' com.scb.edmhdpef.jdbcshell.JDBCShell ${jdbcstring} ${username!"''"} $TDPASS com.teradata.jdbc.TeraDriver TD_create_tmp_table.sql -quiet <#list wfparams as param>${param}=${r"${"}${param}} </#list><#if MAX_BUSINESS_DAY?? > MAX_BUSINESS_DAY=${r"${MAX_BUSINESS_DAY}"}</#if>
status=$?
if [[ $status -ne 0 ]]
	then echo "TD tmp table creation exited with return code $status"
	exit $status
fi

echo "Moving data from Hive to Teradata"
hadoop jar ./${tdchJar} com.teradata.connector.common.tool.ConnectorExportTool -libjars $HIVE_LIB_JARS -classname com.teradata.jdbc.TeraDriver -url ${jdbcstring} -username ${username!"''"} -password $TDPASS -jobtype hive -fileformat textfile -separator '02'XC -method ${tdInsertMethod} -sourcedatabase ${tmpDatabase} -sourcetable edmhdpef_${workflowName}_${r"${MAX_BUSINESS_DAY}"} -sourcefieldnames 'tablename,<#list 1..maxCols as i>c${i}<#sep>,</#sep></#list>' -targettable tmp_${workflowName}_${r"${MAX_BUSINESS_DAY}"} -targetfieldnames 'tablename,<#list 1..maxCols as i>c${i}<#sep>,</#sep></#list>' ${TDCHOptionalArgs!""}
status=$?
if [[ $status -ne 0 ]]
	then echo "TDCH move to TD exited with return code $status"
	exit $status
fi

echo "Adding statement to count rows in Teradata temp table"
HIVE_SCRIPT=""
ROWCOUNT_TD_TMP_TABLE=`java -classpath '$CLASSPATH:JDBCShell.jar:./*:/usr/lib/hadoop-hdfs/*:/usr/lib/hadoop/*:/usr/lib/hadoop/lib/*' com.scb.edmhdpef.jdbcshell.JDBCShell ${jdbcstring} ${username!"''"} $TDPASS com.teradata.jdbc.TeraDriver TD_count_tmp_table.sql -quiet <#list wfparams as param>${param}=${r"${"}${param}} </#list><#if MAX_BUSINESS_DAY?? > MAX_BUSINESS_DAY=${r"${MAX_BUSINESS_DAY}"}</#if>`
status=$?
if [[ $status -ne 0 ]]
	then echo "Count of TD tmp table exited with return code $status"
	exit $status
fi

for p in $ROWCOUNT_TD_TMP_TABLE
do
	<#if bdayRequired >
	HIVE_SCRIPT=$HIVE_SCRIPT" INSERT INTO TABLE ${hiveDatabase}.rowcounts SELECT '${workflowName}', '${r"${jobId}"}', from_unixtime(unix_timestamp()), '${sourceType}', $p, '${r"${businessday}"}' FROM ${hiveDatabase}.rowcounts LIMIT 1;"
	<#else>
	HIVE_SCRIPT=$HIVE_SCRIPT" INSERT INTO TABLE ${hiveDatabase}.rowcounts SELECT '${workflowName}', '${r"${jobId}"}', from_unixtime(unix_timestamp()), '${sourceType}', $p, '' FROM ${hiveDatabase}.rowcounts LIMIT 1;"
	</#if>
done

echo "Moving data from temp table to destination tables"
ROWCOUNTS_OUTPUT=`java -classpath '$CLASSPATH:JDBCShell.jar:./*:/usr/lib/hadoop-hdfs/*:/usr/lib/hadoop/*:/usr/lib/hadoop/lib/*' com.scb.edmhdpef.jdbcshell.JDBCShell ${jdbcstring} ${username!"''"} $TDPASS com.teradata.jdbc.TeraDriver TD_split_tmp_table.sql -quiet <#list wfparams as param>${param}=${r"${"}${param}} </#list><#if MAX_BUSINESS_DAY?? > MAX_BUSINESS_DAY=${r"${MAX_BUSINESS_DAY}"}</#if>`
status=$?
if [[ $status -ne 0 ]]
	then echo "TD split from tmp table exited with return code $status"
	exit $status
fi


echo "Writing rowcounts information to Hive:"$ROWCOUNTS_OUTPUT
for p in $ROWCOUNTS_OUTPUT #note that p is of form 'tablename', count
do
	<#if bdayRequired >
	HIVE_SCRIPT=$HIVE_SCRIPT" INSERT INTO TABLE ${hiveDatabase}.rowcounts SELECT '${workflowName}', '${r"${jobId}"}', from_unixtime(unix_timestamp()), '${sourceType}', $p, '${r"${businessday}"}' FROM ${hiveDatabase}.rowcounts LIMIT 1;"
	<#else>
	HIVE_SCRIPT=$HIVE_SCRIPT" INSERT INTO TABLE ${hiveDatabase}.rowcounts SELECT '${workflowName}', '${r"${jobId}"}', from_unixtime(unix_timestamp()), '${sourceType}', $p, '' FROM ${hiveDatabase}.rowcounts LIMIT 1;"
	</#if>
done
hive -e "$HIVE_SCRIPT"
status=$?
if [[ $status -ne 0 ]]
	then echo "Hive rowcounts script exited with return code $status"
	exit $status
fi