#!/bin/bash
echo "Starting import into hive ..."
 export HADOOP_USER_NAME=${shell_username}
 hdfs dfs -rm -r ${nnFsUrl}/${warehouse}
 TDPASS=`curl --user ' : ' -G http://${restHost}:${restPort}/crypto/decrypt/ --data-urlencode 'data=${password!"''"}'`
<#if sqoop??>
sqoop import \
--connect ${jdbcstring} \
--username ${username!"''"} \
--password $TDPASS \
<#if where??>
--where ${where} \
<#else>
</#if>
<#if query?? >
--query ${query} \
<#else>
</#if>
--table ${sourceTable}  \
<#if splitBy?? >
--split-by ${splitBy} \
<#else>
</#if>
--warehouse-dir ${warehouse}
<#else>
</#if>
<#if tdch??>
hadoop jar ./${tdchJar} com.teradata.hadoop.tool.TeradataExportTool \
-url ${jdbcstring} \
-username ${username!"''"} \
-password $TDPASS \
-classname com.teradata.jdbc.TeraDriver \
<#if fileformat??>
-fileformat ${fileformat} \
<#else>
-fileformat textfile \
</#if>
<#if jobtype??>
-jobtype ${jobtype} \
<#else>
-jobtype hdfs \
</#if>
<#if separator??>
-separator ${separator} \
<#else>
</#if>
<#if method??>
-method ${method} \
<#else>
</#if>
<#if nummapper??>
-nummapper ${nummapper} \
<#else>
</#if>
<#if sourcetable??>
-sourcetable ${sourcetable} \
<#else>
</#if>
<#if sourcefieldnames??>
-sourcefieldnames ${sourcefieldnames}  \
<#else>
</#if>
<#if targetfieldnames??>
-targetfieldnames ${targetfieldnames}  \
<#else>
</#if>
<#if splitbycolumn??>
-splitbycolumn  ${splitbycolumn}
<#else>
</#if>
-targetpaths ${warehouse}
<#if TDCHOptionalArgs??>
${TDCHOptionalArgs}
<#else>
</#if>
<#else>
</#if>
echo "edmhdpef.ebbs_to_teradata.max_partition_for_business_day=0";