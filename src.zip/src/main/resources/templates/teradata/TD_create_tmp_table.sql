create table tmp_${workflowName}_${r"${MAX_BUSINESS_DAY}"} (tablename varchar(100),
<#list typeSizes as ts>c${ts?counter} varchar(${ts?c})<#sep>,</#sep></#list>)
no primary index;