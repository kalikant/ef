SELECT COUNT(1) FROM tmp_${workflowName}_${r"${MAX_BUSINESS_DAY}"};
