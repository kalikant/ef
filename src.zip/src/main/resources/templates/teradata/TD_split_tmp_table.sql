<#list dataTransferSpecs as spec>
	-- Truncate and then insert
	DELETE ${spec.getDestinationTable()} ALL;
	INSERT INTO ${spec.getDestinationDatabase()}.${spec.getDestinationTable()}(<#list spec.getColumns() as col>${col.getDestination()}<#sep>,</#sep></#list>)
	SELECT <#list spec.getColumns() as col>nullif(c${col?counter},'') as ${col.getDestination()}<#sep>,</#sep></#list>
FROM tmp_${workflowName}_${r"${MAX_BUSINESS_DAY}"}
WHERE tablename='${spec.getDestinationDatabase()}.${spec.getDestinationTable()}';
</#list>
drop table tmp_${workflowName}_${r"${MAX_BUSINESS_DAY}"};