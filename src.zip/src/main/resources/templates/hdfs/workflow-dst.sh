#!/bin/bash -e

export HADOOP_USER_NAME=${shell_username}

echo "Writing rowcounts information to Hive"

HIVE_SCRIPT=""
<#list 1..numprocessing as i>
	<#if bdayRequired>
HIVE_SCRIPT=$HIVE_SCRIPT" INSERT INTO TABLE ${hiveDatabase}.rowcounts SELECT '${workflowName}', '${r"${jobId}"}', from_unixtime(unix_timestamp()), '${sourceType}', '${r"${proctable_"}${i}${r"}"}', '${r"${proccount_"}${i}${r"}"}', '${r"${businessday}"}' FROM ${hiveDatabase}.rowcounts LIMIT 1;"
	<#else>
HIVE_SCRIPT=$HIVE_SCRIPT" INSERT INTO TABLE ${hiveDatabase}.rowcounts SELECT '${workflowName}', '${r"${jobId}"}', from_unixtime(unix_timestamp()), '${sourceType}', '${r"${proctable_"}${i}${r"}"}', '${r"${proccount_"}${i}${r"}"}', '' FROM ${hiveDatabase}.rowcounts LIMIT 1;"
	</#if>
</#list>

# Row count for output
<#list 1..numoutput as i>
	<#if bdayRequired>
HIVE_SCRIPT=$HIVE_SCRIPT" INSERT INTO TABLE ${hiveDatabase}.rowcounts SELECT '${workflowName}', '${r"${jobId}"}', from_unixtime(unix_timestamp()), '${sourceType}', '${r"${outputtable_"}${i}${r"}"}', '${r"${outputcount_"}${i}${r"}"}', '${r"${businessday}"}' FROM ${hiveDatabase}.rowcounts LIMIT 1;"
	<#else>
HIVE_SCRIPT=$HIVE_SCRIPT" INSERT INTO TABLE ${hiveDatabase}.rowcounts SELECT '${workflowName}', '${r"${jobId}"}', from_unixtime(unix_timestamp()), '${sourceType}', '${r"${outputtable_"}${i}${r"}"}', '${r"${outputcount_"}${i}${r"}"}', '' FROM ${hiveDatabase}.rowcounts LIMIT 1;"
	</#if>
</#list>

hive -e "$HIVE_SCRIPT"
