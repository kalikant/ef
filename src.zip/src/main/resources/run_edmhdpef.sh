java -jar lib/jetty-runner-9.2.12.v20150709.jar --port 12200 edmhdpef-0.0.1.war  --lib ./ --lib ./lib/ --lib /usr/lib/oozie/lib/ --lib /usr/lib/hadoop/ --lib /usr/lib/hadoop/lib/
